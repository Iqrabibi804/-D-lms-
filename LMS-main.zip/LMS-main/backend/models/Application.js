const mongoose = require('mongoose');

const applicationSchema = new mongoose.Schema({
    applicationNo: {
        type: String,
        required: true,
        unique: true,
        default: () => {
            const timestamp = Date.now().toString().slice(-6);
            const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
            return `APP${timestamp}${random}`;
        }
    },
    studentId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    registrationNo: {
        type: String,
        required: true
    },
    type: {
        type: String,
        enum: ['Fee', 'Re-checking', 'Extension', 'Adjustment', 'Other', 'Leave'],
        required: true
    },
    subject: {
        type: String,
        required: true,
        trim: true,
        maxlength: 200
    },
    message: {
        type: String,
        required: true,
        validate: {
            validator: function(v) {
                return v.toLowerCase().startsWith('it is stated that');
            },
            message: 'Application must start with "It is stated that..."'
        }
    },
    attachments: [{
        filename: String,
        path: String,
        mimetype: String,
        size: Number,
        uploadedAt: {
            type: Date,
            default: Date.now
        }
    }],
    status: {
        type: String,
        enum: ['pending', 'under_review', 'approved', 'rejected', 'implemented', 'returned'],
        default: 'pending'
    },
    currentHandler: {
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        },
        name: String,
        role: String,
        department: String
    },
    department: {
        type: String,
        required: true
    },
    priority: {
        type: String,
        enum: ['low', 'medium', 'high', 'urgent'],
        default: 'medium'
    },
    applicationDate: {
        type: Date,
        default: Date.now
    },
    lastUpdated: {
        type: Date,
        default: Date.now
    },
    implementedDate: Date,
    closedAt: Date,
    remarks: String,
    isActive: {
        type: Boolean,
        default: true
    }
}, {
    timestamps: true
});

// Indexes for better performance
applicationSchema.index({ studentId: 1, applicationDate: -1 });
applicationSchema.index({ status: 1 });
applicationSchema.index({ currentHandler: 1 });
applicationSchema.index({ department: 1, status: 1 });
applicationSchema.index({ applicationNo: 1 });

const Application = mongoose.model('Application', applicationSchema);
module.exports = Application;