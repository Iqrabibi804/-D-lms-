const mongoose = require('mongoose');
const { router } = require('../routes/library');

const librarySchema = new mongoose.Schema({
    bookId: {
        type: String,
        required: true,
        unique: true
    },
    title: {
        type: String,
        required: true,
        trim: true
    },
    author: {
        type: String,
        required: true,
        trim: true
    },
    isbn: {
        type: String,
        required: true,
        unique: true
    },
    
    // Book Details
    category: {
        type: String,
        required: true,
        enum: ['Computer Science', 'Engineering', 'Mathematics', 'Physics', 
               'Chemistry', 'Literature', 'History', 'General']
    },
    publisher: {
        type: String
    },
    publicationYear: {
        type: Number
    },
    edition: {
        type: String
    },
    
    // Inventory
    totalCopies: {
        type: Number,
        required: true,
        min: 1
    },
    availableCopies: {
        type: Number,
        required: true,
        min: 0
    },
    shelfLocation: {
        type: String,
        required: true
    },
    
    // Borrowing
    borrowedBy: [{
        student: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        },
        borrowDate: {
            type: Date,
            default: Date.now
        },
        dueDate: {
            type: Date,
            required: true
        },
        returnDate: Date,
        fine: {
            type: Number,
            default: 0
        },
        status: {
            type: String,
            enum: ['borrowed', 'returned', 'overdue'],
            default: 'borrowed'
        }
    }],
    
    // Book Status
    isAvailable: {
        type: Boolean,
        default: true
    },
    
    // Metadata
    addedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    addedDate: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Library', librarySchema);
module.exports = router;
