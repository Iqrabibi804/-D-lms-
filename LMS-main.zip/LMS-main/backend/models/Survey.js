const mongoose = require('mongoose');

const surveySchema = new mongoose.Schema({
    // Student Information (stored but not shown to instructor)
    studentId: {
        type: String,
        required: true
    },
    studentName: {
        type: String,
        required: true
    },
    
    // Course Information
    instructorId: {
        type: String,
        required: true
    },
    instructorName: {
        type: String,
        required: true
    },
    courseCode: {
        type: String,
        required: true
    },
    courseName: {
        type: String,
        required: true
    },
    semester: {
        type: String,
        required: true
    },
    
    // Survey Details
    surveyType: {
        type: String,
        enum: ['mids', 'finals'],
        required: true
    },
    averageScore: {
        type: Number,
        required: true,
        min: 1,
        max: 5
    },
    
    // Question Responses
    question1: { type: Number, min: 1, max: 5 },
    question2: { type: Number, min: 1, max: 5 },
    question3: { type: Number, min: 1, max: 5 },
    question4: { type: Number, min: 1, max: 5 },
    question5: { type: Number, min: 1, max: 5 },
    question6: { type: Number, min: 1, max: 5 },
    
    // Anonymous Complaint/Message
    complaintMessage: {
        type: String,
        maxlength: 1000
    },
    
    // Metadata
    isAnonymous: {
        type: Boolean,
        default: true
    },
    submissionDate: {
        type: Date,
        default: Date.now
    },
    
    // For admin to control surveys
    isActive: {
        type: Boolean,
        default: true
    },
    adminUploaded: {
        type: Boolean,
        default: false
    },
    deadline: {
        type: Date
    }
}, {
    timestamps: true
});

// Index for efficient queries
surveySchema.index({ instructorId: 1, surveyType: 1, semester: 1 });
surveySchema.index({ studentId: 1, courseCode: 1, surveyType: 1 });
surveySchema.index({ submissionDate: -1 });

module.exports = mongoose.model('Survey', surveySchema);