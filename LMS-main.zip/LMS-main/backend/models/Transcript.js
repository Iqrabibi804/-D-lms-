const mongoose = require('mongoose');

const transcriptSchema = new mongoose.Schema({
    student: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    semester: {
        type: Number,
        required: true
    },
    academicYear: {
        type: String,
        required: true
    },
    
    // Course Grades
    courses: [{
        course: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Course'
        },
        courseCode: String,
        courseName: String,
        credits: Number,
        grade: {
            type: String,
            enum: ['A', 'B', 'C', 'D', 'F', 'I', 'W']
        },
        gradePoints: Number,
        marks: Number,
        status: {
            type: String,
            enum: ['completed', 'in-progress', 'failed']
        }
    }],
    
    // Semester Statistics
    totalCredits: {
        type: Number,
        default: 0
    },
    earnedCredits: {
        type: Number,
        default: 0
    },
    sgpa: {
        type: Number,
        min: 0,
        max: 10
    },
    cgpa: {
        type: Number,
        min: 0,
        max: 10
    },
    
    // Transcript Status
    isPublished: {
        type: Boolean,
        default: false
    },
    publishedDate: Date,
    publishedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    },
    
    // Verification
    verificationCode: {
        type: String,
        unique: true
    },
    isVerified: {
        type: Boolean,
        default: false
    },
    
    // Digital Signature
    digitalSignature: String,
    qrCode: String
}, {
    timestamps: true
});

// Generate verification code before saving
transcriptSchema.pre('save', function(next) {
    if (!this.verificationCode) {
        this.verificationCode = 'TR-' + Date.now().toString(36) + Math.random().toString(36).substr(2);
    }
    next();
});

module.exports = mongoose.model('Transcript', transcriptSchema);