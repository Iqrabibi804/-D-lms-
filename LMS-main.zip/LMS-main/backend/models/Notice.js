const mongoose = require('mongoose');

const noticeSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true,
        trim: true
    },
    content: {
        type: String,
        required: true
    },
    category: {
        type: String,
        enum: ['academic', 'exam', 'holiday', 'event', 'emergency', 'general'],
        default: 'general'
    },
    
    // Target Audience
    targetDepartment: {
        type: String,
        enum: ['all', 'Computer Science', 'Engineering', 'Mathematics', 'Physics', 'Chemistry']
    },
    targetYear: {
        type: String,
        enum: ['all', '1st Year', '2nd Year', '3rd Year', '4th Year']
    },
    
    // Important Notice
    isImportant: {
        type: Boolean,
        default: false
    },
    priority: {
        type: String,
        enum: ['low', 'medium', 'high', 'urgent'],
        default: 'medium'
    },
    
    // Timing
    publishDate: {
        type: Date,
        default: Date.now
    },
    expiryDate: {
        type: Date
    },
    
    // Attachments
    attachments: [{
        name: String,
        url: String,
        size: Number
    }],
    
    // Author
    createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    
    // Read Status (for individual students)
    readBy: [{
        student: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        },
        readAt: {
            type: Date,
            default: Date.now
        }
    }]
}, {
    timestamps: true
});

module.exports = mongoose.model('Notice', noticeSchema);