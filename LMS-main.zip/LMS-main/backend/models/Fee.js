const mongoose = require('mongoose');

const feeSchema = new mongoose.Schema({
    student: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    semester: {
        type: Number,
        required: true,
        min: 1,
        max: 8
    },
    academicYear: {
        type: String,
        required: true
    },
    
    // Fee Breakdown
    tuitionFee: {
        type: Number,
        required: true,
        min: 0
    },
    libraryFee: {
        type: Number,
        default: 0
    },
    examFee: {
        type: Number,
        default: 0
    },
    labFee: {
        type: Number,
        default: 0
    },
    otherCharges: {
        type: Number,
        default: 0
    },
    
    // Payment Status
    totalAmount: {
        type: Number,
        required: true
    },
    paidAmount: {
        type: Number,
        default: 0
    },
    pendingAmount: {
        type: Number,
        default: function() {
            return this.totalAmount - this.paidAmount;
        }
    },
    status: {
        type: String,
        enum: ['paid', 'partial', 'unpaid', 'overdue'],
        default: 'unpaid'
    },
    
    // Payment History
    payments: [{
        amount: {
            type: Number,
            required: true
        },
        paymentDate: {
            type: Date,
            default: Date.now
        },
        paymentMethod: {
            type: String,
            enum: ['cash', 'card', 'bank_transfer', 'online'],
            required: true
        },
        transactionId: String,
        receiptNumber: String,
        verifiedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        }
    }],
    
    // Due Dates
    dueDate: {
        type: Date,
        required: true
    },
    lateFee: {
        type: Number,
        default: 0
    },
    
    // Discounts/Scholarships
    discount: {
        type: Number,
        default: 0
    },
    scholarship: {
        type: Number,
        default: 0
    },
    discountReason: String
}, {
    timestamps: true
});

// Calculate total before saving
feeSchema.pre('save', function(next) {
    this.totalAmount = this.tuitionFee + this.libraryFee + this.examFee + 
                      this.labFee + this.otherCharges - this.discount - this.scholarship;
    this.pendingAmount = this.totalAmount - this.paidAmount;
    
    // Update status
    if (this.paidAmount >= this.totalAmount) {
        this.status = 'paid';
    } else if (this.paidAmount > 0) {
        this.status = 'partial';
    } else if (new Date() > this.dueDate) {
        this.status = 'overdue';
    } else {
        this.status = 'unpaid';
    }
    
    next();
});

module.exports = mongoose.model('Fee', feeSchema);