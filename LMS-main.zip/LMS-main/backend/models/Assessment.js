const mongoose = require('mongoose');

const assessmentSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        trim: true
    },
    course: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Course',
        required: true
    },
    
    // Type of assessment
    type: {
        type: String,
        enum: ['quiz', 'assignment', 'midterm', 'final', 'project'],
        required: true
    },
    
    // Timing
    startDate: {
        type: Date,
        required: true
    },
    dueDate: {
        type: Date,
        required: true
    },
    duration: {
        type: Number, // in minutes
        required: function() {
            return this.type === 'quiz';
        }
    },
    
    // Grading
    totalMarks: {
        type: Number,
        required: true,
        min: 0
    },
    weightage: {
        type: Number,
        required: true,
        min: 0,
        max: 100
    },
    
    // Questions/Instructions
    questions: [{
        question: String,
        options: [String],
        correctAnswer: String,
        marks: Number
    }],
    
    // Submission
    submissions: [{
        student: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        },
        submittedAt: Date,
        answers: [{
            questionIndex: Number,
            answer: String
        }],
        marksObtained: Number,
        gradedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        },
        feedback: String,
        status: {
            type: String,
            enum: ['submitted', 'graded', 'late', 'missing'],
            default: 'submitted'
        }
    }],
    
    // Files
    files: [{
        name: String,
        url: String,
        uploadedAt: Date
    }],
    
    // Settings
    isActive: {
        type: Boolean,
        default: true
    },
    allowLateSubmission: {
        type: Boolean,
        default: false
    },
    latePenalty: {
        type: Number,
        default: 0
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Assessment', assessmentSchema);