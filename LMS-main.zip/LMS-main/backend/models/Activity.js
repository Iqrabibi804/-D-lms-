const mongoose = require('mongoose');

const activitySchema = new mongoose.Schema({
    applicationId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Application',
        required: true
    },
    activityNo: {
        type: Number,
        required: true
    },
    action: {
        type: String,
        enum: ['submitted', 'forwarded', 'approved', 'rejected', 'returned', 'implemented', 'commented'],
        required: true
    },
    forwardedBy: {
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        },
        name: String,
        role: String,
        department: String
    },
    respondBy: {
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        },
        name: String,
        role: String,
        department: String
    },
    response: {
        type: String,
        enum: ['Submitted', 'Forwarded', 'Approved', 'Rejected', 'Returned', 'Implemented'],
        required: true
    },
    forwardedTo: {
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        },
        name: String,
        role: String,
        department: String
    },
    remarks: String,
    date: {
        type: Date,
        default: Date.now
    },
    isStudentNotified: {
        type: Boolean,
        default: false
    },
    metadata: mongoose.Schema.Types.Mixed
}, {
    timestamps: true
});

// Indexes
activitySchema.index({ applicationId: 1, activityNo: 1 });
activitySchema.index({ 'forwardedBy.userId': 1 });
activitySchema.index({ date: -1 });

const Activity = mongoose.model('Activity', activitySchema);
module.exports = Activity;