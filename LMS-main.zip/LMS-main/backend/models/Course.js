const mongoose = require('mongoose');

const CourseSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'Please add a course title'],
        trim: true,
        maxlength: [100, 'Title cannot be more than 100 characters']
    },
    code: {
        type: String,
        required: [true, 'Please add a course code'],
        unique: true,
        uppercase: true,
        maxlength: [10, 'Course code cannot be more than 10 characters']
    },
    description: {
        type: String,
        required: [true, 'Please add a description']
    },
    credits: {
        type: Number,
        required: [true, 'Please add number of credits'],
        min: [1, 'Credits must be at least 1'],
        max: [10, 'Credits cannot be more than 10']
    },
    department: {
        type: String,
        required: [true, 'Please add department'],
        enum: ['CSE', 'ECE', 'ME', 'CE', 'EEE', 'IT']
    },
    semester: {
        type: Number,
        required: [true, 'Please add semester'],
        min: [1, 'Semester must be at least 1'],
        max: [8, 'Semester cannot be more than 8']
    },
    teacher: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    studentsEnrolled: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }],
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Course', CourseSchema);