const Fee = require('../models/Fee');

// @desc    Get fee details for student
// @route   GET /api/fees
// @access  Private
exports.getFees = async (req, res) => {
    try {
        const studentId = req.user.id;
        const { semester, academicYear } = req.query;

        let query = { student: studentId };

        if (semester) {
            query.semester = parseInt(semester);
        }

        if (academicYear) {
            query.academicYear = academicYear;
        }

        const fees = await Fee.find(query)
            .sort({ semester: -1, createdAt: -1 });

        // Calculate overall statistics
        const totalPending = fees.reduce((sum, fee) => sum + fee.pendingAmount, 0);
        const totalPaid = fees.reduce((sum, fee) => sum + fee.paidAmount, 0);
        const totalAmount = fees.reduce((sum, fee) => sum + fee.totalAmount, 0);

        res.status(200).json({
            success: true,
            count: fees.length,
            statistics: {
                totalPending,
                totalPaid,
                totalAmount,
                paidPercentage: totalAmount > 0 ? (totalPaid / totalAmount * 100).toFixed(2) : 0
            },
            fees
        });

    } catch (error) {
        console.error('Get fees error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};

// @desc    Get fee details by ID
// @route   GET /api/fees/:id
// @access  Private
exports.getFeeDetails = async (req, res) => {
    try {
        const feeId = req.params.id;
        const studentId = req.user.id;

        const fee = await Fee.findOne({
            _id: feeId,
            student: studentId
        });

        if (!fee) {
            return res.status(404).json({
                success: false,
                message: 'Fee record not found'
            });
        }

        res.status(200).json({
            success: true,
            fee
        });

    } catch (error) {
        console.error('Get fee details error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};

// @desc    Make payment
// @route   POST /api/fees/:id/pay
// @access  Private
exports.makePayment = async (req, res) => {
    try {
        const feeId = req.params.id;
        const studentId = req.user.id;
        const { amount, paymentMethod, transactionId } = req.body;

        const fee = await Fee.findOne({
            _id: feeId,
            student: studentId
        });

        if (!fee) {
            return res.status(404).json({
                success: false,
                message: 'Fee record not found'
            });
        }

        // Check if already paid
        if (fee.status === 'paid') {
            return res.status(400).json({
                success: false,
                message: 'Fee already paid in full'
            });
        }

        // Check payment amount
        if (amount <= 0) {
            return res.status(400).json({
                success: false,
                message: 'Invalid payment amount'
            });
        }

        if (amount > fee.pendingAmount) {
            return res.status(400).json({
                success: false,
                message: `Payment amount exceeds pending amount. Maximum: ${fee.pendingAmount}`
            });
        }

        // Create payment record
        const payment = {
            amount,
            paymentMethod,
            transactionId,
            paymentDate: new Date()
        };

        fee.payments.push(payment);
        fee.paidAmount += amount;

        // Save fee (pre-save middleware will update status)
        await fee.save();

        res.status(200).json({
            success: true,
            message: 'Payment recorded successfully',
            payment,
            fee: {
                id: fee._id,
                paidAmount: fee.paidAmount,
                pendingAmount: fee.pendingAmount,
                status: fee.status
            }
        });

    } catch (error) {
        console.error('Make payment error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};

// @desc    Generate fee receipt
// @route   GET /api/fees/:id/receipt
// @access  Private
exports.generateReceipt = async (req, res) => {
    try {
        const feeId = req.params.id;
        const studentId = req.user.id;

        const fee = await Fee.findOne({
            _id: feeId,
            student: studentId
        }).populate('student', 'fullName studentId department year');

        if (!fee) {
            return res.status(404).json({
                success: false,
                message: 'Fee record not found'
            });
        }

        // Generate receipt data
        const receipt = {
            receiptNumber: `REC-${Date.now()}-${fee._id.toString().slice(-6)}`,
            student: {
                name: fee.student.fullName,
                studentId: fee.student.studentId,
                department: fee.student.department,
                year: fee.student.year
            },
            feeDetails: {
                semester: fee.semester,
                academicYear: fee.academicYear,
                tuitionFee: fee.tuitionFee,
                libraryFee: fee.libraryFee,
                examFee: fee.examFee,
                labFee: fee.labFee,
                otherCharges: fee.otherCharges,
                discount: fee.discount,
                scholarship: fee.scholarship,
                totalAmount: fee.totalAmount
            },
            paymentDetails: {
                paidAmount: fee.paidAmount,
                pendingAmount: fee.pendingAmount,
                status: fee.status,
                payments: fee.payments
            },
            generatedAt: new Date().toISOString(),
            verificationCode: `VER-${fee._id.toString().slice(-8)}-${Date.now().toString(36)}`
        };

        res.status(200).json({
            success: true,
            receipt
        });

    } catch (error) {
        console.error('Generate receipt error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};