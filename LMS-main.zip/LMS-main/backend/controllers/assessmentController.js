const Assessment = require('../models/Assessment');
const Course = require('../models/Course');

// @desc    Get assessments for a student
// @route   GET /api/assessments
// @access  Private
exports.getAssessments = async (req, res) => {
    try {
        const studentId = req.user.id;
        const { courseId, type, status } = req.query;

        // Get courses the student is enrolled in
        const enrolledCourses = await Course.find({
            'enrolledStudents.student': studentId,
            'enrolledStudents.status': 'enrolled'
        }).select('_id');

        const courseIds = enrolledCourses.map(course => course._id);

        let query = { 
            course: { $in: courseIds },
            isActive: true 
        };

        if (courseId) {
            query.course = courseId;
        }

        if (type) {
            query.type = type;
        }

        const assessments = await Assessment.find(query)
            .populate('course', 'courseCode courseName')
            .sort({ dueDate: 1 });

        // Add submission status for each assessment
        const assessmentsWithStatus = assessments.map(assessment => {
            const submission = assessment.submissions.find(
                sub => sub.student && sub.student.toString() === studentId
            );
            
            return {
                ...assessment.toObject(),
                submissionStatus: submission ? submission.status : 'not_submitted',
                marksObtained: submission ? submission.marksObtained : null
            };
        });

        res.status(200).json({
            success: true,
            count: assessments.length,
            assessments: assessmentsWithStatus
        });

    } catch (error) {
        console.error('Get assessments error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};

// @desc    Get assessment details
// @route   GET /api/assessments/:id
// @access  Private
exports.getAssessmentDetails = async (req, res) => {
    try {
        const assessmentId = req.params.id;
        const studentId = req.user.id;

        const assessment = await Assessment.findById(assessmentId)
            .populate('course', 'courseCode courseName')
            .populate('submissions.student', 'fullName studentId');

        if (!assessment) {
            return res.status(404).json({
                success: false,
                message: 'Assessment not found'
            });
        }

        // Check if student is enrolled in the course
        const course = await Course.findOne({
            _id: assessment.course._id,
            'enrolledStudents.student': studentId
        });

        if (!course) {
            return res.status(403).json({
                success: false,
                message: 'Not enrolled in this course'
            });
        }

        // Get student's submission if exists
        const studentSubmission = assessment.submissions.find(
            submission => submission.student && submission.student._id.toString() === studentId
        );

        // Don't send correct answers to students
        const assessmentForStudent = assessment.toObject();
        if (assessmentForStudent.questions) {
            assessmentForStudent.questions = assessmentForStudent.questions.map(q => ({
                ...q,
                correctAnswer: undefined
            }));
        }

        res.status(200).json({
            success: true,
            assessment: assessmentForStudent,
            submission: studentSubmission || null,
            timeRemaining: assessment.dueDate - Date.now()
        });

    } catch (error) {
        console.error('Get assessment details error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};

// @desc    Submit assessment
// @route   POST /api/assessments/:id/submit
// @access  Private
exports.submitAssessment = async (req, res) => {
    try {
        const assessmentId = req.params.id;
        const studentId = req.user.id;
        const { answers, files } = req.body;

        const assessment = await Assessment.findById(assessmentId);

        if (!assessment) {
            return res.status(404).json({
                success: false,
                message: 'Assessment not found'
            });
        }

        // Check if deadline has passed
        if (new Date() > assessment.dueDate && !assessment.allowLateSubmission) {
            return res.status(400).json({
                success: false,
                message: 'Submission deadline has passed'
            });
        }

        // Check if already submitted
        const existingSubmissionIndex = assessment.submissions.findIndex(
            submission => submission.student && submission.student.toString() === studentId
        );

        if (existingSubmissionIndex !== -1) {
            return res.status(400).json({
                success: false,
                message: 'Already submitted'
            });
        }

        // Check if it's a quiz and calculate marks automatically
        let marksObtained = 0;
        if (assessment.type === 'quiz') {
            answers.forEach((answer, index) => {
                const question = assessment.questions[index];
                if (question && answer.answer === question.correctAnswer) {
                    marksObtained += question.marks || 1;
                }
            });
        }

        // Create submission
        const submission = {
            student: studentId,
            submittedAt: new Date(),
            answers: answers || [],
            marksObtained,
            status: new Date() > assessment.dueDate ? 'late' : 'submitted'
        };

        assessment.submissions.push(submission);
        await assessment.save();

        res.status(200).json({
            success: true,
            message: 'Assessment submitted successfully',
            submissionId: assessment.submissions[assessment.submissions.length - 1]._id,
            marksObtained
        });

    } catch (error) {
        console.error('Submit assessment error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};