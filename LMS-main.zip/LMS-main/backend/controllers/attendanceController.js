const Attendance = require('../models/Attendance');
const Course = require('../models/Course');
const User = require('../models/User');

// @desc    Get attendance for a student
// @route   GET /api/attendance
// @access  Private
exports.getAttendance = async (req, res) => {
    try {
        const studentId = req.user.id;
        const { courseId, startDate, endDate } = req.query;

        let query = { student: studentId };

        if (courseId) {
            query.course = courseId;
        }

        if (startDate || endDate) {
            query.date = {};
            if (startDate) query.date.$gte = new Date(startDate);
            if (endDate) query.date.$lte = new Date(endDate);
        }

        const attendance = await Attendance.find(query)
            .populate('course', 'courseCode courseName')
            .populate('markedBy', 'fullName')
            .sort({ date: -1 });

        // Calculate statistics
        const totalClasses = attendance.length;
        const presentClasses = attendance.filter(a => a.status === 'present').length;
        const absentClasses = attendance.filter(a => a.status === 'absent').length;
        const attendancePercentage = totalClasses > 0 
            ? (presentClasses / totalClasses * 100).toFixed(2) 
            : 0;

        res.status(200).json({
            success: true,
            count: attendance.length,
            statistics: {
                totalClasses,
                presentClasses,
                absentClasses,
                attendancePercentage: parseFloat(attendancePercentage)
            },
            attendance
        });

    } catch (error) {
        console.error('Get attendance error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};

// @desc    Mark attendance (for teachers)
// @route   POST /api/attendance/mark
// @access  Private (Teacher only)
exports.markAttendance = async (req, res) => {
    try {
        const { courseId, studentId, date, status, remarks } = req.body;
        const markedBy = req.user.id;

        // Check if user is teacher
        if (req.user.role !== 'teacher' && req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to mark attendance'
            });
        }

        // Check if course exists
        const course = await Course.findById(courseId);
        if (!course) {
            return res.status(404).json({
                success: false,
                message: 'Course not found'
            });
        }

        // Check if student is enrolled
        const isEnrolled = course.enrolledStudents.some(
            enrollment => enrollment.student.toString() === studentId
        );

        if (!isEnrolled) {
            return res.status(400).json({
                success: false,
                message: 'Student is not enrolled in this course'
            });
        }

        // Check if attendance already marked for this date
        const existingAttendance = await Attendance.findOne({
            student: studentId,
            course: courseId,
            date: new Date(date)
        });

        if (existingAttendance) {
            // Update existing attendance
            existingAttendance.status = status;
            existingAttendance.remarks = remarks;
            existingAttendance.markedBy = markedBy;
            await existingAttendance.save();

            return res.status(200).json({
                success: true,
                message: 'Attendance updated successfully',
                attendance: existingAttendance
            });
        }

        // Create new attendance record
        const attendance = await Attendance.create({
            student: studentId,
            course: courseId,
            date: new Date(date),
            status,
            remarks,
            markedBy
        });

        res.status(201).json({
            success: true,
            message: 'Attendance marked successfully',
            attendance
        });

    } catch (error) {
        console.error('Mark attendance error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};

// @desc    Generate QR code for attendance (for teachers)
// @route   POST /api/attendance/generate-qr
// @access  Private (Teacher only)
exports.generateQRCode = async (req, res) => {
    try {
        const { courseId, duration = 15 } = req.body; // duration in minutes
        const teacherId = req.user.id;

        // Check if user is teacher
        if (req.user.role !== 'teacher' && req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Not authorized'
            });
        }

        const course = await Course.findById(courseId);
        if (!course) {
            return res.status(404).json({
                success: false,
                message: 'Course not found'
            });
        }

        // Generate unique QR code
        const qrCode = `ATT-${courseId}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        
        // Get enrolled students
        const enrolledStudents = course.enrolledStudents
            .filter(enrollment => enrollment.status === 'enrolled')
            .map(enrollment => enrollment.student);

        // Create attendance records with QR code
        const attendanceRecords = enrolledStudents.map(studentId => ({
            student: studentId,
            course: courseId,
            date: new Date(),
            status: 'absent', // Default status
            qrCode,
            qrScanned: false
        }));

        // Save all attendance records
        await Attendance.insertMany(attendanceRecords);

        // QR code expires after specified duration
        const expiresAt = new Date(Date.now() + duration * 60000);

        res.status(200).json({
            success: true,
            message: 'QR code generated successfully',
            qrCode,
            expiresAt,
            duration,
            enrolledStudents: enrolledStudents.length
        });

    } catch (error) {
        console.error('Generate QR error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};

// @desc    Scan QR code for attendance (for students)
// @route   POST /api/attendance/scan-qr
// @access  Private
exports.scanQRCode = async (req, res) => {
    try {
        const { qrCode } = req.body;
        const studentId = req.user.id;

        // Find attendance record with this QR code
        const attendance = await Attendance.findOne({
            qrCode,
            student: studentId,
            qrScanned: false
        });

        if (!attendance) {
            return res.status(400).json({
                success: false,
                message: 'Invalid QR code or already scanned'
            });
        }

        // Check if QR code is still valid
        const qrGeneratedTime = new Date(attendance.createdAt).getTime();
        const currentTime = Date.now();
        const timeDifference = (currentTime - qrGeneratedTime) / 60000; // in minutes

        // Usually QR codes expire after 15-30 minutes
        if (timeDifference > 30) {
            return res.status(400).json({
                success: false,
                message: 'QR code has expired'
            });
        }

        // Update attendance
        attendance.status = 'present';
        attendance.qrScanned = true;
        attendance.scanTime = new Date();
        await attendance.save();

        res.status(200).json({
            success: true,
            message: 'Attendance marked successfully',
            attendance
        });

    } catch (error) {
        console.error('Scan QR error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};