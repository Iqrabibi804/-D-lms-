const Survey = require('../models/Survey');
const User = require('../models/User');

// Submit a survey
exports.submitSurvey = async (req, res) => {
    try {
        const {
            instructorId,
            instructorName,
            courseCode,
            courseName,
            surveyType,
            semester,
            averageScore,
            complaintMessage,
            question1, question2, question3, question4, question5, question6
        } = req.body;

        // Get student information from token
        const studentId = req.user.studentId;
        const studentName = req.user.fullName;

        // Check if student already submitted this survey type for this course
        const existingSurvey = await Survey.findOne({
            studentId,
            courseCode,
            surveyType,
            semester
        });

        if (existingSurvey) {
            return res.status(400).json({
                success: false,
                message: `You have already submitted the ${surveyType} survey for this course.`
            });
        }

        // Create new survey
        const survey = new Survey({
            studentId,
            studentName,
            instructorId,
            instructorName,
            courseCode,
            courseName,
            surveyType,
            semester,
            averageScore,
            complaintMessage: complaintMessage || '',
            question1, question2, question3, question4, question5, question6,
            isAnonymous: true
        });

        await survey.save();

        res.status(201).json({
            success: true,
            message: 'Survey submitted successfully (anonymous)',
            surveyId: survey._id,
            data: {
                surveyType,
                courseCode,
                instructorName,
                averageScore,
                submissionDate: survey.submissionDate
            }
        });

    } catch (error) {
        console.error('Survey submission error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Get student's survey history
exports.getStudentSurveys = async (req, res) => {
    try {
        const studentId = req.user.studentId;
        
        const surveys = await Survey.find({ studentId })
            .select('-studentId -studentName') // Hide student info in response
            .sort({ submissionDate: -1 });

        res.status(200).json({
            success: true,
            count: surveys.length,
            surveys
        });

    } catch (error) {
        console.error('Get student surveys error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Get instructor's survey results (anonymous)
exports.getInstructorSurveys = async (req, res) => {
    try {
        const instructorId = req.params.instructorId || req.user.studentId;
        
        // Check if user is the instructor or admin
        const isInstructor = req.user.role === 'teacher' && req.user.studentId === instructorId;
        const isAdmin = req.user.role === 'admin';
        
        if (!isInstructor && !isAdmin) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        // Get surveys for this instructor
        const surveys = await Survey.find({ instructorId })
            .select('-studentId -studentName') // Hide student identities
            .sort({ submissionDate: -1 });

        // Calculate statistics
        const midsSurveys = surveys.filter(s => s.surveyType === 'mids');
        const finalsSurveys = surveys.filter(s => s.surveyType === 'finals');
        
        const calculateStats = (surveyList) => {
            if (surveyList.length === 0) return null;
            
            const totalScore = surveyList.reduce((sum, s) => sum + s.averageScore, 0);
            const avgScore = (totalScore / surveyList.length).toFixed(2);
            
            // Count complaints
            const complaints = surveyList.filter(s => s.complaintMessage && s.complaintMessage.trim()).length;
            
            return {
                count: surveyList.length,
                averageScore: avgScore,
                complaintsCount: complaints,
                complaintsPercentage: Math.round((complaints / surveyList.length) * 100)
            };
        };

        res.status(200).json({
            success: true,
            instructorId,
            instructorName: surveys[0]?.instructorName || '',
            overall: {
                totalSurveys: surveys.length,
                mids: calculateStats(midsSurveys),
                finals: calculateStats(finalsSurveys)
            },
            anonymousMessages: surveys
                .filter(s => s.complaintMessage && s.complaintMessage.trim())
                .map(s => ({
                    message: s.complaintMessage,
                    surveyType: s.surveyType,
                    submissionDate: s.submissionDate,
                    averageScore: s.averageScore
                }))
        });

    } catch (error) {
        console.error('Get instructor surveys error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Admin: Upload/activate surveys for students
exports.activateSurvey = async (req, res) => {
    try {
        if (req.user.role !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Admin access required'
            });
        }

        const { surveyType, deadline, courses } = req.body;

        // Here you would typically create survey records for all students
        // or set a flag that surveys are active for certain courses

        res.status(200).json({
            success: true,
            message: `${surveyType} surveys activated for selected courses`,
            deadline,
            courses,
            activationDate: new Date()
        });

    } catch (error) {
        console.error('Activate survey error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};

// Check if survey is available for student
exports.checkSurveyAvailability = async (req, res) => {
    try {
        const { courseCode, surveyType } = req.query;
        const studentId = req.user.studentId;

        // Check if student already submitted
        const submitted = await Survey.findOne({
            studentId,
            courseCode,
            surveyType
        });

        // Here you would also check if admin has activated surveys
        // and if deadline hasn't passed

        res.status(200).json({
            success: true,
            available: !submitted,
            alreadySubmitted: !!submitted,
            submission: submitted ? {
                date: submitted.submissionDate,
                averageScore: submitted.averageScore
            } : null
        });

    } catch (error) {
        console.error('Check survey availability error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
};