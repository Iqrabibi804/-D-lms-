const Course = require('../models/Course');
const User = require('../models/User');

// @desc    Get all courses for a student
// @route   GET /api/courses/my-courses
// @access  Private
exports.getMyCourses = async (req, res) => {
    try {
        const studentId = req.user.id;
        const { semester } = req.query;

        let query = {
            'enrolledStudents.student': studentId,
            'enrolledStudents.status': 'enrolled'
        };

        if (semester) {
            query.semester = parseInt(semester);
        }

        const courses = await Course.find(query)
            .populate('instructor', 'fullName email')
            .select('-enrolledStudents');

        res.status(200).json({
            success: true,
            count: courses.length,
            courses
        });

    } catch (error) {
        console.error('Get courses error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};

// @desc    Get course details
// @route   GET /api/courses/:id
// @access  Private
exports.getCourseDetails = async (req, res) => {
    try {
        const courseId = req.params.id;
        const studentId = req.user.id;

        const course = await Course.findOne({
            _id: courseId,
            'enrolledStudents.student': studentId
        })
        .populate('instructor', 'fullName email phone profileImage')
        .populate('enrolledStudents.student', 'fullName studentId');

        if (!course) {
            return res.status(404).json({
                success: false,
                message: 'Course not found or you are not enrolled'
            });
        }

        // Get student's specific enrollment info
        const studentEnrollment = course.enrolledStudents.find(
            enrollment => enrollment.student._id.toString() === studentId
        );

        res.status(200).json({
            success: true,
            course,
            enrollment: studentEnrollment
        });

    } catch (error) {
        console.error('Get course details error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};

// @desc    Get available courses for enrollment
// @route   GET /api/courses/available
// @access  Private
exports.getAvailableCourses = async (req, res) => {
    try {
        const student = await User.findById(req.user.id);
        const { department, year, semester } = req.query;

        let query = {
            isActive: true,
            department: student.department,
            semester: student.semester || semester
        };

        if (department) query.department = department;
        if (semester) query.semester = semester;

        const courses = await Course.find(query)
            .populate('instructor', 'fullName')
            .select('courseCode courseName description credits instructor schedule maxStudents currentStudents');

        res.status(200).json({
            success: true,
            count: courses.length,
            courses
        });

    } catch (error) {
        console.error('Get available courses error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};

// @desc    Enroll in a course
// @route   POST /api/courses/:id/enroll
// @access  Private
exports.enrollInCourse = async (req, res) => {
    try {
        const courseId = req.params.id;
        const studentId = req.user.id;

        const course = await Course.findById(courseId);

        if (!course) {
            return res.status(404).json({
                success: false,
                message: 'Course not found'
            });
        }

        // Check if already enrolled
        const alreadyEnrolled = course.enrolledStudents.some(
            enrollment => enrollment.student.toString() === studentId
        );

        if (alreadyEnrolled) {
            return res.status(400).json({
                success: false,
                message: 'Already enrolled in this course'
            });
        }

        // Check if course is full
        if (course.currentStudents >= course.maxStudents) {
            return res.status(400).json({
                success: false,
                message: 'Course is full'
            });
        }

        // Check if student's department matches course department
        const student = await User.findById(studentId);
        if (student.department !== course.department) {
            return res.status(400).json({
                success: false,
                message: 'This course is not available for your department'
            });
        }

        // Add student to course
        course.enrolledStudents.push({
            student: studentId,
            enrollmentDate: Date.now()
        });

        course.currentStudents += 1;
        await course.save();

        res.status(200).json({
            success: true,
            message: 'Successfully enrolled in course',
            course: {
                id: course._id,
                courseCode: course.courseCode,
                courseName: course.courseName
            }
        });

    } catch (error) {
        console.error('Enroll error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};

// @desc    Drop a course
// @route   POST /api/courses/:id/drop
// @access  Private
exports.dropCourse = async (req, res) => {
    try {
        const courseId = req.params.id;
        const studentId = req.user.id;

        const course = await Course.findById(courseId);

        if (!course) {
            return res.status(404).json({
                success: false,
                message: 'Course not found'
            });
        }

        // Check if enrolled
        const enrollmentIndex = course.enrolledStudents.findIndex(
            enrollment => enrollment.student.toString() === studentId
        );

        if (enrollmentIndex === -1) {
            return res.status(400).json({
                success: false,
                message: 'Not enrolled in this course'
            });
        }

        // Update enrollment status
        course.enrolledStudents[enrollmentIndex].status = 'dropped';
        course.currentStudents -= 1;
        await course.save();

        res.status(200).json({
            success: true,
            message: 'Successfully dropped the course'
        });

    } catch (error) {
        console.error('Drop course error:', error);
        res.status(500).json({
            success: false,
            message: 'Server error',
            error: error.message
        });
    }
};