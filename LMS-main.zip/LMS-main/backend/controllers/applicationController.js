const Application = require('../models/Application');
const Activity = require('../models/Activity');
const User = require('../models/User');
const mongoose = require('mongoose');

/**
 * @desc    Create new application
 * @route   POST /api/applications/create
 * @access  Private (Student)
 */
exports.createApplication = async (req, res) => {
    try {
        const { type, subject, message, department } = req.body;
        
        // Get student info from token
        const student = await User.findById(req.user.id);
        
        if (!student) {
            return res.status(404).json({ 
                success: false, 
                message: 'Student not found' 
            });
        }
        
        // Validate message starts with required phrase
        if (!message.toLowerCase().startsWith('it is stated that')) {
            return res.status(400).json({
                success: false,
                message: 'Application must start with "It is stated that..."'
            });
        }
        
        // Validate message length
        if (message.length > 1200) {
            return res.status(400).json({
                success: false,
                message: 'Message must be 1200 characters or less'
            });
        }
        
        // Create application
        const application = new Application({
            studentId: student._id,
            registrationNo: student.registrationNo,
            type,
            subject,
            message,
            department: department || student.department,
            status: 'pending',
            currentHandler: null
        });
        
        await application.save();
        
        // Create initial activity
        const activity = new Activity({
            applicationId: application._id,
            activityNo: 1,
            action: 'submitted',
            forwardedBy: {
                userId: student._id,
                name: student.fullName,
                role: student.role,
                department: student.department
            },
            respondBy: {
                userId: student._id,
                name: student.fullName,
                role: student.role,
                department: student.department
            },
            response: 'Submitted',
            remarks: 'Application submitted by student',
            forwardedTo: null
        });
        
        await activity.save();
        
        res.status(201).json({
            success: true,
            message: 'Application submitted successfully',
            data: {
                applicationNo: application.applicationNo,
                applicationId: application._id,
                subject: application.subject,
                date: application.applicationDate
            }
        });
        
    } catch (error) {
        console.error('Create application error:', error);
        
        // Handle duplicate application number
        if (error.code === 11000) {
            return res.status(400).json({
                success: false,
                message: 'Application number already exists'
            });
        }
        
        res.status(500).json({ 
            success: false, 
            message: 'Server error', 
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};

/**
 * @desc    Get all applications for a student
 * @route   GET /api/applications/student
 * @access  Private (Student)
 */
exports.getStudentApplications = async (req, res) => {
    try {
        const studentId = req.user.id;
        const { status, type, page = 1, limit = 10 } = req.query;
        
        // Build filter
        const filter = { studentId };
        
        if (status && status !== 'all') {
            filter.status = status;
        }
        
        if (type && type !== 'all') {
            filter.type = type;
        }
        
        const skip = (page - 1) * limit;
        
        // Get applications with pagination
        const applications = await Application.find(filter)
            .sort({ applicationDate: -1 })
            .skip(skip)
            .limit(parseInt(limit))
            .select('-__v')
            .lean();
        
        // Get total count
        const total = await Application.countDocuments(filter);
        
        // Calculate pages
        const pages = Math.ceil(total / limit);
        
        res.json({
            success: true,
            data: applications,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                pages
            }
        });
        
    } catch (error) {
        console.error('Get student applications error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Server error'
        });
    }
};

/**
 * @desc    Get single application with activities
 * @route   GET /api/applications/student/:id
 * @access  Private (Student)
 */
exports.getApplicationDetails = async (req, res) => {
    try {
        const { id } = req.params;
        const studentId = req.user.id;
        
        // Validate ObjectId
        if (!mongoose.Types.ObjectId.isValid(id)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid application ID'
            });
        }
        
        // Check if application belongs to student
        const application = await Application.findOne({
            _id: id,
            studentId
        }).select('-__v').lean();
        
        if (!application) {
            return res.status(404).json({
                success: false,
                message: 'Application not found'
            });
        }
        
        // Get all activities for this application
        const activities = await Activity.find({ applicationId: id })
            .sort({ activityNo: 1 })
            .select('-__v -updatedAt')
            .lean();
        
        // Get student info
        const student = await User.findById(studentId)
            .select('fullName registrationNo department year program cgpa sgpa group')
            .lean();
        
        res.json({
            success: true,
            data: {
                application,
                activities,
                student
            }
        });
        
    } catch (error) {
        console.error('Get application details error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Server error'
        });
    }
};

/**
 * @desc    Get applications assigned to staff
 * @route   GET /api/applications/staff
 * @access  Private (Staff/Admin)
 */
exports.getStaffApplications = async (req, res) => {
    try {
        const staffId = req.user.id;
        const userRole = req.user.role;
        const { status, department, page = 1, limit = 10 } = req.query;
        
        let filter = {};
        
        // Different filters based on role
        if (userRole === 'admin') {
            // Admin can see all applications
            if (status && status !== 'all') {
                filter.status = status;
            }
            
            if (department && department !== 'all') {
                filter.department = department;
            }
        } else if (userRole === 'hod' || userRole === 'faculty') {
            // HOD/Faculty can see applications in their department
            filter.department = req.user.department;
            
            if (status && status !== 'all') {
                filter.status = status;
            }
            
            // Also include applications assigned to them
            filter.$or = [
                { 'currentHandler.userId': staffId },
                { status: 'pending' }
            ];
        } else {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }
        
        const skip = (page - 1) * limit;
        
        const applications = await Application.find(filter)
            .sort({ priority: -1, applicationDate: -1 })
            .skip(skip)
            .limit(parseInt(limit))
            .populate('studentId', 'fullName registrationNo department year')
            .select('-__v')
            .lean();
        
        const total = await Application.countDocuments(filter);
        const pages = Math.ceil(total / limit);
        
        res.json({
            success: true,
            data: applications,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                pages
            }
        });
        
    } catch (error) {
        console.error('Get staff applications error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Server error'
        });
    }
};

/**
 * @desc    Update application status (Forward/Approve/Reject/Implement)
 * @route   PUT /api/applications/:id/status
 * @access  Private (Staff/Admin)
 */
exports.updateApplicationStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { action, remarks, forwardTo } = req.body;
        const staffId = req.user.id;
        const staffName = req.user.fullName;
        const staffRole = req.user.role;
        const staffDept = req.user.department;
        
        // Validate ObjectId
        if (!mongoose.Types.ObjectId.isValid(id)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid application ID'
            });
        }
        
        // Validate action
        const validActions = ['forward', 'approve', 'reject', 'implement', 'return'];
        if (!validActions.includes(action)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid action'
            });
        }
        
        const application = await Application.findById(id);
        
        if (!application) {
            return res.status(404).json({
                success: false,
                message: 'Application not found'
            });
        }
        
        // Check authorization
        if (application.currentHandler && 
            application.currentHandler.userId.toString() !== staffId.toString() &&
            staffRole !== 'admin') {
            return res.status(403).json({
                success: false,
                message: 'Not authorized to update this application'
            });
        }
        
        // Get next activity number
        const lastActivity = await Activity.findOne({ applicationId: id })
            .sort({ activityNo: -1 });
        
        const nextActivityNo = lastActivity ? lastActivity.activityNo + 1 : 1;
        
        // Prepare update data
        let updateData = {};
        let responseText = '';
        
        switch (action) {
            case 'forward':
                if (!forwardTo) {
                    return res.status(400).json({
                        success: false,
                        message: 'Forward to user is required'
                    });
                }
                
                const forwardUser = await User.findById(forwardTo);
                if (!forwardUser) {
                    return res.status(404).json({
                        success: false,
                        message: 'Forward user not found'
                    });
                }
                
                updateData.currentHandler = {
                    userId: forwardUser._id,
                    name: forwardUser.fullName,
                    role: forwardUser.role,
                    department: forwardUser.department
                };
                updateData.status = 'under_review';
                updateData.department = forwardUser.department;
                responseText = 'Forwarded';
                break;
                
            case 'approve':
                updateData.currentHandler = null;
                updateData.status = 'approved';
                responseText = 'Approved';
                break;
                
            case 'reject':
                updateData.currentHandler = null;
                updateData.status = 'rejected';
                updateData.closedAt = new Date();
                responseText = 'Rejected';
                break;
                
            case 'implement':
                updateData.currentHandler = null;
                updateData.status = 'implemented';
                updateData.implementedDate = new Date();
                updateData.closedAt = new Date();
                responseText = 'Implemented';
                break;
                
            case 'return':
                updateData.currentHandler = null;
                updateData.status = 'returned';
                responseText = 'Returned';
                break;
        }
        
        updateData.lastUpdated = new Date();
        
        // Update application
        const updatedApplication = await Application.findByIdAndUpdate(
            id,
            { $set: updateData },
            { new: true, runValidators: true }
        ).select('-__v').lean();
        
        if (!updatedApplication) {
            return res.status(404).json({
                success: false,
                message: 'Application not found after update'
            });
        }
        
        // Create activity record
        const activity = new Activity({
            applicationId: id,
            activityNo: nextActivityNo,
            action: action,
            forwardedBy: {
                userId: staffId,
                name: staffName,
                role: staffRole,
                department: staffDept
            },
            respondBy: {
                userId: staffId,
                name: staffName,
                role: staffRole,
                department: staffDept
            },
            response: responseText,
            forwardedTo: action === 'forward' ? {
                userId: forwardTo,
                name: forwardUser.fullName,
                role: forwardUser.role,
                department: forwardUser.department
            } : null,
            remarks: remarks || '',
            isStudentNotified: false
        });
        
        await activity.save();
        
        res.json({
            success: true,
            message: `Application ${action}ed successfully`,
            data: {
                applicationNo: updatedApplication.applicationNo,
                status: updatedApplication.status,
                activityNo: nextActivityNo,
                updatedApplication
            }
        });
        
    } catch (error) {
        console.error('Update application error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Server error',
            error: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
};

/**
 * @desc    Upload attachment for application
 * @route   POST /api/applications/:id/upload
 * @access  Private (Student)
 */
exports.uploadAttachment = async (req, res) => {
    try {
        const { id } = req.params;
        const studentId = req.user.id;
        
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'No file uploaded'
            });
        }
        
        // Check if application belongs to student
        const application = await Application.findOne({
            _id: id,
            studentId
        });
        
        if (!application) {
            return res.status(404).json({
                success: false,
                message: 'Application not found or access denied'
            });
        }
        
        // Add attachment
        application.attachments.push({
            filename: req.file.originalname,
            path: req.file.path,
            mimetype: req.file.mimetype,
            size: req.file.size
        });
        
        await application.save();
        
        res.json({
            success: true,
            message: 'File uploaded successfully',
            data: {
                filename: req.file.originalname,
                size: req.file.size,
                mimetype: req.file.mimetype
            }
        });
        
    } catch (error) {
        console.error('Upload attachment error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'File upload failed'
        });
    }
};

/**
 * @desc    Get application statistics
 * @route   GET /api/applications/stats
 * @access  Private (Student)
 */
exports.getApplicationStats = async (req, res) => {
    try {
        const studentId = req.user.id;
        
        const stats = await Application.aggregate([
            { $match: { studentId: mongoose.Types.ObjectId(studentId) } },
            {
                $group: {
                    _id: '$status',
                    count: { $sum: 1 }
                }
            }
        ]);
        
        // Format stats
        const formattedStats = {
            total: 0,
            pending: 0,
            approved: 0,
            rejected: 0,
            implemented: 0,
            under_review: 0
        };
        
        stats.forEach(stat => {
            formattedStats[stat._id] = stat.count;
            formattedStats.total += stat.count;
        });
        
        res.json({
            success: true,
            data: formattedStats
        });
        
    } catch (error) {
        console.error('Get application stats error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Server error'
        });
    }
};

/**
 * @desc    Delete application (only if pending)
 * @route   DELETE /api/applications/:id
 * @access  Private (Student)
 */
exports.deleteApplication = async (req, res) => {
    try {
        const { id } = req.params;
        const studentId = req.user.id;
        
        // Check if application belongs to student and is pending
        const application = await Application.findOne({
            _id: id,
            studentId,
            status: 'pending'
        });
        
        if (!application) {
            return res.status(404).json({
                success: false,
                message: 'Application not found or cannot be deleted'
            });
        }
        
        // Delete activities first
        await Activity.deleteMany({ applicationId: id });
        
        // Delete application
        await Application.findByIdAndDelete(id);
        
        res.json({
            success: true,
            message: 'Application deleted successfully'
        });
        
    } catch (error) {
        console.error('Delete application error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Server error'
        });
    }
};