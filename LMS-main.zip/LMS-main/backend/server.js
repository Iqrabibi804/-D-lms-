// ---------------------------
// LMS Backend Server (Complete) - FIXED VERSION
// ---------------------------

// ✅ IMPORTS
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const dotenv = require('dotenv');
const path = require('path');
const fs = require('fs');

// ✅ Load environment variables
dotenv.config();

// ✅ Import routes
const authRoutes = require('./routes/auth');
const courseRoutes = require('./routes/courses');
const attendanceRoutes = require('./routes/attendance');
const feeRoutes = require('./routes/fee');
const profileRoutes = require('./routes/profile');
const noticeRoutes = require('./routes/notice');
const applicationRoutes = require('./routes/application');

// ✅ Import middleware
const errorHandler = require('./middleware/errorHandler');

// ✅ Initialize express app
const app = express();

// ---------------------
// 🔒 Security middleware
// ---------------------
app.use(helmet());
app.use(
  cors({
    origin: '*',
    credentials: true,
  })
);

// ✅ Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
});
app.use('/api/', limiter);

// ✅ Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ✅ Create uploads directory
const uploadsDir = 'uploads/applications';
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}

// ✅ Serve uploads (if any)
app.use('/uploads', express.static('uploads'));

// ✅ Serve Frontend Files
app.use(express.static(path.join(__dirname, '../frontend')));

// ✅ Default Frontend Route
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/1.html'));
});

// ✅ Login route (alias for 1.html)
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/1.html'));
});

app.get('/login.html', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/1.html'));
});

// ✅ Applications route
app.get('/applications', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/applications.html'));
});

app.get('/applications.html', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/applications.html'));
});

// ✅ ALL HTML Routes for Navigation
app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/dashboard.html'));
});

app.get('/profile', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/profile.html'));
});

app.get('/courses', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/My course.html'));
});

app.get('/fee', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/fee.html'));
});

app.get('/assignments', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/assessment.html'));
});

app.get('/attendance', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/attendance.html'));
});

app.get('/noticeboard', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/notice board.html'));
});

app.get('/projects', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/assessment.html'));
});

app.get('/exam', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/exam.html'));
});

app.get('/transcript', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/assessment.html'));
});

app.get('/promotions', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/assessment.html'));
});

app.get('/library', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/library.html'));
});

app.get('/awards', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/assessment.html'));
});

app.get('/society', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/assessment.html'));
});

// ✅ Direct file access routes (for backward compatibility)
app.get('/dashboard.html', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/dashboard.html'));
});

app.get('/profile.html', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/profile.html'));
});

app.get('/My course.html', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/My course.html'));
});

app.get('/fee.html', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/fee.html'));
});

app.get('/assessment.html', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/assessment.html'));
});

app.get('/attendance.html', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/attendance.html'));
});

app.get('/notice board.html', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/notice board.html'));
});

app.get('/exam.html', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/exam.html'));
});

app.get('/library.html', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/library.html'));
});

// ✅ API Routes
app.use('/api/auth', authRoutes);
app.use('/api/courses', courseRoutes);
app.use('/api/attendance', attendanceRoutes);
app.use('/api/fees', feeRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/notices', noticeRoutes);
app.use('/api/applications', applicationRoutes); // ✅ Moved here

// ✅ Root API endpoint
app.get('/api', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'LMS API Gateway',
    version: '1.0.0',
    database: mongoose.connection.readyState === 1 ? 'Connected' : 'Disconnected',
    endpoints: {
      auth: '/api/auth',
      courses: '/api/courses',
      attendance: '/api/attendance',
      fees: '/api/fees',
      profile: '/api/profile',
      notices: '/api/notices',
      applications: '/api/applications',
      health: '/api/health',
    },
    frontend_routes: {
      login: '/login',
      applications: '/applications',
      dashboard: '/dashboard',
      profile: '/profile',
      courses: '/courses',
      fee: '/fee',
      assignments: '/assignments',
      attendance: '/attendance',
      noticeboard: '/noticeboard',
      exam: '/exam',
      library: '/library'
    },
    timestamp: new Date().toISOString(),
  });
});

// ✅ Health Check
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'LMS Backend is running',
    database: mongoose.connection.readyState === 1 ? 'Connected' : 'Disconnected',
    frontend_files: [
      '1.html', 
      'dashboard.html', 
      'profile.html', 
      'My course.html', 
      'fee.html', 
      'assessment.html', 
      'attendance.html', 
      'notice board.html', 
      'exam.html', 
      'library.html',
      'applications.html'
    ],
    timestamp: new Date().toISOString(),
  });
});

// ✅ Error Handling Middleware
app.use(errorHandler);

// ✅ Connect MongoDB and Start Server
mongoose
  .connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/lms_database', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log('✅ MongoDB Connected Successfully');

    const PORT = process.env.PORT || 5000;
    app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT}`);
      console.log(`🌐 API: http://localhost:${PORT}/api`);
      console.log(`🏥 Health: http://localhost:${PORT}/api/health`);
      console.log(`💻 Frontend: http://localhost:${PORT}`);
      console.log('\n📁 Available Routes:');
      console.log(`   🔐 Login: http://localhost:${PORT}/`);
      console.log(`   🔐 Login (alias): http://localhost:${PORT}/login`);
      console.log(`   📋 Applications: http://localhost:${PORT}/applications`);
      console.log(`   📊 Dashboard: http://localhost:${PORT}/dashboard`);
      console.log(`   👤 Profile: http://localhost:${PORT}/profile`);
      console.log(`   📚 Courses: http://localhost:${PORT}/courses`);
      console.log(`   💰 Fee: http://localhost:${PORT}/fee`);
      console.log(`   📝 Assignments: http://localhost:${PORT}/assignments`);
      console.log(`   📅 Attendance: http://localhost:${PORT}/attendance`);
      console.log(`   📢 Notice Board: http://localhost:${PORT}/noticeboard`);
      console.log(`   📝 Exam: http://localhost:${PORT}/exam`);
      console.log(`   📚 Library: http://localhost:${PORT}/library`);
      console.log('\n✅ Server started successfully!');
    });
  })
  .catch((error) => {
    console.error('❌ MongoDB Connection Error:', error);
    console.log('⚠️ Starting server without database connection...');

    const PORT = process.env.PORT || 5000;
    app.listen(PORT, () => {
      console.log(`🚀 Server running on port ${PORT} (MOCK MODE)`);
      console.log(`🌐 API: http://localhost:${PORT}/api`);
      console.log(`🏥 Health: http://localhost:${PORT}/api/health`);
      console.log(`💻 Frontend: http://localhost:${PORT}`);
      console.log(`   🔐 Login: http://localhost:${PORT}/`);
      console.log(`   📋 Applications: http://localhost:${PORT}/applications`);
    });
  });

// ✅ Handle Unhandled Rejections
process.on('unhandledRejection', (err) => {
  console.error('❌ Unhandled Rejection:', err);
  process.exit(1);
});
// Test endpoint
app.get('/api/test', (req, res) => {
    res.json({
        success: true,
        message: 'Backend is working!',
        timestamp: new Date().toISOString()
    });
});