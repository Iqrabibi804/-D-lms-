// routes/courses.js - SIMPLIFIED VERSION
const express = require('express');
const router = express.Router();

// @desc    Get all courses (TEST VERSION - No auth)
// @route   GET /api/courses
// @access  Public (for testing)
router.get('/', (req, res) => {
    res.status(200).json({
        success: true,
        message: 'Courses endpoint is working',
        data: [
            { id: 1, title: 'Mathematics', code: 'MATH101', credits: 3 },
            { id: 2, title: 'Physics', code: 'PHY101', credits: 4 },
            { id: 3, title: 'Programming', code: 'CSE101', credits: 3 }
        ]
    });
});

// @desc    Create a course (TEST VERSION - No auth)
// @route   POST /api/courses
// @access  Public (for testing)
router.post('/', (req, res) => {
    const course = req.body;
    res.status(201).json({
        success: true,
        message: 'Course created successfully',
        data: { ...course, id: Date.now() }
    });
});

module.exports = router;