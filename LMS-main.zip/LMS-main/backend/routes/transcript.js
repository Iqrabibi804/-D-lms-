const express = require('express');
const router = express.Router();
const Transcript = require('../models/Transcript');
const authMiddleware = require('../middleware/auth');

// All routes are protected
router.use(authMiddleware);

// @desc    Get student transcripts
// @route   GET /api/transcripts
router.get('/', async (req, res) => {
    try {
        const transcripts = await Transcript.find({
            student: req.user.id,
            isPublished: true
        }).sort({ semester: -1 });
        
        res.status(200).json({
            success: true,
            count: transcripts.length,
            transcripts
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: error.message 
        });
    }
});

// @desc    Get transcript by semester
// @route   GET /api/transcripts/semester/:semester
router.get('/semester/:semester', async (req, res) => {
    try {
        const transcript = await Transcript.findOne({
            student: req.user.id,
            semester: parseInt(req.params.semester),
            isPublished: true
        }).populate('courses.course', 'courseCode courseName credits');
        
        if (!transcript) {
            return res.status(404).json({
                success: false,
                message: 'Transcript not found for this semester'
            });
        }
        
        res.status(200).json({
            success: true,
            transcript
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: error.message 
        });
    }
});

// @desc    Get complete academic record
// @route   GET /api/transcripts/complete
router.get('/complete', async (req, res) => {
    try {
        const transcripts = await Transcript.find({
            student: req.user.id,
            isPublished: true
        }).populate('courses.course', 'courseCode courseName credits')
          .sort({ semester: 1 });
        
        if (transcripts.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'No transcripts found'
            });
        }
        
        // Calculate overall statistics
        let totalCredits = 0;
        let earnedCredits = 0;
        let totalGradePoints = 0;
        
        transcripts.forEach(transcript => {
            transcript.courses.forEach(course => {
                totalCredits += course.credits || 0;
                if (course.grade && course.grade !== 'F' && course.grade !== 'I' && course.grade !== 'W') {
                    earnedCredits += course.credits || 0;
                    // Convert grade to points
                    const gradePoints = {
                        'A': 10, 'B': 8, 'C': 6, 'D': 4, 'F': 0
                    };
                    totalGradePoints += (course.credits || 0) * (gradePoints[course.grade] || 0);
                }
            });
        });
        
        const cgpa = earnedCredits > 0 ? (totalGradePoints / earnedCredits).toFixed(2) : 0;
        
        res.status(200).json({
            success: true,
            transcripts,
            statistics: {
                totalSemesters: transcripts.length,
                totalCredits,
                earnedCredits,
                cgpa: parseFloat(cgpa),
                completionPercentage: (earnedCredits / totalCredits * 100).toFixed(2)
            }
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: error.message 
        });
    }
});

// @desc    Verify transcript
// @route   GET /api/transcripts/verify/:code
router.get('/verify/:code', async (req, res) => {
    try {
        const transcript = await Transcript.findOne({
            verificationCode: req.params.code
        }).populate('student', 'fullName studentId department year');
        
        if (!transcript) {
            return res.status(404).json({
                success: false,
                message: 'Invalid verification code'
            });
        }
        
        res.status(200).json({
            success: true,
            isValid: true,
            student: {
                name: transcript.student.fullName,
                studentId: transcript.student.studentId,
                department: transcript.student.department,
                year: transcript.student.year
            },
            transcript: {
                semester: transcript.semester,
                academicYear: transcript.academicYear,
                sgpa: transcript.sgpa,
                cgpa: transcript.cgpa,
                publishedDate: transcript.publishedDate,
                verificationCode: transcript.verificationCode
            }
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: error.message 
        });
    }
});

// @desc    Download transcript (mock endpoint)
// @route   GET /api/transcripts/:id/download
router.get('/:id/download', async (req, res) => {
    try {
        const transcript = await Transcript.findById(req.params.id);
        
        if (!transcript || transcript.student.toString() !== req.user.id) {
            return res.status(404).json({
                success: false,
                message: 'Transcript not found'
            });
        }
        
        // In a real application, you would generate a PDF here
        // For now, returning the transcript data
        res.status(200).json({
            success: true,
            message: 'Transcript ready for download',
            downloadUrl: `/api/transcripts/${transcript._id}/pdf`, // Mock URL
            transcript
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: error.message 
        });
    }
});

module.exports = router;