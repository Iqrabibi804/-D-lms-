const express = require('express');
const router = express.Router();
exports.router = router;
const Library = require('../models/library');
const authMiddleware = require('../middleware/auth');

// All routes are protected
router.use(authMiddleware);

// @desc    Get all books
// @route   GET /api/library
router.get('/', async (req, res) => {
    try {
        const { category, author, title, available } = req.query;
        
        let query = {};
        
        if (category) query.category = category;
        if (author) query.author = { $regex: author, $options: 'i' };
        if (title) query.title = { $regex: title, $options: 'i' };
        if (available === 'true') query.availableCopies = { $gt: 0 };
        
        const books = await Library.find(query)
            .sort({ title: 1 })
            .select('-borrowedBy');
        
        res.status(200).json({
            success: true,
            count: books.length,
            books
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// @desc    Get book details
// @route   GET /api/library/:id
router.get('/:id', async (req, res) => {
    try {
        const book = await Library.findById(req.params.id)
            .populate('borrowedBy.student', 'fullName studentId');
        
        if (!book) {
            return res.status(404).json({ 
                success: false, 
                message: 'Book not found' 
            });
        }
        
        res.status(200).json({
            success: true,
            book
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// @desc    Borrow a book
// @route   POST /api/library/:id/borrow
router.post('/:id/borrow', async (req, res) => {
    try {
        const book = await Library.findById(req.params.id);
        
        if (!book) {
            return res.status(404).json({ 
                success: false, 
                message: 'Book not found' 
            });
        }
        
        if (book.availableCopies === 0) {
            return res.status(400).json({ 
                success: false, 
                message: 'No copies available' 
            });
        }
        
        // Check if student already borrowed this book
        const alreadyBorrowed = book.borrowedBy.some(
            record => record.student.toString() === req.user.id && record.status === 'borrowed'
        );
        
        if (alreadyBorrowed) {
            return res.status(400).json({ 
                success: false, 
                message: 'You already borrowed this book' 
            });
        }
        
        // Calculate due date (14 days from now)
        const dueDate = new Date();
        dueDate.setDate(dueDate.getDate() + 14);
        
        // Add borrowing record
        book.borrowedBy.push({
            student: req.user.id,
            borrowDate: new Date(),
            dueDate: dueDate,
            status: 'borrowed'
        });
        
        book.availableCopies -= 1;
        if (book.availableCopies === 0) {
            book.isAvailable = false;
        }
        
        await book.save();
        
        res.status(200).json({
            success: true,
            message: 'Book borrowed successfully',
            dueDate: dueDate.toISOString().split('T')[0]
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// @desc    Return a book
// @route   POST /api/library/:id/return
router.post('/:id/return', async (req, res) => {
    try {
        const book = await Library.findById(req.params.id);
        
        if (!book) {
            return res.status(404).json({ 
                success: false, 
                message: 'Book not found' 
            });
        }
        
        // Find borrowing record
        const borrowingRecord = book.borrowedBy.find(
            record => record.student.toString() === req.user.id && record.status === 'borrowed'
        );
        
        if (!borrowingRecord) {
            return res.status(400).json({ 
                success: false, 
                message: 'You have not borrowed this book' 
            });
        }
        
        // Calculate fine if overdue
        const returnDate = new Date();
        const dueDate = new Date(borrowingRecord.dueDate);
        let fine = 0;
        
        if (returnDate > dueDate) {
            const daysOverdue = Math.ceil((returnDate - dueDate) / (1000 * 60 * 60 * 24));
            fine = daysOverdue * 10; // ₹10 per day fine
        }
        
        // Update borrowing record
        borrowingRecord.returnDate = returnDate;
        borrowingRecord.fine = fine;
        borrowingRecord.status = 'returned';
        
        book.availableCopies += 1;
        book.isAvailable = true;
        
        await book.save();
        
        res.status(200).json({
            success: true,
            message: 'Book returned successfully',
            fine: fine
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

// @desc    Get borrowed books by student
// @route   GET /api/library/my-books
router.get('/my/borrowed', async (req, res) => {
    try {
        const books = await Library.find({
            'borrowedBy.student': req.user.id,
            'borrowedBy.status': 'borrowed'
        }).select('title author isbn dueDate');
        
        // Add due date and fine calculation
        const borrowedBooks = books.map(book => {
            const borrowingRecord = book.borrowedBy.find(
                record => record.student.toString() === req.user.id && record.status === 'borrowed'
            );
            
            const today = new Date();
            const dueDate = new Date(borrowingRecord.dueDate);
            let daysRemaining = Math.ceil((dueDate - today) / (1000 * 60 * 60 * 24));
            daysRemaining = daysRemaining > 0 ? daysRemaining : 0;
            
            let fine = 0;
            if (today > dueDate) {
                const daysOverdue = Math.ceil((today - dueDate) / (1000 * 60 * 60 * 24));
                fine = daysOverdue * 10;
            }
            
            return {
                _id: book._id,
                title: book.title,
                author: book.author,
                isbn: book.isbn,
                borrowDate: borrowingRecord.borrowDate,
                dueDate: borrowingRecord.dueDate,
                daysRemaining: daysRemaining,
                fine: fine,
                status: daysRemaining > 0 ? 'active' : 'overdue'
            };
        });
        
        res.status(200).json({
            success: true,
            count: borrowedBooks.length,
            books: borrowedBooks
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});

