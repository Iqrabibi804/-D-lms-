const express = require('express');
const router = express.Router();

// @desc    Get all notices
// @route   GET /api/notices
// @access  Private
router.get('/', (req, res) => {
    res.status(200).json({
        success: true,
        message: 'Notices retrieved successfully',
        data: [
            { 
                id: 1, 
                title: 'Semester Exam Schedule', 
                content: 'Final exams start from December 15th',
                date: '2024-12-01',
                category: 'Academic'
            },
            { 
                id: 2, 
                title: 'Library Holiday', 
                content: 'Library will be closed on December 25th',
                date: '2024-11-28',
                category: 'General'
            }
        ]
    });
});

module.exports = router;