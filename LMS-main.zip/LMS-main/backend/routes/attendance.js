const express = require('express');
const router = express.Router();

// @desc    Get user attendance
// @route   GET /api/attendance
// @access  Private
router.get('/', (req, res) => {
    res.status(200).json({
        success: true,
        message: 'Attendance retrieved successfully',
        data: [
            {
                course: "Mathematics",
                code: "MATH101",
                totalClasses: 30,
                attended: 28,
                percentage: 93.3
            },
            {
                course: "Physics",
                code: "PHY101",
                totalClasses: 28,
                attended: 26,
                percentage: 92.9
            }
        ]
    });
});

module.exports = router;