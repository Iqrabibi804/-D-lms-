const express = require('express');
const router = express.Router();
const assessmentController = require('../controllers/assessmentController');
const authMiddleware = require('../middleware/auth');

// All routes are protected
router.use(authMiddleware);

// Student routes
router.get('/', assessmentController.getAssessments);
router.get('/:id', assessmentController.getAssessmentDetails);
router.post('/:id/submit', assessmentController.submitAssessment);

module.exports = router;