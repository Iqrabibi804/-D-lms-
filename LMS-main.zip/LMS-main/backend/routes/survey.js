const express = require('express');
const router = express.Router();
const surveyController = require('../controllers/surveyController');
const authMiddleware = require('../middleware/auth');

// Student routes
router.post('/submit', authMiddleware, surveyController.submitSurvey);
router.get('/student/history', authMiddleware, surveyController.getStudentSurveys);
router.get('/check', authMiddleware, surveyController.checkSurveyAvailability);

// Instructor routes
router.get('/instructor/:instructorId?', authMiddleware, surveyController.getInstructorSurveys);

// Admin routes
router.post('/admin/activate', authMiddleware, surveyController.activateSurvey);

module.exports = router;