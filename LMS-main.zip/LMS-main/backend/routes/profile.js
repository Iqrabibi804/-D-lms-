const express = require('express');
const router = express.Router();

// @desc    Get user profile
// @route   GET /api/profile
// @access  Private
router.get('/', (req, res) => {
    res.status(200).json({
        success: true,
        message: 'Profile retrieved successfully',
        data: {
            _id: "mock-user-id",
            studentId: "2023CSE045",
            fullName: "Alpha Khan",
            email: "admin@lms.com",
            department: "Computer Science",
            year: "3rd Year",
            role: "student",
            profileImage: "default.png",
            phone: "+1234567890",
            address: "123 Main Street, City"
        }
    });
});

module.exports = router;