const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

// Simple test route
router.get('/test', (req, res) => {
    res.json({
        success: true,
        message: 'Auth route is working'
    });
});

// Register route
router.post('/register', async (req, res) => {
    try {
        const { studentId, fullName, email, password, department, year } = req.body;
        
        // Mock user creation (without database)
        const user = {
            _id: 'mock-id-' + Date.now(),
            studentId,
            fullName,
            email,
            department,
            year,
            role: 'student'
        };
        
        // Generate token
        const token = jwt.sign(
            { id: user._id, role: user.role },
            process.env.JWT_SECRET || 'test_secret',
            { expiresIn: '7d' }
        );
        
        res.status(201).json({
            success: true,
            message: 'User registered successfully (MOCK)',
            token,
            user
        });
        
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: error.message 
        });
    }
});

// Login route
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        
        // Mock login (accept any credentials for testing)
        const user = {
            _id: 'mock-user-id',
            studentId: '2023CSE045',
            fullName: 'Alpha Khan',
            email: email,
            department: 'Computer Science',
            year: '3rd Year',
            role: 'student',
            profileImage: 'default.png'
        };
        
        // Generate token
        const token = jwt.sign(
            { id: user._id, role: user.role },
            process.env.JWT_SECRET || 'test_secret',
            { expiresIn: '7d' }
        );
        
        res.json({
            success: true,
            message: 'Login successful (MOCK)',
            token,
            user
        });
        
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: error.message 
        });
    }
});

module.exports = router;