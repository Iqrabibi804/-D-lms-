const express = require('express');
const router = express.Router();
const applicationController = require('../controllers/applicationController');
const auth = require('../middleware/auth');
const multer = require('multer');
const path = require('path');

// Configure multer for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/applications/');
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({
    storage: storage,
    limits: { 
        fileSize: 5 * 1024 * 1024 // 5MB limit
    },
    fileFilter: function (req, file, cb) {
        // Allowed file types
        const allowedTypes = /jpeg|jpg|png|pdf|doc|docx/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);
        
        if (mimetype && extname) {
            return cb(null, true);
        } else {
            cb(new Error('Only images (JPEG, JPG, PNG) and documents (PDF, DOC, DOCX) are allowed'));
        }
    }
});

// ================= STUDENT ROUTES =================
// Create new application
router.post('/create', auth, applicationController.createApplication);

// Get all applications for student
router.get('/student', auth, applicationController.getStudentApplications);

// Get single application details
router.get('/student/:id', auth, applicationController.getApplicationDetails);

// Upload attachment
router.post('/:id/upload', auth, upload.single('attachment'), applicationController.uploadAttachment);

// Get application statistics
router.get('/stats', auth, applicationController.getApplicationStats);

// Delete application (only if pending)
router.delete('/:id', auth, applicationController.deleteApplication);

// ================= STAFF ROUTES =================
// Get applications for staff
router.get('/staff', auth, applicationController.getStaffApplications);

// Update application status
router.put('/:id/status', auth, applicationController.updateApplicationStatus);

// ================= ADMIN ROUTES =================
// Get all applications (admin only)
router.get('/all', auth, (req, res, next) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({
            success: false,
            message: 'Access denied. Admin only.'
        });
    }
    next();
}, async (req, res) => {
    try {
        const { page = 1, limit = 20, department, status } = req.query;
        
        const filter = {};
        if (department && department !== 'all') filter.department = department;
        if (status && status !== 'all') filter.status = status;
        
        const skip = (page - 1) * limit;
        
        const applications = await Application.find(filter)
            .sort({ applicationDate: -1 })
            .skip(skip)
            .limit(parseInt(limit))
            .populate('studentId', 'fullName registrationNo department')
            .select('-__v')
            .lean();
        
        const total = await Application.countDocuments(filter);
        
        res.json({
            success: true,
            data: applications,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total,
                pages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        console.error('Get all applications error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Server error'
        });
    }
});

// Get application by application number
router.get('/number/:appNo', auth, async (req, res) => {
    try {
        const { appNo } = req.params;
        
        const application = await Application.findOne({ applicationNo: appNo })
            .populate('studentId', 'fullName registrationNo department year program')
            .select('-__v')
            .lean();
        
        if (!application) {
            return res.status(404).json({
                success: false,
                message: 'Application not found'
            });
        }
        
        // Check authorization
        if (req.user.role === 'student' && 
            application.studentId._id.toString() !== req.user.id.toString()) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }
        
        // Get activities
        const activities = await Activity.find({ applicationId: application._id })
            .sort({ activityNo: 1 })
            .select('-__v -updatedAt')
            .lean();
        
        res.json({
            success: true,
            data: {
                application,
                activities
            }
        });
        
    } catch (error) {
        console.error('Get application by number error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Server error'
        });
    }
});

// Health check endpoint
router.get('/health', (req, res) => {
    res.json({
        success: true,
        message: 'Applications API is running',
        timestamp: new Date().toISOString(),
        endpoints: {
            student: '/student',
            staff: '/staff',
            create: '/create',
            upload: '/:id/upload',
            stats: '/stats'
        }
    });
});

module.exports = router;






        