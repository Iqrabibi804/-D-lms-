const express = require('express');
const router = express.Router();

// @desc    Get fee details
// @route   GET /api/fees
// @access  Private
router.get('/', (req, res) => {
    res.status(200).json({
        success: true,
        message: 'Fee details retrieved successfully',
        data: {
            totalFee: 50000,
            paid: 45000,
            due: 5000,
            lastPayment: "2024-11-15",
            nextDueDate: "2024-12-31",
            transactions: [
                { date: "2024-11-15", amount: 15000, mode: "Online" },
                { date: "2024-09-10", amount: 30000, mode: "Bank Transfer" }
            ]
        }
    });
});

module.exports = router;