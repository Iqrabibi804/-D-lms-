
    // Sample Data
    const libraryData = {
      books: [
        {
          id: 1,
          title: "Introduction to Algorithms",
          author: "Thomas H. Cormen",
          isbn: "978-0262033848",
          category: "cs",
          totalCopies: 8,
          availableCopies: 3,
          borrowedBy: [
            { studentId: "2023CSE012", name: "John Doe", dueDate: "2025-12-20", borrowedDate: "2025-12-06" },
            { studentId: "2023CSE023", name: "Jane Smith", dueDate: "2025-12-22", borrowedDate: "2025-12-06" },
            { studentId: "2023CSE034", name: "Bob Wilson", dueDate: "2025-12-25", borrowedDate: "2025-12-05" },
            { studentId: "2023CSE041", name: "Alice Brown", dueDate: "2025-12-18", borrowedDate: "2025-12-04" },
            { studentId: "2023CSE056", name: "Charlie Davis", dueDate: "2025-12-19", borrowedDate: "2025-12-05" }
          ],
          publisher: "MIT Press",
          year: 2009,
          location: "CS Section, Shelf 1A-45",
          popularity: 95,
          description: "Comprehensive guide to algorithms and data structures used in computer programming."
        },
        {
          id: 2,
          title: "Clean Code: A Handbook of Agile Software Craftsmanship",
          author: "Robert C. Martin",
          isbn: "978-0132350884",
          category: "cs",
          totalCopies: 5,
          availableCopies: 1,
          borrowedBy: [
            { studentId: "2023CSE067", name: "David Miller", dueDate: "2025-12-21", borrowedDate: "2025-12-06" },
            { studentId: "2023CSE078", name: "Eva Garcia", dueDate: "2025-12-23", borrowedDate: "2025-12-05" },
            { studentId: "2023CSE089", name: "Frank Wilson", dueDate: "2025-12-26", borrowedDate: "2025-12-04" },
            { studentId: "2023CSE091", name: "Grace Lee", dueDate: "2025-12-17", borrowedDate: "2025-12-03" }
          ],
          publisher: "Prentice Hall",
          year: 2008,
          location: "CS Section, Shelf 1B-12",
          popularity: 88,
          description: "Essential reading for software developers who want to write maintainable, readable code."
        },
        {
          id: 3,
          title: "The Pragmatic Programmer",
          author: "Andrew Hunt, David Thomas",
          isbn: "978-0201616224",
          category: "cs",
          totalCopies: 6,
          availableCopies: 4,
          borrowedBy: [
            { studentId: "2023CSE102", name: "Henry Taylor", dueDate: "2025-12-24", borrowedDate: "2025-12-06" },
            { studentId: "2023CSE113", name: "Isabella Clark", dueDate: "2025-12-27", borrowedDate: "2025-12-05" }
          ],
          publisher: "Addison-Wesley",
          year: 1999,
          location: "CS Section, Shelf 2A-08",
          popularity: 92,
          description: "Classic book on software engineering best practices and career advice for programmers."
        }
      ],
      borrowedBooks: [
        {
          id: 101,
          bookId: 1,
          bookTitle: "Introduction to Algorithms",
          author: "Thomas H. Cormen",
          borrowedDate: "2025-12-05",
          dueDate: "2025-12-19",
          returned: false,
          fine: 0,
          purpose: "Data Structures course project"
        },
        {
          id: 102,
          bookId: 3,
          bookTitle: "The Pragmatic Programmer",
          author: "Andrew Hunt, David Thomas",
          borrowedDate: "2025-12-10",
          dueDate: "2025-12-24",
          returned: false,
          fine: 0,
          purpose: "Software Engineering assignment"
        }
      ],
      libraryEntry: {
        lastEntry: "2025-12-05 14:10:00",
        entries: [
          { date: "2025-12-05", time: "14:10:00", status: "Entered" },
          { date: "2025-12-04", time: "10:30:00", status: "Entered" },
          { date: "2025-12-04", time: "17:45:00", status: "Exited" }
        ]
      },
      discussionRoom: {
        name: "Collaboration Room",
        capacity: 8,
        currentOccupancy: 0,
        isAvailable: true,
        bookings: [],
        nextAvailable: "Now"
      }
    };

    // Current Student
    const currentStudent = {
      id: "2023CSE045",
      name: "Alpha Khan",
      department: "Computer Science",
      year: "3rd Year",
      email: "alpha.khan@university.edu",
      maxBooks: 4,
      currentlyBorrowed: 2
    };

    // Initialize
    function init() {
      updateDateTime();
      loadStudentInfo();
      renderBooks();
      renderMyBooks();
      updateRoomStatus();
      setupEventListeners();
      
      // Simulate external scanner entry
      simulateScannerEntry();
    }

    // Update date and time
    function updateDateTime() {
      const now = new Date();
      
      // Format date
      const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
      const dateString = now.toLocaleDateString('en-US', dateOptions);
      document.getElementById('currentDate').textContent = dateString;
      
      // Format time
      const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true };
      const timeString = now.toLocaleTimeString('en-US', timeOptions);
      document.getElementById('currentTime').textContent = timeString;
      
      // Update every second
      setTimeout(updateDateTime, 1000);
    }

    // Load student info
    function loadStudentInfo() {
      document.getElementById('studentId').textContent = currentStudent.id;
      document.getElementById('studentName').textContent = currentStudent.name;
      document.getElementById('studentDept').textContent = currentStudent.department;
      
      // Set last entry time
      const lastEntry = libraryData.libraryEntry.lastEntry;
      const entryTime = new Date(lastEntry);
      const timeString = entryTime.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      });
      document.getElementById('lastEntryTime').textContent = `Today ${timeString}`;
    }

    // Simulate scanner entry
    function simulateScannerEntry() {
      // This function simulates the external scanner sending data
      console.log("Scanner: Student entered library at", new Date().toLocaleString());
      
      // Update entry record
      const now = new Date();
      libraryData.libraryEntry.lastEntry = now.toISOString();
      libraryData.libraryEntry.entries.unshift({
        date: now.toISOString().split('T')[0],
        time: now.toTimeString().split(' ')[0],
        status: "Entered"
      });
      
      // Update display
      const timeString = now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      });
      document.getElementById('lastEntryTime').textContent = `Today ${timeString}`;
    }

    // Render books
    function renderBooks() {
      const booksGrid = document.getElementById('booksGrid');
      booksGrid.innerHTML = '';
      
      if (libraryData.books.length === 0) {
        booksGrid.innerHTML = `
          <div class="w-100 text-center" style="grid-column: 1 / -1; padding: 60px; color: #546e7a;">
            <div style="font-size: 4rem; margin-bottom: 20px;">📚</div>
            <h3 style="color: #37474f; margin-bottom: 10px;">No books available</h3>
            <p>Please check back later</p>
          </div>
        `;
        return;
      }
      
      libraryData.books.forEach(book => {
        const isAvailable = book.availableCopies > 0;
        const canBorrow = isAvailable && currentStudent.currentlyBorrowed < currentStudent.maxBooks;
        
        const bookCard = document.createElement('div');
        bookCard.className = 'book-card';
        bookCard.innerHTML = `
          <div class="book-status ${isAvailable ? 'status-available' : 'status-borrowed'}">
            ${isAvailable ? 'Available' : 'All Borrowed'}
          </div>
          
          <div class="book-header">
            <div class="book-cover" style="background: linear-gradient(135deg, ${getCategoryColor(book.category)});">
              ${book.title.charAt(0)}
            </div>
            <div class="book-info">
              <h3 class="book-title">${book.title}</h3>
              <p class="book-author">by ${book.author}</p>
              <div class="book-meta">
                <span class="meta-item">📚 ${getCategoryName(book.category)}</span>
                <span class="meta-item">📅 ${book.year}</span>
                <span class="meta-item">📍 ${book.location}</span>
              </div>
            </div>
          </div>
          
          <div class="book-details-grid">
            <div class="detail-card">
              <div class="detail-number">${book.availableCopies}</div>
              <div class="detail-text">Available Copies</div>
            </div>
            <div class="detail-card">
              <div class="detail-number">${book.totalCopies}</div>
              <div class="detail-text">Total Copies</div>
            </div>
            <div class="detail-card">
              <div class="detail-number">${book.borrowedBy.length}</div>
              <div class="detail-text">Currently Borrowed</div>
            </div>
            <div class="detail-card">
              <div class="detail-number">${book.popularity}%</div>
              <div class="detail-text">Popularity</div>
            </div>
          </div>
          
          ${book.borrowedBy.length > 0 ? `
            <div class="borrower-info">
              <h4>👥 Currently With:</h4>
              <div class="borrower-list">
                ${book.borrowedBy.slice(0, 3).map(student => `
                  <div class="borrower-item">
                    <span>${student.name} (${student.studentId})</span>
                    <span>Due: ${formatDate(student.dueDate)}</span>
                  </div>
                `).join('')}
                ${book.borrowedBy.length > 3 ? `
                  <div class="borrower-item">
                    <span>... and ${book.borrowedBy.length - 3} more</span>
                    <span><button onclick="viewAllBorrowers(${book.id})" style="background:none;border:none;color:#1a237e;cursor:pointer;text-decoration:underline;">View All</button></span>
                  </div>
                ` : ''}
              </div>
            </div>
          ` : ''}
          
          <div class="book-actions">
            <button class="action-btn details-btn" onclick="showBookDetails(${book.id})">
              <span>📖</span> Details
            </button>
            <button class="action-btn borrow-btn" onclick="borrowBook(${book.id})" ${!canBorrow ? 'disabled' : ''}>
              <span>📥</span> ${isAvailable ? 'Borrow' : 'Waitlist'}
            </button>
          </div>
        `;
        booksGrid.appendChild(bookCard);
      });
    }

    // Render my books
    function renderMyBooks() {
      const myBooksGrid = document.getElementById('myBooksGrid');
      myBooksGrid.innerHTML = '';
      
      if (libraryData.borrowedBooks.filter(book => !book.returned).length === 0) {
        myBooksGrid.innerHTML = `
          <div class="w-100 text-center" style="grid-column: 1 / -1; padding: 60px; color: #546e7a;">
            <div style="font-size: 4rem; margin-bottom: 20px;">📖</div>
            <h3 style="color: #37474f; margin-bottom: 10px;">No books borrowed</h3>
            <p>You haven't borrowed any books yet</p>
            <button class="search-button mt-20" onclick="switchTab('search')">
              <span>🔍</span> Browse Books
            </button>
          </div>
        `;
        return;
      }
      
      let totalBorrowed = 0;
      let dueSoonCount = 0;
      let totalFine = 0;
      
      libraryData.borrowedBooks.forEach(book => {
        if (!book.returned) {
          totalBorrowed++;
          
          const dueDate = new Date(book.dueDate);
          const today = new Date();
          const daysDiff = Math.ceil((dueDate - today) / (1000 * 60 * 60 * 24));
          
          if (daysDiff <= 3 && daysDiff >= 0) {
            dueSoonCount++;
          }
          
          if (daysDiff < 0) {
            const overdueDays = Math.abs(daysDiff);
            const fine = overdueDays * 10;
            totalFine += fine;
          }
          
          const bookCard = document.createElement('div');
          bookCard.className = 'book-card';
          bookCard.innerHTML = `
            <div class="book-status ${daysDiff < 0 ? 'status-borrowed' : daysDiff <= 3 ? 'status-reserved' : 'status-available'}">
              ${daysDiff < 0 ? 'Overdue' : daysDiff <= 3 ? 'Due Soon' : 'On Time'}
            </div>
            
            <div class="book-header">
              <div class="book-cover" style="background: linear-gradient(135deg, #1a237e 0%, #283593 100%);">
                ${book.bookTitle.charAt(0)}
              </div>
              <div class="book-info">
                <h3 class="book-title">${book.bookTitle}</h3>
                <p class="book-author">by ${book.author}</p>
                <div class="book-meta">
                  <span class="meta-item">📅 Borrowed: ${formatDate(book.borrowedDate)}</span>
                  <span class="meta-item">⏰ Due: ${formatDate(book.dueDate)}</span>
                </div>
              </div>
            </div>
            
            <div class="book-details-grid">
              <div class="detail-card">
                <div class="detail-number">${daysDiff >= 0 ? daysDiff : Math.abs(daysDiff)}</div>
                <div class="detail-text">${daysDiff >= 0 ? 'Days Left' : 'Days Overdue'}</div>
              </div>
              <div class="detail-card">
                <div class="detail-number">${book.purpose.substring(0, 15)}...</div>
                <div class="detail-text">Purpose</div>
              </div>
            </div>
            
            <div class="borrower-info" style="background: ${daysDiff < 0 ? '#ffebee' : '#e8f5e8'}; border-left-color: ${daysDiff < 0 ? '#f44336' : '#4caf50'};">
              <h4>${daysDiff < 0 ? '⚠️ Overdue Notice' : '📅 Return Schedule'}</h4>
              <div class="borrower-list">
                <div class="borrower-item">
                  <span>Fine Amount:</span>
                  <span style="color: ${daysDiff < 0 ? '#f44336' : '#4caf50'}; font-weight: 600;">
                    ${daysDiff < 0 ? `₹${Math.abs(daysDiff) * 10}` : 'None'}
                  </span>
                </div>
                <div class="borrower-item">
                  <span>Return By:</span>
                  <span>${formatDate(book.dueDate)}</span>
                </div>
              </div>
            </div>
            
            <div class="book-actions">
              <button class="action-btn return-btn" onclick="returnBook(${book.id})">
                <span>📤</span> Return Book
              </button>
              <button class="action-btn details-btn" onclick="extendDueDate(${book.id})">
                <span>📅</span> Extend Due Date
              </button>
            </div>
          `;
          myBooksGrid.appendChild(bookCard);
        }
      });
      
      // Update stats
      document.getElementById('totalBorrowed').textContent = totalBorrowed;
      document.getElementById('dueSoon').textContent = dueSoonCount;
      document.getElementById('totalFine').textContent = `₹${totalFine}`;
      
      // Show notifications
      if (dueSoonCount > 0) {
        showNotification(`You have ${dueSoonCount} book(s) due in 3 days or less. Please return on time to avoid fines.`, 'warning');
      }
      
      if (totalFine > 0) {
        showNotification(`You have overdue books with total fine of ₹${totalFine}. Please return immediately.`, 'danger');
      }
    }

    // Show book details
    function showBookDetails(bookId) {
      const book = libraryData.books.find(b => b.id === bookId);
      if (!book) return;
      
      const content = document.getElementById('bookDetailsContent');
      content.innerHTML = `
        <div style="margin-bottom: 25px;">
          <h4 style="color: #1a237e; margin-bottom: 10px; font-size: 1.2rem;">${book.title}</h4>
          <p style="color: #37474f; margin-bottom: 5px;"><strong>Author:</strong> ${book.author}</p>
          <p style="color: #37474f; margin-bottom: 5px;"><strong>ISBN:</strong> ${book.isbn}</p>
          <p style="color: #37474f; margin-bottom: 5px;"><strong>Publisher:</strong> ${book.publisher}</p>
          <p style="color: #37474f; margin-bottom: 5px;"><strong>Year:</strong> ${book.year}</p>
          <p style="color: #37474f; margin-bottom: 5px;"><strong>Category:</strong> ${getCategoryName(book.category)}</p>
          <p style="color: #37474f; margin-bottom: 5px;"><strong>Location:</strong> ${book.location}</p>
          <p style="color: #37474f; margin-bottom: 20px;"><strong>Description:</strong> ${book.description}</p>
        </div>
        
        <div style="background: #f8fafc; padding: 20px; border-radius: 10px; margin-bottom: 20px;">
          <h5 style="color: #1a237e; margin-bottom: 15px;">📊 Availability Details</h5>
          <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-bottom: 20px;">
            <div style="text-align: center;">
              <div style="font-size: 2rem; font-weight: 700; color: #4caf50;">${book.availableCopies}</div>
              <div style="color: #546e7a; font-size: 0.9rem;">Available Now</div>
            </div>
            <div style="text-align: center;">
              <div style="font-size: 2rem; font-weight: 700; color: #ff9800;">${book.totalCopies}</div>
              <div style="color: #546e7a; font-size: 0.9rem;">Total Copies</div>
            </div>
          </div>
          
          <div style="background: white; padding: 15px; border-radius: 8px; border: 1px solid #e0e0e0;">
            <h6 style="color: #1a237e; margin-bottom: 10px;">📅 Expected Availability</h6>
            <p style="color: #546e7a; font-size: 0.9rem;">
              ${book.availableCopies > 0 ? 
                '✅ Available for immediate borrowing' : 
                `⏳ Next available copy expected when current borrowers return their books`
              }
            </p>
          </div>
        </div>
        
        <div style="margin-bottom: 20px;">
          <h5 style="color: #1a237e; margin-bottom: 15px;">👥 Current Borrowers</h5>
          ${book.borrowedBy.length > 0 ? `
            <div style="max-height: 200px; overflow-y: auto;">
              <table style="width: 100%; border-collapse: collapse; font-size: 0.9rem;">
                <thead>
                  <tr style="background: #f1f5f9;">
                    <th style="padding: 10px; text-align: left;">Student</th>
                    <th style="padding: 10px; text-align: left;">Borrowed On</th>
                    <th style="padding: 10px; text-align: left;">Due Date</th>
                    <th style="padding: 10px; text-align: left;">Status</th>
                  </tr>
                </thead>
                <tbody>
                  ${book.borrowedBy.map(student => {
                    const dueDate = new Date(student.dueDate);
                    const today = new Date();
                    const daysDiff = Math.ceil((dueDate - today) / (1000 * 60 * 60 * 24));
                    let status = '';
                    let statusColor = '';
                    
                    if (daysDiff < 0) {
                      status = 'Overdue';
                      statusColor = '#f44336';
                    } else if (daysDiff <= 3) {
                      status = 'Due Soon';
                      statusColor = '#ff9800';
                    } else {
                      status = 'On Track';
                      statusColor = '#4caf50';
                    }
                    
                    return `
                      <tr style="border-bottom: 1px solid #e0e0e0;">
                        <td style="padding: 10px;">${student.name}<br><small style="color: #90a4ae;">${student.studentId}</small></td>
                        <td style="padding: 10px;">${formatDate(student.borrowedDate)}</td>
                        <td style="padding: 10px;">${formatDate(student.dueDate)}</td>
                        <td style="padding: 10px; color: ${statusColor}; font-weight: 600;">${status}</td>
                      </tr>
                    `;
                  }).join('')}
                </tbody>
              </table>
            </div>
          ` : `
            <p style="color: #546e7a; text-align: center; padding: 20px; background: #f8fafc; border-radius: 8px;">
              No current borrowers
            </p>
          `}
        </div>
        
        <div style="display: flex; gap: 10px;">
          ${book.availableCopies > 0 ? `
            <button class="action-btn borrow-btn" onclick="borrowBook(${book.id}); closeModal('bookDetailsModal')" style="flex: 1;">
              Borrow This Book
            </button>
          ` : `
            <button class="action-btn reserve-btn" onclick="addToWaitlist(${book.id}); closeModal('bookDetailsModal')" style="flex: 1;">
              Join Waitlist
            </button>
          `}
          <button class="action-btn details-btn" onclick="closeModal('bookDetailsModal')" style="flex: 1;">
            Close
          </button>
        </div>
      `;
      
      openModal('bookDetailsModal');
    }

    // Search books
    function searchBooks() {
      const title = document.getElementById('searchTitle').value.toLowerCase();
      const author = document.getElementById('searchAuthor').value.toLowerCase();
      const category = document.getElementById('searchCategory').value;
      const status = document.getElementById('searchStatus').value;
      
      let filteredBooks = libraryData.books.filter(book => {
        let matches = true;
        
        if (title && !book.title.toLowerCase().includes(title)) {
          matches = false;
        }
        
        if (author && !book.author.toLowerCase().includes(author)) {
          matches = false;
        }
        
        if (category && book.category !== category) {
          matches = false;
        }
        
        if (status === 'available' && book.availableCopies === 0) {
          matches = false;
        }
        
        if (status === 'borrowed' && book.availableCopies === book.totalCopies) {
          matches = false;
        }
        
        return matches;
      });
      
      // Re-render with filtered books
      const booksGrid = document.getElementById('booksGrid');
      booksGrid.innerHTML = '';
      
      if (filteredBooks.length === 0) {
        booksGrid.innerHTML = `
          <div class="w-100 text-center" style="grid-column: 1 / -1; padding: 60px; color: #546e7a;">
            <div style="font-size: 4rem; margin-bottom: 20px;">🔍</div>
            <h3 style="color: #37474f; margin-bottom: 10px;">No books found</h3>
            <p>Try adjusting your search criteria</p>
            <button class="search-button mt-20" onclick="clearSearch()">
              <span>🔄</span> Clear Search
            </button>
          </div>
        `;
        return;
      }
      
      filteredBooks.forEach(book => {
        const isAvailable = book.availableCopies > 0;
        const canBorrow = isAvailable && currentStudent.currentlyBorrowed < currentStudent.maxBooks;
        
        const bookCard = document.createElement('div');
        bookCard.className = 'book-card';
        bookCard.innerHTML = `
          <div class="book-status ${isAvailable ? 'status-available' : 'status-borrowed'}">
            ${isAvailable ? 'Available' : 'All Borrowed'}
          </div>
          
          <div class="book-header">
            <div class="book-cover" style="background: linear-gradient(135deg, ${getCategoryColor(book.category)});">
              ${book.title.charAt(0)}
            </div>
            <div class="book-info">
              <h3 class="book-title">${book.title}</h3>
              <p class="book-author">by ${book.author}</p>
              <div class="book-meta">
                <span class="meta-item">📚 ${getCategoryName(book.category)}</span>
                <span class="meta-item">📅 ${book.year}</span>
                <span class="meta-item">📍 ${book.location}</span>
              </div>
            </div>
          </div>
          
          <div class="book-details-grid">
            <div class="detail-card">
              <div class="detail-number">${book.availableCopies}</div>
              <div class="detail-text">Available Copies</div>
            </div>
            <div class="detail-card">
              <div class="detail-number">${book.totalCopies}</div>
              <div class="detail-text">Total Copies</div>
            </div>
          </div>
          
          <div class="book-actions">
            <button class="action-btn details-btn" onclick="showBookDetails(${book.id})">
              <span>📖</span> Details
            </button>
            <button class="action-btn borrow-btn" onclick="borrowBook(${book.id})" ${!canBorrow ? 'disabled' : ''}>
              <span>📥</span> ${isAvailable ? 'Borrow' : 'Waitlist'}
            </button>
          </div>
        `;
        booksGrid.appendChild(bookCard);
      });
    }

    // Clear search
    function clearSearch() {
      document.getElementById('searchTitle').value = '';
      document.getElementById('searchAuthor').value = '';
      document.getElementById('searchCategory').value = 'cs';
      document.getElementById('searchStatus').value = 'all';
      renderBooks();
    }

    // Borrow book
    function borrowBook(bookId) {
      const book = libraryData.books.find(b => b.id === bookId);
      
      if (!book) {
        showNotification('Book not found!', 'danger');
        return;
      }
      
      if (book.availableCopies <= 0) {
        showNotification('This book is currently not available. You can join the waitlist.', 'warning');
        return;
      }
      
      if (currentStudent.currentlyBorrowed >= currentStudent.maxBooks) {
        showNotification(`You can only borrow ${currentStudent.maxBooks} books at a time. Please return some books first.`, 'danger');
        return;
      }
      
      // Calculate due date (14 days from now)
      const today = new Date();
      const dueDate = new Date();
      dueDate.setDate(today.getDate() + 14);
      
      // Update book data
      book.availableCopies -= 1;
      book.borrowedBy.push({
        studentId: currentStudent.id,
        name: currentStudent.name,
        dueDate: dueDate.toISOString().split('T')[0],
        borrowedDate: today.toISOString().split('T')[0]
      });
      
      // Add to borrowed books
      libraryData.borrowedBooks.push({
        id: libraryData.borrowedBooks.length + 1,
        bookId: bookId,
        bookTitle: book.title,
        author: book.author,
        borrowedDate: today.toISOString().split('T')[0],
        dueDate: dueDate.toISOString().split('T')[0],
        returned: false,
        fine: 0,
        purpose: "Course study"
      });
      
      // Update student count
      currentStudent.currentlyBorrowed += 1;
      
      // Update UI
      renderBooks();
      renderMyBooks();
      
      showNotification(`"${book.title}" borrowed successfully! Due date: ${formatDate(dueDate)}. Please return on time.`, 'success');
    }

    // Return book
    function returnBook(bookId) {
      const borrowedBook = libraryData.borrowedBooks.find(b => b.id === bookId);
      if (!borrowedBook) return;
      
      const book = libraryData.books.find(b => b.id === borrowedBook.bookId);
      if (book) {
        // Remove student from borrowed list
        book.borrowedBy = book.borrowedBy.filter(s => s.studentId !== currentStudent.id);
        book.availableCopies += 1;
      }
      
      // Mark as returned
      borrowedBook.returned = true;
      borrowedBook.returnDate = new Date().toISOString().split('T')[0];
      
      // Update student count
      currentStudent.currentlyBorrowed -= 1;
      
      // Remove from borrowed books list
      libraryData.borrowedBooks = libraryData.borrowedBooks.filter(b => b.id !== bookId);
      
      // Update UI
      renderBooks();
      renderMyBooks();
      
      showNotification(`"${borrowedBook.bookTitle}" returned successfully! Thank you.`, 'success');
    }

    // Extend due date
    function extendDueDate(bookId) {
      const borrowedBook = libraryData.borrowedBooks.find(b => b.id === bookId);
      if (!borrowedBook) return;
      
      const currentDueDate = new Date(borrowedBook.dueDate);
      const newDueDate = new Date(currentDueDate);
      newDueDate.setDate(newDueDate.getDate() + 7); // Extend by 7 days
      
      borrowedBook.dueDate = newDueDate.toISOString().split('T')[0];
      
      // Also update in the main book record
      const book = libraryData.books.find(b => b.id === borrowedBook.bookId);
      if (book) {
        const studentRecord = book.borrowedBy.find(s => s.studentId === currentStudent.id);
        if (studentRecord) {
          studentRecord.dueDate = newDueDate.toISOString().split('T')[0];
        }
      }
      
      renderMyBooks();
      showNotification(`Due date extended for "${borrowedBook.bookTitle}" to ${formatDate(newDueDate)}.`, 'success');
    }

    // Submit borrow request (from form)
    function submitBorrowRequest() {
      const title = document.getElementById('borrowBookTitle').value;
      const author = document.getElementById('borrowAuthor').value;
      const isbn = document.getElementById('borrowISBN').value;
      const duration = document.getElementById('borrowDuration').value;
      const purpose = document.getElementById('borrowPurpose').value;
      
      if (!title || !duration || !purpose) {
        showNotification('Please fill all required fields!', 'warning');
        return;
      }
      
      // Check if student can borrow more books
      if (currentStudent.currentlyBorrowed >= currentStudent.maxBooks) {
        showNotification(`You can only borrow ${currentStudent.maxBooks} books at a time.`, 'danger');
        return;
      }
      
      // Find book by title/author/ISBN
      let book = null;
      if (isbn) {
        book = libraryData.books.find(b => b.isbn === isbn);
      } else if (title && author) {
        book = libraryData.books.find(b => 
          b.title.toLowerCase().includes(title.toLowerCase()) && 
          b.author.toLowerCase().includes(author.toLowerCase())
        );
      } else if (title) {
        book = libraryData.books.find(b => 
          b.title.toLowerCase().includes(title.toLowerCase())
        );
      }
      
      if (!book) {
        showNotification('Book not found in library. Please check the details.', 'warning');
        return;
      }
      
      if (book.availableCopies <= 0) {
        showNotification('This book is currently not available. You can join the waitlist.', 'warning');
        return;
      }
      
      // Process borrowing
      const today = new Date();
      const dueDate = new Date();
      dueDate.setDate(today.getDate() + parseInt(duration));
      
      // Update book data
      book.availableCopies -= 1;
      book.borrowedBy.push({
        studentId: currentStudent.id,
        name: currentStudent.name,
        dueDate: dueDate.toISOString().split('T')[0],
        borrowedDate: today.toISOString().split('T')[0]
      });
      
      // Add to borrowed books
      libraryData.borrowedBooks.push({
        id: libraryData.borrowedBooks.length + 1,
        bookId: book.id,
        bookTitle: book.title,
        author: book.author,
        borrowedDate: today.toISOString().split('T')[0],
        dueDate: dueDate.toISOString().split('T')[0],
        returned: false,
        fine: 0,
        purpose: purpose
      });
      
      // Update student count
      currentStudent.currentlyBorrowed += 1;
      
      // Clear form
      document.getElementById('borrowBookTitle').value = '';
      document.getElementById('borrowAuthor').value = '';
      document.getElementById('borrowISBN').value = '';
      document.getElementById('borrowDuration').value = '14';
      document.getElementById('borrowPurpose').value = '';
      
      // Update UI
      renderBooks();
      renderMyBooks();
      
      // Switch to My Books tab
      switchTab('mybooks');
      
      showNotification(`Borrow request submitted! "${book.title}" borrowed successfully. Due: ${formatDate(dueDate)}`, 'success');
    }

    // Update room status
    function updateRoomStatus() {
      const room = libraryData.discussionRoom;
      const statusIcon = document.getElementById('roomStatusIcon');
      const statusText = document.getElementById('roomStatusText');
      const currentOccupancy = document.getElementById('currentOccupancy');
      const nextAvailable = document.getElementById('nextAvailable');
      
      if (room.isAvailable) {
        statusIcon.textContent = '✅';
        statusText.textContent = 'Available Now';
        statusText.parentElement.className = 'room-status status-available';
      } else {
        statusIcon.textContent = '⏳';
        statusText.textContent = 'Currently Occupied';
        statusText.parentElement.className = 'room-status status-occupied';
      }
      
      currentOccupancy.textContent = `${room.currentOccupancy}/${room.capacity}`;
      nextAvailable.textContent = room.nextAvailable;
    }

    // Book discussion room
    function bookDiscussionRoom() {
      const date = document.getElementById('roomDate').value;
      const time = document.getElementById('roomTime').value;
      const duration = document.getElementById('roomDurationSelect').value;
      const participants = parseInt(document.getElementById('participants').value);
      const purpose = document.getElementById('roomPurpose').value;
      
      if (!date || !time || !purpose) {
        showNotification('Please fill all required fields!', 'warning');
        return;
      }
      
      if (participants > libraryData.discussionRoom.capacity) {
        showNotification(`Maximum ${libraryData.discussionRoom.capacity} participants allowed!`, 'danger');
        return;
      }
      
      if (!libraryData.discussionRoom.isAvailable) {
        showNotification('Room is currently occupied. Please check next available time.', 'warning');
        return;
      }
      
      // Update room status
      libraryData.discussionRoom.isAvailable = false;
      libraryData.discussionRoom.currentOccupancy = participants;
      
      // Calculate end time
      const startDateTime = new Date(`${date}T${time}`);
      const endDateTime = new Date(startDateTime);
      endDateTime.setHours(endDateTime.getHours() + parseInt(duration));
      
      // Set next available time
      const nextAvailableTime = endDateTime.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit',
        hour12: true 
      });
      libraryData.discussionRoom.nextAvailable = nextAvailableTime;
      
      // Add booking
      libraryData.discussionRoom.bookings.push({
        date: date,
        time: time,
        duration: duration,
        participants: participants,
        purpose: purpose,
        bookedBy: currentStudent.name,
        studentId: currentStudent.id
      });
      
      // Clear form
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      document.getElementById('roomDate').valueAsDate = tomorrow;
      document.getElementById('roomTime').value = '10:00';
      document.getElementById('roomDurationSelect').value = '2';
      document.getElementById('participants').value = '4';
      document.getElementById('roomPurpose').value = '';
      
      // Update UI
      updateRoomStatus();
      
      showNotification(`Discussion room booked successfully for ${duration} hour(s) on ${date} at ${time}!`, 'success');
    }

    // Setup event listeners
    function setupEventListeners() {
      // Tab switching
      document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
          const tabId = tab.dataset.tab;
          switchTab(tabId);
        });
      });
      
      // Set default date for room booking
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      document.getElementById('roomDate').valueAsDate = tomorrow;
      
      // Set default time for room booking
      document.getElementById('roomTime').value = '10:00';
      
      // Enter key for search
      document.getElementById('searchTitle').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') searchBooks();
      });
      
      document.getElementById('searchAuthor').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') searchBooks();
      });
    }

    // Switch tab
    function switchTab(tabId) {
      // Update active tab
      document.querySelectorAll('.tab').forEach(t => {
        t.classList.remove('active');
        if (t.dataset.tab === tabId) {
          t.classList.add('active');
        }
      });
      
      // Show corresponding content
      document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
      });
      document.getElementById(`${tabId}-tab`).classList.add('active');
    }

    // Show notification
    function showNotification(message, type = 'info') {
      const notificationArea = document.getElementById('notificationArea');
      
      const alert = document.createElement('div');
      alert.className = `alert alert-${type}`;
      alert.innerHTML = `
        <div class="alert-icon">
          ${type === 'success' ? '✅' : type === 'warning' ? '⚠️' : type === 'danger' ? '❌' : 'ℹ️'}
        </div>
        <div class="alert-content">
          <div class="alert-title">
            ${type === 'success' ? 'Success' : type === 'warning' ? 'Warning' : type === 'danger' ? 'Error' : 'Information'}
          </div>
          <div class="alert-message">${message}</div>
        </div>
        <button class="alert-close" onclick="this.parentElement.remove()">×</button>
      `;
      
      notificationArea.appendChild(alert);
      
      // Auto-remove after 8 seconds
      setTimeout(() => {
        if (alert.parentElement) {
          alert.style.animation = 'slideInRight 0.3s ease reverse';
          setTimeout(() => alert.remove(), 300);
        }
      }, 8000);
    }

    // Utility functions
    function getCategoryColor(category) {
      const colors = {
        cs: '#2196F3, #1976D2',
        eng: '#9C27B0, #7B1FA2',
        math: '#4CAF50, #388E3C',
        physics: '#F44336, #D32F2F',
        chem: '#FF9800, #F57C00',
        lit: '#E91E63, #C2185B',
        hist: '#607D8B, #455A64'
      };
      return colors[category] || '#757575, #616161';
    }

    function getCategoryName(category) {
      const names = {
        cs: 'Computer Science',
        eng: 'Engineering',
        math: 'Mathematics',
        physics: 'Physics',
        chem: 'Chemistry',
        lit: 'Literature',
        hist: 'History'
      };
      return names[category] || 'General';
    }

    function formatDate(dateString) {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
      });
    }

    function openModal(modalId) {
      document.getElementById(modalId).style.display = 'flex';
    }

    function closeModal(modalId) {
      document.getElementById(modalId).style.display = 'none';
    }

    // Initialize
    init();
document.addEventListener('DOMContentLoaded', function() {
        UserProfile.loadFromStorage();
        UserProfile.updateLibraryPage();
    });