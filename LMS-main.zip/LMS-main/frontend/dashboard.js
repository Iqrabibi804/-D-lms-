const API_BASE_URL = 'http://localhost:5000/api';

function checkLogin() {
    const user = localStorage.getItem('user');
    if (!user) {
        alert('Please login first');
        window.location.href = '1.html';
        return null;
    }
    return JSON.parse(user);
}

async function isBackendConnected() {
    try {
        const res = await fetch(`${API_BASE_URL}/health`);
        return res.ok;
    } catch {
        return false;
    }
}

function updateUserInfo(user) {
    if (!user) return;
    document.querySelector('.user-avatar').textContent = user.fullName?.charAt(0) || 'S';
    document.querySelector('.user-info h3').textContent = user.fullName || 'Student';
    document.querySelector('.user-info p').textContent = `${user.studentId || 'BSE234'} - Student`;
    document.querySelector('.dashboard-header h1').textContent = `Welcome to Your Dashboard, ${user.fullName || 'Student'}!`;
}

function getMockData() {
    return {
        courses: [{ id: 1, courseName: "Data Structures" }, { id: 2, courseName: "Database Systems" }],
        notices: [{ title: "Midterm Notice" }, { title: "Holiday Notice" }],
        attendance: { total: 40, present: 36 }
    };
}

async function loadDashboardData() {
    const backendAvailable = await isBackendConnected();
    const header = document.querySelector('.dashboard-header p');

    if (backendAvailable) {
        header.innerHTML += `<br><small style="color:green;"><i class="fas fa-check-circle"></i> Connected to backend</small>`;
    } else {
        header.innerHTML += `<br><small style="color:orange;"><i class="fas fa-exclamation-triangle"></i> Mock Mode (Backend Offline)</small>`;
    }

    if (!backendAvailable) updateDashboardUI(getMockData());
    else {
        try {
            const token = localStorage.getItem('token');
            const [coursesRes, noticesRes] = await Promise.all([
                fetch(`${API_BASE_URL}/courses/my-courses`, { headers: { Authorization: `Bearer ${token}` } }),
                fetch(`${API_BASE_URL}/notices`, { headers: { Authorization: `Bearer ${token}` } })
            ]);
            const courses = await coursesRes.json();
            const notices = await noticesRes.json();
            updateDashboardUI({ courses, notices });
        } catch {
            updateDashboardUI(getMockData());
        }
    }
}

function updateDashboardUI(data) {
    const assignmentsBadge = document.querySelector('.cards:nth-child(4) .notification-badge');
    const noticesBadge = document.querySelector('.cards:nth-child(6) .notification-badge');
    if (assignmentsBadge) assignmentsBadge.textContent = data.courses?.length || 0;
    if (noticesBadge) noticesBadge.textContent = data.notices?.length || 0;
}

function handleLogout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    alert('Logged out successfully!');
    window.location.href = '1.html';
}

document.addEventListener('DOMContentLoaded', () => {
    const user = checkLogin();
    if (!user) return;
    updateUserInfo(user);
    loadDashboardData();

    const logoutBtn = document.querySelector('.logout-card a');
    logoutBtn.addEventListener('click', e => {
        e.preventDefault();
        if (confirm('Are you sure you want to logout?')) handleLogout();
    });

    // Today's date
    const today = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const header = document.querySelector('.dashboard-header p');
    header.innerHTML += `<br><small><i class="fas fa-calendar-alt"></i> ${today.toLocaleDateString('en-US', options)}</small>`;
});

    
if (typeof UserProfile !== 'undefined') {
    UserProfile.loadFromStorage();
    UserProfile.updateDashboard();
} else {
    console.log('Loading user-profile.js...');
    const script = document.createElement('script');
    script.src = 'user-profile.js';
    script.onload = function() {
        UserProfile.loadFromStorage();
        UserProfile.updateDashboard();
    };
    document.head.appendChild(script);
}
