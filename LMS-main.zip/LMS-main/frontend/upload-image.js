 document.addEventListener('DOMContentLoaded', function() {
            // Get saved image or use default
            const savedImage = localStorage.getItem('profileImage');
            const currentImage = document.getElementById('currentImage');
            
            if (savedImage) {
                currentImage.src = savedImage;
            } else {
                // Default avatar
                currentImage.src = 'https://ui-avatars.com/api/?name=Hina&background=0D8BC9&color=fff&size=150&bold=true';
            }
            
            // Generate avatar options
            generateAvatarOptions();
            
            // Setup file input listener
            setupFileUpload();
        });

        // Generate avatar options
        function generateAvatarOptions() {
            const avatarOptions = document.getElementById('avatarOptions');
            const colors = ['0D8BC9', '4CAF50', 'FF9800', '9C27B0', 'F44336', '2196F3', '009688', '795548'];
            
            avatarOptions.innerHTML = '';
            
            colors.forEach((color) => {
                const avatar = document.createElement('img');
                avatar.className = 'avatar';
                avatar.src = `https://ui-avatars.com/api/?name=Hina&background=${color}&color=fff&size=80&bold=true`;
                
                avatar.onclick = function() {
                    // Remove selected class from all avatars
                    document.querySelectorAll('.avatar').forEach(a => a.classList.remove('selected'));
                    // Add selected class to clicked avatar
                    this.classList.add('selected');
                    // Set the image URL
                    document.getElementById('imageUrl').value = this.src;
                    // Update preview
                    document.getElementById('currentImage').src = this.src;
                };
                
                avatarOptions.appendChild(avatar);
            });
        }

        // Setup file upload
        function setupFileUpload() {
            const fileInput = document.getElementById('fileInput');
            
            fileInput.addEventListener('change', function(event) {
                const file = event.target.files[0];
                if (file) {
                    // Check file type
                    if (!file.type.match('image.*')) {
                        alert('❌ Please select an image file (JPG, PNG, GIF, etc.)');
                        return;
                    }
                    
                    // Check file size (max 5MB)
                    if (file.size > 5 * 1024 * 1024) {
                        alert('❌ Image size should be less than 5MB');
                        return;
                    }
                    
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        const imageUrl = e.target.result;
                        // Update preview
                        document.getElementById('currentImage').src = imageUrl;
                        // Clear URL input
                        document.getElementById('imageUrl').value = '';
                        // Clear selected avatars
                        document.querySelectorAll('.avatar').forEach(a => a.classList.remove('selected'));
                    };
                    
                    reader.readAsDataURL(file);
                }
            });
        }

        // Trigger file input when clicking on current image
        function triggerFileInput() {
            document.getElementById('fileInput').click();
        }

        // Save image function
        function saveImage() {
            const fileInput = document.getElementById('fileInput');
            const imageUrlInput = document.getElementById('imageUrl');
            
            let imageUrl = '';
            
            // Priority 1: Use uploaded file
            if (fileInput.files && fileInput.files[0]) {
                const file = fileInput.files[0];
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    imageUrl = e.target.result;
                    saveToLocalStorage(imageUrl);
                };
                
                reader.readAsDataURL(file);
                return;
            }
            
            // Priority 2: Use URL input
            if (imageUrlInput.value.trim() !== '') {
                imageUrl = imageUrlInput.value.trim();
                
                // Validate URL
                if (!imageUrl.match(/^https?:\/\/.+/i)) {
                    alert('❌ Please enter a valid URL starting with http:// or https://');
                    return;
                }
                
                saveToLocalStorage(imageUrl);
                return;
            }
            
            // Priority 3: Use selected avatar
            const selectedAvatar = document.querySelector('.avatar.selected');
            if (selectedAvatar) {
                imageUrl = selectedAvatar.src;
                saveToLocalStorage(imageUrl);
                return;
            }
            
            // No image selected
            alert('❌ Please select an image using one of the options above.');
        }

        // Save to localStorage and redirect
        function saveToLocalStorage(imageUrl) {
            // Save to localStorage
            localStorage.setItem('profileImage', imageUrl);
            
            // Show success message
            alert('✅ Profile image updated successfully!');
            
            // Redirect back to profile
            setTimeout(() => {
                window.location.href = 'profile.html';
            }, 1000);
        }