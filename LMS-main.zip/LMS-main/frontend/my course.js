
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize all functionality
            initDropdowns();
            initDropWithdraw();
        });

        // Instructor data for survey pages
        function setInstructor(instructorId) {
            // Store instructor ID in localStorage for survey page
            localStorage.setItem('currentInstructor', instructorId);
            
            // Instructor data mapping
            const instructors = {
                'shakeel': {
                    name: "Mr. Shakeel Ahmed",
                    course: "Mobile Application Development",
                    code: "COMP-331",
                    section: "E",
                    year: "2025-2026",
                    department: "Computer Science",
                    semester: "FALL-2025",
                    creditHours: "3 CrHr"
                },
                'sajjad': {
                    name: "Dr. Sajjad Ahmed",
                    course: "Computer Networks",
                    code: "COMP-322",
                    section: "C",
                    year: "2025-2026",
                    department: "Computer Science",
                    semester: "FALL-2025",
                    creditHours: "3 CrHr"
                },
                'sajjad_lab': {
                    name: "Dr. Sajjad Ahmed",
                    course: "Computer Networks Lab",
                    code: "COMP-322L",
                    section: "C",
                    year: "2025-2026",
                    department: "Computer Science",
                    semester: "FALL-2025",
                    creditHours: "1 CrHr"
                },
                'maliha': {
                    name: "Ms. Maliha Khan",
                    course: "Technical and Business Writing",
                    code: "SS-303",
                    section: "N",
                    year: "2024-2025",
                    department: "Social Sciences",
                    semester: "SPRING-2025",
                    creditHours: "3 CrHr"
                },
                'mubashir': {
                    name: "Dr. Mubashir Mansoor",
                    course: "Database Systems",
                    code: "COMP-231",
                    section: "O",
                    year: "2024-2025",
                    department: "Computer Science",
                    semester: "SPRING-2025",
                    creditHours: "3 CrHr"
                }
            };
            
            // Store the specific instructor data
            const instructor = instructors[instructorId];
            if (instructor) {
                localStorage.setItem('instructorData', JSON.stringify(instructor));
            }
            
            return true;
        }

        // Dropdown functionality
        function initDropdowns() {
            // Toggle dropdowns
            document.querySelectorAll('.dropdown-toggle').forEach(button => {
                button.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const dropdown = this.closest('.dropdown');
                    dropdown.classList.toggle('active');
                });
            });

            // Close dropdowns when clicking outside
            document.addEventListener('click', function() {
                document.querySelectorAll('.dropdown').forEach(dropdown => {
                    dropdown.classList.remove('active');
                });
            });
        }

        // Drop/Withdraw functionality
        function initDropWithdraw() {
            // Drop course functionality
            document.querySelectorAll('.drop-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const courseCode = this.getAttribute('data-course');
                    const action = this.getAttribute('data-action');
                    handleCourseAction(courseCode, action);
                });
            });

            // Withdraw course functionality
            document.querySelectorAll('.withdraw-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const courseCode = this.getAttribute('data-course');
                    const action = this.getAttribute('data-action');
                    handleCourseAction(courseCode, action);
                });
            });
        }

        function handleCourseAction(courseCode, action) {
            const courseRow = document.getElementById(`course-${courseCode}`);
            if (!courseRow) return;
            
            const courseTitle = courseRow.querySelector('.course-title-table').textContent;
            const courseFullCode = courseRow.querySelector('.course-code-table').textContent;
            
            const actionText = action === 'drop' ? 'DROP' : 'WITHDRAW';
            const statusText = action === 'drop' ? 'DROPPED' : 'WITHDRAWN';
            const statusClass = action === 'drop' ? 'dropped' : 'withdrawn';
            
            if (confirm(`Are you sure you want to ${actionText} "${courseFullCode} - ${courseTitle}"?`)) {
                // Update status badge
                const statusBadge = courseRow.querySelector('.status-badge');
                statusBadge.className = `status-badge ${statusClass}`;
                statusBadge.textContent = statusText;
                
                // Disable all action buttons in this row
                const actionButtons = courseRow.querySelectorAll('.action-btn, .dropdown-toggle');
                actionButtons.forEach(btn => {
                    btn.style.opacity = '0.5';
                    btn.style.pointerEvents = 'none';
                    btn.title = `Course ${statusText}`;
                });
                
                // Disable dropdown items
                const dropdownItems = courseRow.querySelectorAll('.dropdown-item');
                dropdownItems.forEach(item => {
                    item.style.opacity = '0.5';
                    item.style.pointerEvents = 'none';
                });
                
                // Update credit hours calculation
                updateCreditHours();
                
                // Show success message
                alert(`Course "${courseFullCode}" has been ${statusText.toLowerCase()} successfully.`);
            }
        }

        function updateCreditHours() {
            // Update FALL-2025 credit hours
            const fallContinuingCourses = document.querySelectorAll('#FALL-2025 .status-badge.continuing').length;
            const fallCreditHours = fallContinuingCourses * 3; // Assuming 3 credit hours per course
            
            // Update SPRING-2025 credit hours
            const springContinuingCourses = document.querySelectorAll('#SPRING-2025 .status-badge.continuing').length;
            const springCreditHours = springContinuingCourses * 3;
            
            // Update display (you'll need to add IDs to your semester sections)
            const fallCreditElement = document.querySelector('#FALL-2025 .credit-hours');
            const springCreditElement = document.querySelector('#SPRING-2025 .credit-hours');
            
            if (fallCreditElement) {
                fallCreditElement.textContent = `${fallCreditHours} CrHr / 20 CrHr`;
            }
            
            if (springCreditElement) {
                springCreditElement.textContent = `${springCreditHours} CrHr / 21 CrHr`;
            }
        }

        // Course Card Modal Functions
        let currentInstructorData = null;

        function showCourseCard(instructorId) {
            const instructors = {
                'shakeel': {
                    name: "Mr. Shakeel Ahmed",
                    course: "Mobile Application Development",
                    code: "COMP-331",
                    section: "E",
                    year: "2025-2026",
                    department: "Computer Science",
                    semester: "FALL-2025",
                    creditHours: "3 CrHr"
                },
                'sajjad': {
                    name: "Dr. Sajjad Ahmed",
                    course: "Computer Networks",
                    code: "COMP-322",
                    section: "C",
                    year: "2025-2026",
                    department: "Computer Science",
                    semester: "FALL-2025",
                    creditHours: "3 CrHr"
                },
                'sajjad_lab': {
                    name: "Dr. Sajjad Ahmed",
                    course: "Computer Networks Lab",
                    code: "COMP-322L",
                    section: "C",
                    year: "2025-2026",
                    department: "Computer Science",
                    semester: "FALL-2025",
                    creditHours: "1 CrHr"
                },
                'maliha': {
                    name: "Ms. Maliha Khan",
                    course: "Technical and Business Writing",
                    code: "SS-303",
                    section: "N",
                    year: "2024-2025",
                    department: "Social Sciences",
                    semester: "SPRING-2025",
                    creditHours: "3 CrHr"
                },
                'mubashir': {
                    name: "Dr. Mubashir Mansoor",
                    course: "Database Systems",
                    code: "COMP-231",
                    section: "O",
                    year: "2024-2025",
                    department: "Computer Science",
                    semester: "SPRING-2025",
                    creditHours: "3 CrHr"
                }
            };

            currentInstructorData = instructors[instructorId] || instructors['shakeel'];
            
            // Update modal title
            document.getElementById('modalCourseTitle').textContent = `Course Card - ${currentInstructorData.code}`;
            
            // Generate course card preview
            const previewHTML = `
                <div style="font-family: Arial, sans-serif; padding: 20px; background: white; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                    <div style="text-align: center; border-bottom: 3px solid #0978ac; padding-bottom: 15px; margin-bottom: 20px;">
                        <h1 style="color: #0978ac; margin-bottom: 5px; font-size: 24px;">UNIVERSITY COURSE CARD</h1>
                        <p style="color: #666; font-size: 14px;">Faculty Feedback System</p>
                    </div>
                    
                    <div style="display: flex; justify-content: space-between; margin-bottom: 25px; flex-wrap: wrap;">
                        <div style="flex: 1; min-width: 300px; margin-right: 20px;">
                            <h3 style="color: #333; margin-bottom: 15px; font-size: 18px; border-bottom: 2px solid #0978ac; padding-bottom: 5px;">COURSE INFORMATION</h3>
                            <table style="border-collapse: collapse; width: 100%;">
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold; width: 180px;">Course Code:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee;">${currentInstructorData.code}</td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold;">Course Title:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee;">${currentInstructorData.course}</td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold;">Credit Hours:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee;">${currentInstructorData.creditHours}</td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold;">Section:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee;">${currentInstructorData.section}</td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold;">Semester:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee;">${currentInstructorData.semester}</td>
                                </tr>
                            </table>
                        </div>
                        
                        <div style="flex: 1; min-width: 300px;">
                            <h3 style="color: #333; margin-bottom: 15px; font-size: 18px; border-bottom: 2px solid #0978ac; padding-bottom: 5px;">INSTRUCTOR INFORMATION</h3>
                            <table style="border-collapse: collapse; width: 100%;">
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold; width: 180px;">Instructor:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee;">${currentInstructorData.name}</td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold;">Department:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee;">${currentInstructorData.department}</td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold;">Academic Year:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee;">${currentInstructorData.year}</td>
                                </tr>
                                <tr>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee; font-weight: bold;">Generated On:</td>
                                    <td style="padding: 10px 0; border-bottom: 1px solid #eee;">${new Date().toLocaleDateString()}</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    
                    <div style="background-color: #f8f9fa; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #0978ac;">
                        <h3 style="color: #0978ac; margin-bottom: 10px; font-size: 16px;">STUDENT INFORMATION</h3>
                        <p style="color: #333; margin: 5px 0;">
                            <strong>Student Name:</strong> John Doe<br>
                            <strong>Student ID:</strong> CS-2023-001<br>
                            <strong>Program:</strong> BS Computer Science<br>
                            <strong>Batch:</strong> 2023
                        </p>
                    </div>
                    
                    <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; text-align: center;">
                        <p style="color: #666; font-size: 14px;">
                            This course card is generated from the Faculty Feedback System.<br>
                            Keep this card for your academic records.
                        </p>
                    </div>
                    
                    <div style="text-align: center; margin-top: 30px; color: #999; font-size: 12px;">
                        <p>© 2024 University Faculty Feedback System | Generated on ${new Date().toLocaleDateString()}</p>
                    </div>
                </div>
            `;
            
            document.getElementById('courseCardPreview').innerHTML = previewHTML;
            document.getElementById('courseCardModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeCourseCardModal() {
            document.getElementById('courseCardModal').classList.remove('active');
            document.body.style.overflow = 'auto';
        }

        function downloadCourseCard(format) {
            if (!currentInstructorData) return;
            
            const cardHTML = document.getElementById('courseCardPreview').innerHTML;
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = cardHTML;
            document.body.appendChild(tempDiv);
            
            if (format === 'pdf') {
                html2canvas(tempDiv).then(canvas => {
                    const imgData = canvas.toDataURL('image/png');
                    const pdf = new jspdf.jsPDF('p', 'mm', 'a4');
                    const imgWidth = 210;
                    const pageHeight = 295;
                    const imgHeight = canvas.height * imgWidth / canvas.width;
                    
                    pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
                    pdf.save(`Course_Card_${currentInstructorData.code}_${currentInstructorData.name.replace(/\s+/g, '_')}.pdf`);
                    document.body.removeChild(tempDiv);
                });
            } else if (format === 'image') {
                html2canvas(tempDiv).then(canvas => {
                    const link = document.createElement('a');
                    link.download = `Course_Card_${currentInstructorData.code}_${currentInstructorData.name.replace(/\s+/g, '_')}.png`;
                    link.href = canvas.toDataURL('image/png');
                    link.click();
                    document.body.removeChild(tempDiv);
                });
            } else if (format === 'print') {
                const printWindow = window.open('', '_blank');
                printWindow.document.write(`
                    <html>
                        <head>
                            <title>Course Card - ${currentInstructorData.code}</title>
                            <style>
                                body { font-family: Arial, sans-serif; margin: 20px; }
                                @media print {
                                    @page { margin: 0; }
                                    body { margin: 1.6cm; }
                                }
                            </style>
                        </head>
                        <body>${cardHTML}</body>
                    </html>
                `);
                printWindow.document.close();
                printWindow.focus();
                setTimeout(() => {
                    printWindow.print();
                    printWindow.close();
                }, 250);
                document.body.removeChild(tempDiv);
            }
            
            // Close modal after download
            setTimeout(() => {
                closeCourseCardModal();
            }, 500);
        }

        // Close modal when clicking outside
        document.getElementById('courseCardModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeCourseCardModal();
            }
        });
 