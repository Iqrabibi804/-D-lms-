
        // Generate Admit Card
        function generateAdmitCard(examType) {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            if (examType === 'midterm') {
                // Mid-Term Admit Card
                doc.setFontSize(24);
                doc.setTextColor(9, 120, 172);
                doc.text("MID-TERM EXAM ADMIT CARD", 105, 20, { align: "center" });
                
                doc.setFontSize(16);
                doc.setTextColor(0, 0, 0);
                doc.text("SPRING 2024 SESSION", 105, 32, { align: "center" });
                
                // University Logo/Header
                doc.setFontSize(18);
                doc.setTextColor(111, 66, 193);
                doc.text("UNIVERSITY OF EXCELLENCE", 105, 45, { align: "center" });
                
                // Student Info
                doc.setFontSize(12);
                doc.text("STUDENT INFORMATION:", 20, 60);
                doc.setDrawColor(111, 66, 193);
                doc.setLineWidth(0.5);
                doc.line(20, 62, 80, 62);
                
                doc.setFontSize(11);
                doc.text("Name: Iqra Khan", 25, 70);
                doc.text("Roll No: BSCS2023001", 25, 77);
                doc.text("Program: BS Computer Science", 25, 84);
                doc.text("Semester: 6th Semester", 25, 91);
                doc.text("Section: A", 25, 98);
                
                // Exam Info
                doc.setFontSize(12);
                doc.text("EXAMINATION DETAILS:", 120, 60);
                doc.line(120, 62, 180, 62);
                
                doc.setFontSize(11);
                doc.text("Exam Type: Mid-Term", 125, 70);
                doc.text("Date: March 25, 2024", 125, 77);
                doc.text("Time: 10:00 AM - 12:00 PM", 125, 84);
                doc.text("Venue: Seminar Hall, Block B", 125, 91);
                doc.text("Duration: 2 Hours", 125, 98);
                
                // Subjects
                doc.setFontSize(12);
                doc.text("SUBJECTS:", 20, 110);
                doc.line(20, 112, 50, 112);
                
                doc.setFontSize(11);
                doc.text("1. Statistics", 25, 120);
                doc.text("2. Economics", 25, 127);
                doc.text("3. Business Mathematics", 25, 134);
                
                // Instructions
                doc.setFontSize(12);
                doc.text("IMPORTANT INSTRUCTIONS:", 20, 145);
                doc.line(20, 147, 80, 147);
                
                doc.setFontSize(10);
                doc.text("1. Carry this admit card & university ID", 25, 155);
                doc.text("2. Report 30 minutes before exam", 25, 162);
                doc.text("3. No electronic devices allowed", 25, 169);
                doc.text("4. Follow all exam rules strictly", 25, 176);
                
                // Signature
                doc.setFontSize(11);
                doc.text("___________________", 40, 190);
                doc.text("Student Signature", 40, 196);
                
                doc.text("___________________", 140, 190);
                doc.text("Controller Signature", 140, 196);
                
                doc.save("Mid_Term_Admit_Card_Spring2024.pdf");
                
            } else {
                // Final Exam Admit Card
                doc.setFontSize(24);
                doc.setTextColor(9, 120, 172);
                doc.text("FINAL EXAM ADMIT CARD", 105, 20, { align: "center" });
                
                doc.setFontSize(16);
                doc.setTextColor(0, 0, 0);
                doc.text("SPRING 2024 SESSION", 105, 32, { align: "center" });
                
                // University Logo/Header
                doc.setFontSize(18);
                doc.setTextColor(9, 120, 172);
                doc.text("UNIVERSITY OF EXCELLENCE", 105, 45, { align: "center" });
                
                // Student Info
                doc.setFontSize(12);
                doc.text("STUDENT INFORMATION:", 20, 60);
                doc.setDrawColor(9, 120, 172);
                doc.setLineWidth(0.5);
                doc.line(20, 62, 80, 62);
                
                doc.setFontSize(11);
                doc.text("Name: Iqra Khan", 25, 70);
                doc.text("Roll No: BSCS2023001", 25, 77);
                doc.text("Program: BS Computer Science", 25, 84);
                doc.text("Semester: 6th Semester", 25, 91);
                doc.text("Section: A", 25, 98);
                
                // Exam Info
                doc.setFontSize(12);
                doc.text("EXAMINATION DETAILS:", 120, 60);
                doc.line(120, 62, 180, 62);
                
                doc.setFontSize(11);
                doc.text("Exam Type: Final", 125, 70);
                doc.text("Date: May 15, 2024", 125, 77);
                doc.text("Time: 02:00 PM - 05:00 PM", 125, 84);
                doc.text("Venue: Auditorium Complex, Block C", 125, 91);
                doc.text("Duration: 3 Hours", 125, 98);
                
                // Subjects
                doc.setFontSize(12);
                doc.text("SUBJECTS:", 20, 110);
                doc.line(20, 112, 50, 112);
                
                doc.setFontSize(11);
                doc.text("1. Data Structures", 25, 120);
                doc.text("2. Database Systems", 25, 127);
                doc.text("3. Object Oriented Programming", 25, 134);
                doc.text("4. Computer Networks", 25, 141);
                
                // Instructions
                doc.setFontSize(12);
                doc.text("IMPORTANT INSTRUCTIONS:", 20, 150);
                doc.line(20, 152, 80, 152);
                
                doc.setFontSize(10);
                doc.text("1. Must carry admit card & university ID", 25, 160);
                doc.text("2. Report 30 minutes before exam", 25, 167);
                doc.text("3. No mobile phones or smart watches", 25, 174);
                doc.text("4. Strictly follow seating arrangement", 25, 181);
                doc.text("5. Maintain exam discipline", 25, 188);
                
                // Signature
                doc.setFontSize(11);
                doc.text("___________________", 40, 200);
                doc.text("Student Signature", 40, 206);
                
                doc.text("___________________", 140, 200);
                doc.text("Controller Signature", 140, 206);
                
                doc.save("Final_Exam_Admit_Card_Spring2024.pdf");
            }
        }

        // View Results
        function viewResults(examType) {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            doc.setFontSize(24);
            doc.setTextColor(40, 167, 69);
            doc.text("MID-TERM EXAM RESULTS", 105, 20, { align: "center" });
            
            doc.setFontSize(16);
            doc.setTextColor(0, 0, 0);
            doc.text("SPRING 2024 SESSION", 105, 30, { align: "center" });
            
            // Student Info
            doc.setFontSize(12);
            doc.text("Student: Iqra Khan", 20, 45);
            doc.text("Roll No: BSCS2023001", 20, 52);
            doc.text("Program: BS Computer Science", 20, 59);
            doc.text("Semester: 6th", 20, 66);
            
            // Results Table
            doc.setFontSize(14);
            doc.text("SUBJECT WISE RESULTS", 105, 80, { align: "center" });
            
            // Table Header
            doc.setFillColor(40, 167, 69);
            doc.setTextColor(255, 255, 255);
            doc.rect(20, 85, 170, 10, 'F');
            doc.text("Subject", 25, 91);
            doc.text("Total Marks", 100, 91);
            doc.text("Obtained", 130, 91);
            doc.text("Grade", 160, 91);
            
            // Table Rows
            doc.setTextColor(0, 0, 0);
            const subjects = [
                { name: "Statistics", total: 100, obtained: 85, grade: "A" },
                { name: "Economics", total: 100, obtained: 82, grade: "A-" },
                { name: "Business Mathematics", total: 100, obtained: 79, grade: "B+" }
            ];
            
            let yPos = 100;
            subjects.forEach((subject, index) => {
                doc.text(subject.name, 25, yPos);
                doc.text(subject.total.toString(), 100, yPos);
                doc.text(subject.obtained.toString(), 130, yPos);
                doc.text(subject.grade, 160, yPos);
                yPos += 10;
            });
            
            // Summary
            yPos += 15;
            doc.setFontSize(14);
            doc.text("RESULT SUMMARY", 20, yPos);
            
            yPos += 10;
            doc.setFontSize(12);
            doc.text(`Total Marks: 300`, 25, yPos);
            doc.text(`Obtained Marks: 246`, 25, yPos + 7);
            doc.text(`Percentage: 82%`, 25, yPos + 14);
            doc.text(`Grade: A-`, 25, yPos + 21);
            doc.text(`Status: PASS`, 25, yPos + 28);
            
            // Remarks
            yPos += 40;
            doc.setFontSize(11);
            doc.setTextColor(40, 167, 69);
            doc.text("Remarks: Excellent Performance! Keep it up.", 20, yPos);
            
            doc.setFontSize(10);
            doc.setTextColor(100, 100, 100);
            doc.text("This is a computer generated result sheet.", 105, 200, { align: "center" });
            doc.text("For official transcript, contact examination department.", 105, 205, { align: "center" });
            
            doc.save("Mid_Term_Results_Spring2024.pdf");
        }

        // View Schedule
        function viewSchedule(examType) {
            alert(`📅 Final Exam Schedule\n\n📆 Date: May 15, 2024\n⏰ Time: 02:00 PM - 05:00 PM\n📍 Venue: Auditorium Complex, Block C\n⏳ Duration: 3 Hours\n\n📚 Subjects:\n- Data Structures\n- Database Systems\n- Object Oriented Programming\n- Computer Networks\n\n✅ Please download your admit card before the exam.`);
        }

        // Download Detailed Results
        function downloadDetailedResults() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            doc.setFontSize(24);
            doc.setTextColor(9, 120, 172);
            doc.text("DETAILED RESULTS ANALYSIS", 105, 20, { align: "center" });
            
            doc.setFontSize(16);
            doc.setTextColor(0, 0, 0);
            doc.text("Mid-Term Examinations - Spring 2024", 105, 30, { align: "center" });
            
            // Performance Analysis
            doc.setFontSize(14);
            doc.text("PERFORMANCE ANALYSIS", 20, 45);
            
            doc.setFontSize(12);
            doc.text("Overall Performance: Excellent", 25, 55);
            doc.text("Class Rank: 15th out of 120 students", 25, 62);
            doc.text("Attendance Record: 95%", 25, 69);
            doc.text("Grade Point Average: 3.7/4.0", 25, 76);
            
            // Subject Analysis
            doc.setFontSize(14);
            doc.text("SUBJECT ANALYSIS", 20, 90);
            
            const analysis = [
                { subject: "Statistics", performance: "Excellent", comments: "Strong grasp of concepts" },
                { subject: "Economics", performance: "Very Good", comments: "Good analytical skills" },
                { subject: "Business Mathematics", performance: "Good", comments: "Need improvement in calculus" }
            ];
            
            let yPos = 100;
            analysis.forEach((item, index) => {
                doc.setFontSize(11);
                doc.text(`${index + 1}. ${item.subject}`, 25, yPos);
                doc.text(`Performance: ${item.performance}`, 25, yPos + 7);
                doc.text(`Comments: ${item.comments}`, 25, yPos + 14);
                yPos += 25;
            });
            
            // Recommendations
            yPos += 10;
            doc.setFontSize(14);
            doc.text("RECOMMENDATIONS", 20, yPos);
            
            doc.setFontSize(11);
            doc.text("1. Focus more on calculus concepts", 25, yPos + 10);
            doc.text("2. Practice more problem-solving questions", 25, yPos + 17);
            doc.text("3. Attend all lectures regularly", 25, yPos + 24);
            doc.text("4. Participate in group studies", 25, yPos + 31);
            
            doc.save("Detailed_Results_Analysis.pdf");
        }
