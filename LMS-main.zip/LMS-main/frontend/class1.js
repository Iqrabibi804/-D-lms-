document.addEventListener("DOMContentLoaded", function () {
    // Attach click event to the login button
    document.getElementById("button").addEventListener("click", function (event) {
      // Prevent default form submission
      event.preventDefault();
  
      // Get input values
      const regNo = document.getElementById("reg-no").value.trim();
      const password = document.getElementById("Password").value.trim();
      const captcha = document.getElementById("captcha").value.trim();
  
      // Validate inputs
      if (!regNo || !password || !captcha) {
        alert("Please fill all the fields!");
      } else {
        // Redirect to the next page
        window.location.href = "dashboard.html"; // Replace with your actual next page URL
      }
    });
  });
  