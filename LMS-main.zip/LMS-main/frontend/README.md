# LMS
🎓 University LMS System A web-based Learning Management System designed for universities using HTML, CSS, and JavaScript. It offers course management, assignment submissions, progress tracking, and interactive quizzes. Features include an intuitive interface, real-time notifications, and secure user access.
