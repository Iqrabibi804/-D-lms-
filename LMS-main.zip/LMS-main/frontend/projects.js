
        // Project data for all semesters
        const semesterProjects = {
            sem1: [
                {
                    id: 1,
                    subject: "Introduction to Programming",
                    title: "Student Management System",
                    description: "A console-based application to manage student records using C++",
                    teacher: "Dr. Ali Raza",
                    teacherEmail: "ali.raza@university.edu.pk",
                    status: "completed",
                    dueDate: "2023-10-15",
                    submissionDate: "2023-10-10",
                    marks: "45/50",
                    requirements: [
                        "Add, delete, and update student records",
                        "Calculate GPA and CGPA",
                        "Generate reports",
                        "Save data to file"
                    ],
                    technology: "C++",
                    teamMembers: "Individual Project"
                },
                {
                    id: 2,
                    subject: "Calculus",
                    title: "Mathematical Modeling Project",
                    description: "Application of calculus concepts to real-world problems",
                    teacher: "Prof. Fatima Khan",
                    teacherEmail: "fatima.khan@university.edu.pk",
                    status: "completed",
                    dueDate: "2023-11-20",
                    submissionDate: "2023-11-18",
                    marks: "48/50",
                    requirements: [
                        "Choose a real-world problem",
                        "Apply calculus concepts",
                        "Create mathematical model",
                        "Present findings"
                    ],
                    technology: "MATLAB",
                    teamMembers: "Group of 3"
                }
            ],
            sem2: [
                {
                    id: 3,
                    subject: "Object Oriented Programming",
                    title: "Library Management System",
                    description: "GUI-based application for library operations using Java",
                    teacher: "Dr. Usman Ahmed",
                    teacherEmail: "usman.ahmed@university.edu.pk",
                    status: "completed",
                    dueDate: "2024-01-15",
                    submissionDate: "2024-01-10",
                    marks: "47/50",
                    requirements: [
                        "Book issue/return system",
                        "Member management",
                        "Fine calculation",
                        "Search functionality"
                    ],
                    technology: "Java Swing",
                    teamMembers: "Group of 2"
                },
                {
                    id: 4,
                    subject: "Data Structures",
                    title: "Algorithm Visualizer",
                    description: "Visual representation of sorting and searching algorithms",
                    teacher: "Dr. Sana Malik",
                    teacherEmail: "sana.malik@university.edu.pk",
                    status: "completed",
                    dueDate: "2024-02-28",
                    submissionDate: "2024-02-25",
                    marks: "49/50",
                    requirements: [
                        "Implement 5 sorting algorithms",
                        "Implement 3 searching algorithms",
                        "Visual step-by-step execution",
                        "Performance comparison"
                    ],
                    technology: "Python, PyGame",
                    teamMembers: "Individual Project"
                }
            ],
            sem3: [
                {
                    id: 5,
                    subject: "Database Systems",
                    title: "E-Commerce Database Design",
                    description: "Complete database design for an e-commerce platform",
                    teacher: "Prof. Bilal Hassan",
                    teacherEmail: "bilal.hassan@university.edu.pk",
                    status: "completed",
                    dueDate: "2024-04-10",
                    submissionDate: "2024-04-05",
                    marks: "46/50",
                    requirements: [
                        "ER Diagram",
                        "Normalization up to 3NF",
                        "SQL queries",
                        "Stored procedures"
                    ],
                    technology: "MySQL",
                    teamMembers: "Group of 3"
                },
                {
                    id: 6,
                    subject: "Computer Networks",
                    title: "Network Packet Analyzer",
                    description: "Tool to capture and analyze network packets",
                    teacher: "Dr. Omar Farooq",
                    teacherEmail: "omar.farooq@university.edu.pk",
                    status: "ongoing",
                    dueDate: "2024-05-20",
                    submissionDate: null,
                    marks: null,
                    requirements: [
                        "Packet capturing",
                        "Protocol analysis",
                        "Traffic statistics",
                        "Graphical interface"
                    ],
                    technology: "Python, Scapy",
                    teamMembers: "Group of 2"
                }
            ],
            sem4: [
                {
                    id: 7,
                    subject: "Operating Systems",
                    title: "Process Scheduler Simulator",
                    description: "Simulation of various CPU scheduling algorithms",
                    teacher: "Dr. Hina Shahid",
                    teacherEmail: "hina.shahid@university.edu.pk",
                    status: "completed",
                    dueDate: "2024-07-15",
                    submissionDate: "2024-07-10",
                    marks: "45/50",
                    requirements: [
                        "FCFS scheduling",
                        "SJF scheduling",
                        "Round Robin",
                        "Priority scheduling"
                    ],
                    technology: "C++",
                    teamMembers: "Individual Project"
                },
                {
                    id: 8,
                    subject: "Software Engineering",
                    title: "Hospital Management System",
                    description: "Complete software development lifecycle project",
                    teacher: "Prof. Kamran Ali",
                    teacherEmail: "kamran.ali@university.edu.pk",
                    status: "ongoing",
                    dueDate: "2024-08-30",
                    submissionDate: null,
                    marks: null,
                    requirements: [
                        "Requirement specification",
                        "Design documents",
                        "Implementation",
                        "Testing reports"
                    ],
                    technology: "Java, MySQL",
                    teamMembers: "Group of 4"
                }
            ],
            sem5: [
                {
                    id: 9,
                    subject: "Web Technologies",
                    title: "Online Food Delivery System",
                    description: "Full-stack web application for food delivery",
                    teacher: "Dr. Ayesha Siddiqui",
                    teacherEmail: "ayesha.siddiqui@university.edu.pk",
                    status: "completed",
                    dueDate: "2024-10-25",
                    submissionDate: "2024-10-20",
                    marks: "48/50",
                    requirements: [
                        "User authentication",
                        "Menu management",
                        "Order tracking",
                        "Payment integration"
                    ],
                    technology: "HTML, CSS, JavaScript, PHP, MySQL",
                    teamMembers: "Group of 3"
                },
                {
                    id: 10,
                    subject: "Artificial Intelligence",
                    title: "Chatbot Development",
                    description: "Intelligent chatbot using NLP techniques",
                    teacher: "Dr. Zainab Abbas",
                    teacherEmail: "zainab.abbas@university.edu.pk",
                    status: "ongoing",
                    dueDate: "2024-11-30",
                    submissionDate: null,
                    marks: null,
                    requirements: [
                        "Natural language processing",
                        "Context management",
                        "Integration with APIs",
                        "User interface"
                    ],
                    technology: "Python, TensorFlow, Flask",
                    teamMembers: "Group of 2"
                }
            ],
            sem6: [
                {
                    id: 11,
                    subject: "Mobile Application Development",
                    title: "Fitness Tracking App",
                    description: "Mobile app for tracking fitness activities and diet",
                    teacher: "Prof. Hassan Rizvi",
                    teacherEmail: "hassan.rizvi@university.edu.pk",
                    status: "completed",
                    dueDate: "2025-01-20",
                    submissionDate: "2025-01-15",
                    marks: "47/50",
                    requirements: [
                        "Step counter",
                        "Calorie tracker",
                        "Workout plans",
                        "Progress charts"
                    ],
                    technology: "React Native, Firebase",
                    teamMembers: "Group of 3"
                },
                {
                    id: 12,
                    subject: "Machine Learning",
                    title: "Sentiment Analysis System",
                    description: "ML model to analyze sentiment from text data",
                    teacher: "Dr. Faisal Mehmood",
                    teacherEmail: "faisal.mehmood@university.edu.pk",
                    status: "ongoing",
                    dueDate: "2025-02-28",
                    submissionDate: null,
                    marks: null,
                    requirements: [
                        "Data collection",
                        "Model training",
                        "Accuracy testing",
                        "Web interface"
                    ],
                    technology: "Python, Scikit-learn, Flask",
                    teamMembers: "Individual Project"
                }
            ],
            sem7: [
                {
                    id: 13,
                    subject: "Cloud Computing",
                    title: "Cloud-Based File Storage System",
                    description: "Secure file storage and sharing system on cloud",
                    teacher: "Dr. Samina Akhtar",
                    teacherEmail: "samina.akhtar@university.edu.pk",
                    status: "pending",
                    dueDate: "2025-04-15",
                    submissionDate: null,
                    marks: null,
                    requirements: [
                        "User authentication",
                        "File encryption",
                        "Access control",
                        "Version control"
                    ],
                    technology: "AWS, Node.js, React",
                    teamMembers: "Group of 4"
                },
                {
                    id: 14,
                    subject: "Cyber Security",
                    title: "Network Security Monitor",
                    description: "Tool to monitor and detect network security threats",
                    teacher: "Prof. Talha Javed",
                    teacherEmail: "talha.javed@university.edu.pk",
                    status: "pending",
                    dueDate: "2025-05-10",
                    submissionDate: null,
                    marks: null,
                    requirements: [
                        "Threat detection",
                        "Log analysis",
                        "Real-time alerts",
                        "Dashboard"
                    ],
                    technology: "Python, Elasticsearch, Kibana",
                    teamMembers: "Group of 3"
                }
            ],
            sem8: [
                {
                    id: 15,
                    subject: "Big Data Analytics",
                    title: "Social Media Analytics Dashboard",
                    description: "Analyze social media data for insights and trends",
                    teacher: "Dr. Nadia Chaudhry",
                    teacherEmail: "nadia.chaudhry@university.edu.pk",
                    status: "pending",
                    dueDate: "2025-06-30",
                    submissionDate: null,
                    marks: null,
                    requirements: [
                        "Data collection from APIs",
                        "Sentiment analysis",
                        "Trend visualization",
                        "Report generation"
                    ],
                    technology: "Hadoop, Spark, Python",
                    teamMembers: "Group of 3"
                },
                {
                    id: 16,
                    subject: "Internet of Things",
                    title: "Smart Home Automation System",
                    description: "IoT-based system to control home appliances",
                    teacher: "Dr. Asim Nawaz",
                    teacherEmail: "asim.nawaz@university.edu.pk",
                    status: "pending",
                    dueDate: "2025-07-15",
                    submissionDate: null,
                    marks: null,
                    requirements: [
                        "Sensor integration",
                        "Mobile control",
                        "Energy monitoring",
                        "Security features"
                    ],
                    technology: "Arduino, Raspberry Pi, Node.js",
                    teamMembers: "Group of 4"
                }
            ]
        };

        // Current selected project for modal
        let selectedProject = null;

        // Initialize page
        document.addEventListener('DOMContentLoaded', function() {
            renderAllSemesterProjects();
            setupEventListeners();
        });

        // Render all semester projects
        function renderAllSemesterProjects() {
            for (const semester in semesterProjects) {
                const container = document.getElementById(`${semester}Projects`);
                if (container) {
                    container.innerHTML = '';
                    
                    semesterProjects[semester].forEach(project => {
                        const card = createProjectCard(project);
                        container.appendChild(card);
                    });
                }
            }
        }

        // Create project card HTML
        function createProjectCard(project) {
            const card = document.createElement('div');
            card.className = 'project-card';
            
            let statusClass = 'status-pending';
            let statusText = 'Pending';
            
            if (project.status === 'completed') {
                statusClass = 'status-completed';
                statusText = 'Completed';
            } else if (project.status === 'ongoing') {
                statusClass = 'status-ongoing';
                statusText = 'Ongoing';
            } else if (project.status === 'overdue') {
                statusClass = 'status-overdue';
                statusText = 'Overdue';
            }
            
            const dueDate = project.dueDate ? formatDate(project.dueDate) : 'Not set';
            const submissionDate = project.submissionDate ? formatDate(project.submissionDate) : 'Not submitted';
            
            card.innerHTML = `
                <div class="project-header">
                    <span class="project-subject">${project.subject}</span>
                    <h4 class="project-title">${project.title}</h4>
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="status-badge ${statusClass}">${statusText}</span>
                        ${project.marks ? `<span style="color: var(--success-green); font-weight: 700;">${project.marks}</span>` : ''}
                    </div>
                </div>
                
                <div class="project-info">
                    <div class="info-item">
                        <i class="fas fa-user-graduate"></i>
                        <span class="info-label">Teacher:</span>
                        <span class="info-value">${project.teacher}</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-calendar-alt"></i>
                        <span class="info-label">Due Date:</span>
                        <span class="info-value">${dueDate}</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-laptop-code"></i>
                        <span class="info-label">Technology:</span>
                        <span class="info-value">${project.technology}</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-users"></i>
                        <span class="info-label">Team:</span>
                        <span class="info-value">${project.teamMembers}</span>
                    </div>
                </div>
                
                <div class="project-actions">
                    <button class="btn-details" onclick="viewProjectDetails(${project.id}, '${Object.keys(semesterProjects).find(key => semesterProjects[key].some(p => p.id === project.id))}')">
                        <i class="fas fa-eye"></i>
                        View Details
                    </button>
                    ${project.status === 'completed' ? '' : `
                        <button class="btn-submit" onclick="submitProject(${project.id})">
                            <i class="fas fa-upload"></i>
                            Submit Project
                        </button>
                    `}
                </div>
            `;
            
            return card;
        }

        // View project details
        function viewProjectDetails(projectId, semesterKey) {
            const semester = semesterProjects[semesterKey];
            selectedProject = semester.find(project => project.id === projectId);
            
            if (!selectedProject) return;
            
            const modalBody = document.querySelector('#projectDetailsModal .modal-body');
            
            let statusClass = 'status-pending';
            let statusText = 'Pending';
            
            if (selectedProject.status === 'completed') {
                statusClass = 'status-completed';
                statusText = 'Completed';
            } else if (selectedProject.status === 'ongoing') {
                statusClass = 'status-ongoing';
                statusText = 'Ongoing';
            }
            
            modalBody.innerHTML = `
                <div class="project-details-grid">
                    <div class="detail-card">
                        <h6><i class="fas fa-info-circle"></i> Basic Information</h6>
                        <div class="detail-item">
                            <span class="detail-label">Subject:</span>
                            <span class="detail-value">${selectedProject.subject}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Project Title:</span>
                            <span class="detail-value">${selectedProject.title}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Status:</span>
                            <span class="detail-value"><span class="status-badge ${statusClass}">${statusText}</span></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Due Date:</span>
                            <span class="detail-value">${formatDate(selectedProject.dueDate)}</span>
                        </div>
                        ${selectedProject.submissionDate ? `
                            <div class="detail-item">
                                <span class="detail-label">Submitted On:</span>
                                <span class="detail-value">${formatDate(selectedProject.submissionDate)}</span>
                            </div>
                        ` : ''}
                        ${selectedProject.marks ? `
                            <div class="detail-item">
                                <span class="detail-label">Marks Obtained:</span>
                                <span class="detail-value" style="color: var(--success-green); font-weight: 700;">${selectedProject.marks}</span>
                            </div>
                        ` : ''}
                    </div>
                    
                    <div class="detail-card">
                        <h6><i class="fas fa-user-tie"></i> Teacher Information</h6>
                        <div class="detail-item">
                            <span class="detail-label">Teacher Name:</span>
                            <span class="detail-value">${selectedProject.teacher}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Email:</span>
                            <span class="detail-value">${selectedProject.teacherEmail}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Technology:</span>
                            <span class="detail-value">${selectedProject.technology}</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Team Size:</span>
                            <span class="detail-value">${selectedProject.teamMembers}</span>
                        </div>
                    </div>
                </div>
                
                <div class="requirements-section">
                    <h6><i class="fas fa-tasks"></i> Project Requirements</h6>
                    <ul class="requirements-list">
                        ${selectedProject.requirements.map(req => `<li>${req}</li>`).join('')}
                    </ul>
                </div>
                
                <div class="requirements-section">
                    <h6><i class="fas fa-file-alt"></i> Project Description</h6>
                    <p>${selectedProject.description}</p>
                </div>
                
                ${selectedProject.status !== 'completed' ? `
                    <div class="submission-section">
                        <h6><i class="fas fa-upload"></i> Submit Project</h6>
                        <p>Upload your project files and documentation here:</p>
                        
                        <div class="upload-area" onclick="document.getElementById('projectFile').click()">
                            <div class="upload-icon">
                                <i class="fas fa-cloud-upload-alt"></i>
                            </div>
                            <h5>Click to Upload Project Files</h5>
                            <p>Supported formats: ZIP, RAR, PDF, DOCX</p>
                            <input type="file" id="projectFile" class="d-none" multiple>
                        </div>
                        
                        <div class="d-flex gap-3 mt-4">
                            <button class="btn-details" onclick="uploadProject()">
                                <i class="fas fa-upload"></i>
                                Upload Files
                            </button>
                            <button class="btn-submit" onclick="submitProject(${selectedProject.id})">
                                <i class="fas fa-paper-plane"></i>
                                Final Submission
                            </button>
                        </div>
                    </div>
                ` : ''}
            `;
            
            // Show modal
            const modal = new bootstrap.Modal(document.getElementById('projectDetailsModal'));
            modal.show();
        }

        // View FYP details
        function viewFYPDetails() {
            const modalBody = document.querySelector('#projectDetailsModal .modal-body');
            
            modalBody.innerHTML = `
                <div class="project-details-grid">
                    <div class="detail-card">
                        <h6><i class="fas fa-info-circle"></i> Project Information</h6>
                        <div class="detail-item">
                            <span class="detail-label">Project Type:</span>
                            <span class="detail-value">Final Year Project</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Title:</span>
                            <span class="detail-value">AI-Based Learning Management System with Predictive Analytics</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Status:</span>
                            <span class="detail-value"><span class="status-badge status-ongoing">In Progress</span></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Duration:</span>
                            <span class="detail-value">8 Months (Oct 2023 - Jun 2024)</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Department:</span>
                            <span class="detail-value">Computer Science</span>
                        </div>
                    </div>
                    
                    <div class="detail-card">
                        <h6><i class="fas fa-user-tie"></i> Supervisor Information</h6>
                        <div class="detail-item">
                            <span class="detail-label">Main Supervisor:</span>
                            <span class="detail-value">Dr. Sarah Khan</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Co-Supervisor:</span>
                            <span class="detail-value">Prof. Ahmed Raza</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Email:</span>
                            <span class="detail-value">sarah.khan@university.edu.pk</span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Phone:</span>
                            <span class="detail-value">+92-300-1234567</span>
                        </div>
                    </div>
                </div>
                
                <div class="requirements-section">
                    <h6><i class="fas fa-tasks"></i> Project Objectives</h6>
                    <ul class="requirements-list">
                        <li>Develop an intelligent LMS that adapts to student learning patterns</li>
                        <li>Implement predictive analytics to forecast student performance</li>
                        <li>Create personalized learning paths based on individual progress</li>
                        <li>Integrate machine learning algorithms for content recommendation</li>
                        <li>Provide real-time analytics dashboard for instructors</li>
                    </ul>
                </div>
                
                <div class="requirements-section">
                    <h6><i class="fas fa-laptop-code"></i> Technology Stack</h6>
                    <div class="detail-item">
                        <span class="detail-label">Frontend:</span>
                        <span class="detail-value">React.js, Material-UI</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Backend:</span>
                        <span class="detail-value">Node.js, Express.js</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Database:</span>
                        <span class="detail-value">MongoDB, Redis</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Machine Learning:</span>
                        <span class="detail-value">Python, TensorFlow, Scikit-learn</span>
                    </div>
                    <div class="detail-item">
                        <span class="detail-label">Deployment:</span>
                        <span class="detail-value">Docker, AWS</span>
                    </div>
                </div>
                
                <div class="submission-section">
                    <h6><i class="fas fa-upload"></i> Submit Progress Report</h6>
                    <p>Upload your progress report and updated project files:</p>
                    
                    <div class="upload-area" onclick="document.getElementById('fypFile').click()">
                        <div class="upload-icon">
                            <i class="fas fa-cloud-upload-alt"></i>
                        </div>
                        <h5>Upload Progress Report</h5>
                        <p>Include: Code files, Documentation, Test results</p>
                        <input type="file" id="fypFile" class="d-none" multiple>
                    </div>
                    
                    <div class="d-flex gap-3 mt-4">
                        <button class="btn-details" onclick="uploadFYPProgress()">
                            <i class="fas fa-upload"></i>
                            Upload Progress
                        </button>
                        <button class="btn-submit" onclick="scheduleMeeting()">
                            <i class="fas fa-calendar-alt"></i>
                            Schedule Meeting
                        </button>
                    </div>
                </div>
            `;
            
            // Show modal
            const modal = new bootstrap.Modal(document.getElementById('projectDetailsModal'));
            modal.show();
        }

        // Submit project
        function submitProject(projectId) {
            alert(`Submitting project #${projectId}\nPlease ensure all files are uploaded before final submission.`);
            
            // In real application, this would submit the project
            // For demo, we'll mark it as completed
            for (const semester in semesterProjects) {
                const project = semesterProjects[semester].find(p => p.id === projectId);
                if (project) {
                    project.status = 'completed';
                    project.submissionDate = new Date().toISOString().split('T')[0];
                    project.marks = 'Pending';
                    break;
                }
            }
            
            renderAllSemesterProjects();
            
            // Close modal if open
            const modal = bootstrap.Modal.getInstance(document.getElementById('projectDetailsModal'));
            if (modal) modal.hide();
        }

        // Upload project
        function uploadProject() {
            alert('Uploading project files...\nFiles will be uploaded to the server for review.');
        }

        // Submit FYP progress
        function submitFYPProgress() {
            alert('Submitting FYP progress report...\nYour supervisor will review and provide feedback.');
        }

        // Upload FYP progress
        function uploadFYPProgress() {
            alert('Uploading FYP progress files...\nPlease include all updated documentation.');
        }

        // Schedule meeting
        function scheduleMeeting() {
            alert('Scheduling meeting with supervisor...\nPlease select your preferred time slot.');
        }

        // Setup event listeners
        function setupEventListeners() {
            // File upload for project submission
            document.addEventListener('change', function(e) {
                if (e.target.id === 'projectFile' || e.target.id === 'fypFile') {
                    const files = e.target.files;
                    if (files.length > 0) {
                        alert(`${files.length} file(s) selected for upload.`);
                    }
                }
            });
        }

        // Format date
        function formatDate(dateString) {
            if (!dateString) return 'Not set';
            
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }

        // Export functions for HTML
        window.viewProjectDetails = viewProjectDetails;
        window.viewFYPDetails = viewFYPDetails;
        window.submitProject = submitProject;
        window.submitFYPProgress = submitFYPProgress;
        window.uploadProject = uploadProject;
        window.uploadFYPProgress = uploadFYPProgress;
        window.scheduleMeeting = scheduleMeeting;
    