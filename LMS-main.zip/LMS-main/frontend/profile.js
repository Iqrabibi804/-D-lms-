
// Simple script to handle the back button
        document.addEventListener('DOMContentLoaded', function() {
            // If back button is clicked, it will navigate to the dashboard
            const backButton = document.querySelector('.back-button');
            
            // You can add additional functionality here if needed
            backButton.addEventListener('click', function() {
                // Optional: Add animation or confirmation
                console.log('Navigating back to LMS Dashboard');
            });
            
        
           
            // Add print button to header on larger screens
            if (window.innerWidth > 768) {
                pageHeader.appendChild(printButton);
            }
        });
  document.addEventListener('DOMContentLoaded', function() {
        const profileImg = document.getElementById('profileImage');
        if (profileImg) {
            profileImg.onclick = function() {
                // Simple image upload prompt
                const newImageUrl = prompt('Enter new profile image URL:');
                if (newImageUrl) {
                    UserProfile.updateProfileImage(newImageUrl);
                    alert('✅ Profile image updated!');
                    location.reload();
                }
            };
            
            // Add cursor pointer
            profileImg.style.cursor = 'pointer';
            profileImg.title = 'Click to change profile image';
        }
    });
     document.addEventListener('DOMContentLoaded', function() {
            const savedImage = localStorage.getItem('studentProfileImage');
            if (savedImage) {
                setProfileImage(savedImage);
            }
            
            // Setup file input
            const fileInput = document.getElementById('imageUpload');
            const preview = document.getElementById('previewImage');
            const previewContainer = document.getElementById('imagePreview');
            const uploadButton = document.getElementById('uploadButton');
            
            fileInput.addEventListener('change', function(event) {
                const file = event.target.files[0];
                if (file) {
                    // Check file type
                    if (!file.type.match('image.*')) {
                        alert('Please select an image file (JPG, PNG, GIF, etc.)');
                        return;
                    }
                    
                    // Check file size (max 5MB)
                    if (file.size > 5 * 1024 * 1024) {
                        alert('Image size should be less than 5MB');
                        fileInput.value = '';
                        return;
                    }
                    
                    // Show preview
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        preview.src = e.target.result;
                        previewContainer.style.display = 'block';
                        
                        // Enable upload button
                        uploadButton.disabled = false;
                        uploadButton.style.opacity = '1';
                    };
                    reader.readAsDataURL(file);
                }
            });
            
            // Upload button click
            uploadButton.addEventListener('click', function() {
                if (fileInput.files && fileInput.files[0]) {
                    const file = fileInput.files[0];
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        updateProfileImage(e.target.result);
                    };
                    reader.readAsDataURL(file);
                }
            });
        });

        // Set profile image
        function setProfileImage(imageData) {
            const container = document.getElementById('profileImageContainer');
            if (imageData.startsWith('data:image')) {
                // It's a base64 image
                container.innerHTML = `<img src="${imageData}" class="profile-img" style="object-fit: cover;">`;
            } else if (imageData.includes('ui-avatars.com')) {
                // It's an avatar URL
                container.innerHTML = `<img src="${imageData}" class="profile-img" style="object-fit: cover;">`;
            } else {
                // It's a regular image URL
                container.innerHTML = `<img src="${imageData}" class="profile-img" style="object-fit: cover;">`;
            }
        }

        // Open file dialog
        function openFileDialog() {
            document.getElementById('fileDialog').style.display = 'flex';
            // Reset form
            document.getElementById('imageUpload').value = '';
            document.getElementById('imagePreview').style.display = 'none';
            document.getElementById('uploadButton').disabled = true;
            document.getElementById('uploadButton').style.opacity = '0.7';
        }

        // Close file dialog
        function closeFileDialog() {
            document.getElementById('fileDialog').style.display = 'none';
        }

        // Update profile image
        function updateProfileImage(imageData) {
            // Set the image
            setProfileImage(imageData);
            
            // Save to localStorage
            localStorage.setItem('studentProfileImage', imageData);
            
            // Close dialog
            closeFileDialog();
            
            // Show success message
            setTimeout(() => {
                alert('Profile picture updated successfully!');
            }, 100);
        }

        // Click profile image to open dialog
        document.getElementById('profileImageContainer').addEventListener('click', openFileDialog);
        
        // Close dialog when clicking outside
        document.getElementById('fileDialog').addEventListener('click', function(e) {
            if (e.target === this) {
                closeFileDialog();
            }
        });