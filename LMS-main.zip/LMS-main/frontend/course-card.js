
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('feedbackForm');
            const questions = document.querySelectorAll('.question');
            const progressFill = document.getElementById('progress-fill');
            const progressPercentage = document.getElementById('progress-percentage');
            const downloadSection = document.getElementById('downloadSection');
            const courseInfo = document.getElementById('courseInfo');
            
            // Get instructor data from URL or localStorage
            const urlParams = new URLSearchParams(window.location.search);
            const instructorId = urlParams.get('instructor') || 'shakeel';
            
            // Instructor data mapping
            const instructors = {
                'shakeel': {
                    name: "Mr. Shakeel Ahmed",
                    course: "Mobile Application Development",
                    code: "COMP-331",
                    section: "E",
                    avatar: "S",
                    year: "2025-2026",
                    department: "Computer Science",
                    semester: "FALL-2025",
                    creditHours: "3 CrHr"
                },
                'sajjad': {
                    name: "Dr. Sajjad Ahmed",
                    course: "Computer Networks",
                    code: "COMP-322",
                    section: "C",
                    avatar: "S",
                    year: "2025-2026",
                    department: "Computer Science",
                    semester: "FALL-2025",
                    creditHours: "3 CrHr"
                },
                'sajjad_lab': {
                    name: "Dr. Sajjad Ahmed",
                    course: "Computer Networks Lab",
                    code: "COMP-322L",
                    section: "C",
                    avatar: "S",
                    year: "2025-2026",
                    department: "Computer Science",
                    semester: "FALL-2025",
                    creditHours: "1 CrHr"
                },
                'maliha': {
                    name: "Ms. Maliha Khan",
                    course: "Technical and Business Writing",
                    code: "SS-303",
                    section: "N",
                    avatar: "M",
                    year: "2024-2025",
                    department: "Social Sciences",
                    semester: "SPRING-2025",
                    creditHours: "3 CrHr"
                },
                'mubashir': {
                    name: "Dr. Mubashir Mansoor",
                    course: "Database Systems",
                    code: "COMP-231",
                    section: "O",
                    avatar: "M",
                    year: "2024-2025",
                    department: "Computer Science",
                    semester: "SPRING-2025",
                    creditHours: "3 CrHr"
                }
            };
            
            // Get current instructor data
            const instructor = instructors[instructorId] || instructors['shakeel'];
            
            // Update course info section
            courseInfo.innerHTML = `
                <h2>Faculty Feedback by Students</h2>
                <p><strong>Instructor:</strong> ${instructor.name}</p>
                <p><strong>Course:</strong> ${instructor.code} ${instructor.course}</p>
                <p><strong>Department:</strong> ${instructor.department} | <strong>Semester:</strong> ${instructor.semester} | <strong>Credit Hours:</strong> ${instructor.creditHours}</p>
                
                <div class="course-details">
                    <div class="detail-item">
                        <i class="fas fa-chalkboard-teacher"></i>
                        <span>Section: ${instructor.section}</span>
                    </div>
                    <div class="detail-item">
                        <i class="fas fa-calendar-alt"></i>
                        <span>Academic Year: ${instructor.year}</span>
                    </div>
                </div>
            `;
            
            // Update page title
            document.title = `Faculty Feedback Survey - ${instructor.name}`;
            
            // Store instructor data for course card generation
            window.currentInstructor = instructor;
            
            // Update progress bar
            function updateProgress() {
                let answeredCount = 0;
                for (let i = 1; i <= 6; i++) {
                    const selectedOption = document.querySelector(`input[name="q${i}"]:checked`);
                    if (selectedOption) answeredCount++;
                }
                
                const percentage = Math.round((answeredCount / 6) * 100);
                progressFill.style.width = percentage + '%';
                progressPercentage.textContent = percentage + '%';
            }
            
            // Initialize progress
            updateProgress();
            
            // Highlight selected option and update progress
            questions.forEach(question => {
                const radioButtons = question.querySelectorAll('input[type="radio"]');
                radioButtons.forEach(radio => {
                    radio.addEventListener('change', function() {
                        // Remove error if any
                        const errorElement = question.querySelector('.validation-error');
                        if (errorElement) {
                            errorElement.style.display = 'none';
                        }
                        
                        // Update progress bar
                        updateProgress();
                    });
                });
            });
            
            // Form validation and submission
            form.addEventListener('submit', function(event) {
                event.preventDefault();
                let isValid = true;
                
                // Check each question
                for (let i = 1; i <= 6; i++) {
                    const questionName = 'q' + i;
                    const selectedOption = document.querySelector(`input[name="${questionName}"]:checked`);
                    const errorElement = document.getElementById(`error_q${i}`);
                    const questionElement = document.getElementById(`q${i}`);
                    
                    if (!selectedOption) {
                        // Show error
                        errorElement.style.display = 'block';
                        questionElement.style.borderLeft = '4px solid #e74c3c';
                        isValid = false;
                    } else {
                        // Hide error if exists
                        errorElement.style.display = 'none';
                        questionElement.style.borderLeft = '4px solid #0978ac';
                    }
                }
                
                if (isValid) {
                    // Collect form data
                    const formData = {};
                    for (let i = 1; i <= 6; i++) {
                        const questionName = 'q' + i;
                        const selectedOption = document.querySelector(`input[name="${questionName}"]:checked`);
                        formData[questionName] = selectedOption.value;
                    }
                    
                    // Add instructor information
                    formData.instructor = instructorId;
                    formData.instructorName = instructor.name;
                    formData.course = instructor.course;
                    formData.courseCode = instructor.code;
                    formData.timestamp = new Date().toISOString();
                    
                    // Save to localStorage
                    const allFeedback = JSON.parse(localStorage.getItem('feedbackResponses') || '[]');
                    allFeedback.push(formData);
                    localStorage.setItem('feedbackResponses', JSON.stringify(allFeedback));
                    
                    console.log('Feedback Submitted for Instructor:', instructorId, formData);
                    
                    // Show success message with animation
                    const submitBtn = document.querySelector('.submit-btn');
                    const originalText = submitBtn.innerHTML;
                    
                    submitBtn.innerHTML = '<i class="fas fa-check"></i> Feedback Submitted!';
                    submitBtn.style.background = 'linear-gradient(135deg, #2ecc71 0%, #27ae60 100%)';
                    submitBtn.disabled = true;
                    
                    // Show download section
                    setTimeout(() => {
                        downloadSection.classList.add('active');
                        downloadSection.scrollIntoView({ behavior: 'smooth' });
                    }, 500);
                    
                    // Reset form after 5 seconds
                    setTimeout(() => {
                        form.reset();
                        submitBtn.innerHTML = originalText;
                        submitBtn.style.background = 'linear-gradient(135deg, #0978ac 0%, #0d8bc9 100%)';
                        submitBtn.disabled = false;
                        
                        // Reset progress
                        progressFill.style.width = '0%';
                        progressPercentage.textContent = '0%';
                        
                        // Reset question borders
                        questions.forEach(q => {
                            q.style.borderLeft = '4px solid transparent';
                        });
                    }, 5000);
                } else {
                    // Scroll to first error
                    const firstError = document.querySelector('.validation-error[style*="display: block"]');
                    if (firstError) {
                        firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                }
            });
            
            // Download PDF functionality
            document.getElementById('downloadPDF').addEventListener('click', function(e) {
                e.preventDefault();
                generateCourseCard('pdf');
            });
            
            // Download Image functionality
            document.getElementById('downloadImage').addEventListener('click', function(e) {
                e.preventDefault();
                generateCourseCard('image');
            });
            
            // Print functionality
            document.getElementById('printCard').addEventListener('click', function() {
                generateCourseCard('print');
            });
            
            // Generate course card
            function generateCourseCard(format) {
                // Create course card HTML
                const cardHTML = `
                    <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; background: white;">
                        <div style="text-align: center; border-bottom: 3px solid #0978ac; padding-bottom: 15px; margin-bottom: 20px;">
                            <h1 style="color: #0978ac; margin-bottom: 5px;">UNIVERSITY COURSE CARD</h1>
                            <p style="color: #666;">Faculty Feedback System</p>
                        </div>
                        
                        <div style="display: flex; justify-content: space-between; margin-bottom: 25px;">
                            <div>
                                <h3 style="color: #333; margin-bottom: 15px;">COURSE INFORMATION</h3>
                                <table style="border-collapse: collapse; width: 100%;">
                                    <tr>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold; width: 180px;">Course Code:</td>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee;">${instructor.code}</td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold;">Course Title:</td>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee;">${instructor.course}</td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold;">Credit Hours:</td>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee;">${instructor.creditHours}</td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold;">Section:</td>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee;">${instructor.section}</td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold;">Semester:</td>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee;">${instructor.semester}</td>
                                    </tr>
                                </table>
                            </div>
                            
                            <div>
                                <h3 style="color: #333; margin-bottom: 15px;">INSTRUCTOR INFORMATION</h3>
                                <table style="border-collapse: collapse; width: 100%;">
                                    <tr>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold; width: 180px;">Instructor:</td>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee;">${instructor.name}</td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold;">Department:</td>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee;">${instructor.department}</td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold;">Academic Year:</td>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee;">${instructor.year}</td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee; font-weight: bold;">Generated On:</td>
                                        <td style="padding: 8px 0; border-bottom: 1px solid #eee;">${new Date().toLocaleDateString()}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        
                        <div style="background-color: #f8f9fa; padding: 15px; border-radius: 8px; margin: 20px 0;">
                            <h3 style="color: #0978ac; margin-bottom: 10px;">FEEDBACK SUBMISSION STATUS</h3>
                            <p style="color: #27ae60; font-weight: bold; margin: 0;">
                                <i class="fas fa-check-circle" style="margin-right: 8px;"></i>
                                Feedback Successfully Submitted
                            </p>
                            <p style="color: #666; margin: 5px 0 0 0; font-size: 14px;">
                                Submission Date: ${new Date().toLocaleString()}
                            </p>
                        </div>
                        
                        <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee;">
                            <p style="color: #666; font-size: 14px; text-align: center;">
                                This course card is generated from the Faculty Feedback System.<br>
                                Keep this card for your academic records.
                            </p>
                        </div>
                        
                        <div style="text-align: center; margin-top: 30px; color: #999; font-size: 12px;">
                            <p>© 2024 University Faculty Feedback System | Generated on ${new Date().toLocaleDateString()}</p>
                        </div>
                    </div>
                `;
                
                // Create a temporary div for the card
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = cardHTML;
                document.body.appendChild(tempDiv);
                
                if (format === 'pdf') {
                    // Generate PDF
                    html2canvas(tempDiv).then(canvas => {
                        const imgData = canvas.toDataURL('image/png');
                        const pdf = new jspdf.jsPDF('p', 'mm', 'a4');
                        const imgWidth = 210;
                        const pageHeight = 295;
                        const imgHeight = canvas.height * imgWidth / canvas.width;
                        let heightLeft = imgHeight;
                        let position = 0;
                        
                        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
                        heightLeft -= pageHeight;
                        
                        while (heightLeft >= 0) {
                            position = heightLeft - imgHeight;
                            pdf.addPage();
                            pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
                            heightLeft -= pageHeight;
                        }
                        
                        pdf.save(`Course_Card_${instructor.code}_${instructor.name.replace(/\s+/g, '_')}.pdf`);
                        document.body.removeChild(tempDiv);
                    });
                } else if (format === 'image') {
                    // Generate Image
                    html2canvas(tempDiv).then(canvas => {
                        const link = document.createElement('a');
                        link.download = `Course_Card_${instructor.code}_${instructor.name.replace(/\s+/g, '_')}.png`;
                        link.href = canvas.toDataURL('image/png');
                        link.click();
                        document.body.removeChild(tempDiv);
                    });
                } else if (format === 'print') {
                    // Print
                    const printWindow = window.open('', '_blank');
                    printWindow.document.write(`
                        <html>
                            <head>
                                <title>Course Card - ${instructor.code}</title>
                                <style>
                                    body { font-family: Arial, sans-serif; margin: 20px; }
                                    @media print {
                                        @page { margin: 0; }
                                        body { margin: 1.6cm; }
                                    }
                                </style>
                            </head>
                            <body>${cardHTML}</body>
                        </html>
                    `);
                    printWindow.document.close();
                    printWindow.focus();
                    setTimeout(() => {
                        printWindow.print();
                        printWindow.close();
                    }, 250);
                    document.body.removeChild(tempDiv);
                }
            }
            
            // Back button functionality
            const backButton = document.querySelector('.back-button');
            backButton.addEventListener('click', function(event) {
                event.preventDefault();
                
                // Check if any answers have been selected
                let hasAnswers = false;
                for (let i = 1; i <= 6; i++) {
                    const selectedOption = document.querySelector(`input[name="q${i}"]:checked`);
                    if (selectedOption) {
                        hasAnswers = true;
                        break;
                    }
                }
                
                if (hasAnswers) {
                    if (confirm('Are you sure you want to go back? Any unsaved feedback will be lost.')) {
                        window.location.href = backButton.getAttribute('href');
                    }
                } else {
                    window.location.href = backButton.getAttribute('href');
                }
            });
            
            // Add animation to question numbers
            const questionNumbers = document.querySelectorAll('.question-number');
            questionNumbers.forEach((num, index) => {
                num.style.animationDelay = `${index * 0.1}s`;
            });
        });
   