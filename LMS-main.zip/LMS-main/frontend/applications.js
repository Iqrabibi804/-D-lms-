// Complete Applications System - FIXED VERSION (with Submit Issue Fixed)
class ApplicationSystem {
    constructor() {
        this.baseUrl = 'http://localhost:5000/api';
        this.currentPage = 1;
        this.limit = 10;
        this.totalPages = 1;
        this.demoMode = true;
        this.demoApplications = []; // Store demo apps here
        this.init();
    }

    async init() {
        console.log('🚀 Initializing Application System...');
        
        // First check backend connection
        await this.checkBackendConnection();
        
        // Then check authentication
        if (!this.checkAuth()) {
            return;
        }
        
        // Load initial demo applications
        this.loadInitialDemoData();
        
        this.setupEventListeners();
        this.loadApplications();
    }

    loadInitialDemoData() {
        // Original demo applications - fixed IDs match viewApplication
        this.demoApplications = [
            {
                _id: '1',
                applicationNo: 'APP001',
                type: 'Fee',
                subject: 'Request for Fee Installment',
                message: 'It is stated that I am requesting fee installment due to unexpected big losses in business. Now, we are getting back but it will take time. I am unable to pay the entire amount in one go. So please help us in our tough time.',
                applicationDate: '2025-01-15T10:30:00.000Z',
                status: 'pending',
                attachments: [],
                activities: [
                    {
                        activityNo: 1,
                        forwardedBy: { name: 'B23F0487SE076', role: 'Student' },
                        respondBy: { name: 'Mr. Daniyal', role: 'Faculty' },
                        response: 'Forwarded',
                        forwardedTo: { name: 'Mr. Daniyal', role: 'Faculty' },
                        date: '2025-01-15T11:00:00.000Z',
                        remarks: ''
                    }
                ]
            },
            {
                _id: '2',
                applicationNo: 'APP002',
                type: 'Re-checking',
                subject: 'Re-checking of Exam Paper - Technical',
                message: 'It is stated that I want to apply for re-checking of my Technical Drawing paper. I believe there might be an error in marking as I expected higher marks.',
                applicationDate: '2025-01-10T14:20:00.000Z',
                status: 'approved',
                attachments: [],
                activities: [
                    {
                        activityNo: 1,
                        forwardedBy: { name: 'B23F0487SE076', role: 'Student' },
                        respondBy: { name: 'Exam Department', role: 'Exam Dept' },
                        response: 'Forwarded',
                        forwardedTo: { name: 'Exam Department', role: 'Exam Dept' },
                        date: '2025-01-10T15:00:00.000Z',
                        remarks: ''
                    },
                    {
                        activityNo: 2,
                        forwardedBy: { name: 'Exam Department', role: 'Exam Dept' },
                        respondBy: { name: 'Dr. Arshad Hussain', role: 'Admin' },
                        response: 'Approved',
                        forwardedTo: { name: 'Dr. Arshad Hussain', role: 'Admin' },
                        date: '2025-01-12T10:00:00.000Z',
                        remarks: 'Re-checking approved. Fee deducted.'
                    }
                ]
            },
            {
                _id: '3',
                applicationNo: '9911',
                type: 'Adjustment',
                subject: 'Late Fee Charges Waiver',
                message: 'It is stated that I am requesting a waiver of late fee charges for my tuition fee payment. Due to waiting for kinship results, I was late in making the payment. I kindly request you to consider my situation and waive off the late fee charges.',
                applicationDate: '2025-08-27T10:36:12.000Z',
                status: 'implemented',
                attachments: [],
                activities: [
                    {
                        activityNo: 1,
                        forwardedBy: { name: 'B23F04875E076', role: 'Student' },
                        respondBy: { name: 'Mr. Daniyal', role: 'Faculty' },
                        response: 'Forwarded',
                        forwardedTo: { name: 'Mr. Daniyal', role: 'Faculty' },
                        date: '2025-08-27T00:00:00.000Z',
                        remarks: ''
                    },
                    {
                        activityNo: 2,
                        forwardedBy: { name: 'Mr. Daniyal', role: 'Faculty' },
                        respondBy: { name: 'Dr. Sharif Ullah Khan', role: 'HOD' },
                        response: 'Forwarded',
                        forwardedTo: { name: 'Dr. Sharif Ullah Khan', role: 'HOD' },
                        date: '2025-09-01T00:00:00.000Z',
                        remarks: ''
                    },
                    {
                        activityNo: 3,
                        forwardedBy: { name: 'Dr. Sharif Ullah Khan', role: 'HOD' },
                        respondBy: { name: 'Dr. Arshad Hussain', role: 'Admin' },
                        response: 'Approved',
                        forwardedTo: { name: 'Dr. Arshad Hussain', role: 'Admin' },
                        date: '2025-09-01T00:00:00.000Z',
                        remarks: ''
                    },
                    {
                        activityNo: 4,
                        forwardedBy: { name: 'Dr. Arshad Hussain', role: 'Admin' },
                        respondBy: { name: 'Dr. Sharif Ullah Khan', role: 'HOD' },
                        response: 'Forwarded',
                        forwardedTo: { name: 'Dr. Sharif Ullah Khan', role: 'HOD' },
                        date: '2025-09-01T00:00:00.000Z',
                        remarks: ''
                    },
                    {
                        activityNo: 5,
                        forwardedBy: { name: 'Dr. Sharif Ullah Khan', role: 'HOD' },
                        respondBy: { name: 'Mr. Daniyal', role: 'Faculty' },
                        response: 'Implemented',
                        forwardedTo: { name: 'Mr. Daniyal', role: 'Faculty' },
                        date: '2025-09-02T00:00:00.000Z',
                        remarks: 'LFC Removal 75%'
                    }
                ]
            },
            {
                _id: '4',
                applicationNo: 'APP004',
                type: 'Extension',
                subject: 'Project Submission Extension',
                message: 'It is stated that I need extension for project submission due to medical emergency in family. Requesting 1 week extension.',
                applicationDate: '2025-01-02T16:45:00.000Z',
                status: 'forwarded',
                attachments: [],
                activities: [
                    {
                        activityNo: 1,
                        forwardedBy: { name: 'B23F0487SE076', role: 'Student' },
                        respondBy: { name: 'Course Instructor', role: 'Faculty' },
                        response: 'Forwarded',
                        forwardedTo: { name: 'Course Instructor', role: 'Faculty' },
                        date: '2025-01-02T17:00:00.000Z',
                        remarks: 'Forwarded to HOD'
                    }
                ]
            },
            {
                _id: '5',
                applicationNo: 'APP005',
                type: 'Other',
                subject: 'Hostel Room Change Request',
                message: 'It is stated that I want to change my hostel room due to compatibility issues with roommate.',
                applicationDate: '2024-12-28T11:20:00.000Z',
                status: 'rejected',
                attachments: [],
                activities: [
                    {
                        activityNo: 1,
                        forwardedBy: { name: 'B23F0487SE076', role: 'Student' },
                        respondBy: { name: 'Hostel Warden', role: 'Warden' },
                        response: 'Rejected',
                        forwardedTo: { name: 'Hostel Warden', role: 'Warden' },
                        date: '2024-12-29T10:00:00.000Z',
                        remarks: 'No rooms available currently'
                    }
                ]
            }
        ];
    }

    async checkBackendConnection() {
        try {
            console.log('🔌 Checking backend connection...');
            const response = await fetch(`${this.baseUrl}/health`);
            
            if (response.ok) {
                const data = await response.json();
                console.log('✅ Backend connected:', data.message);
                this.demoMode = false;
                this.showNotification('Backend connected successfully!', 'success', 3000);
            }
        } catch (error) {
            console.log('⚠️ Backend not connected, using demo mode');
            this.demoMode = true;
        }
        return false;
    }

    checkAuth() {
        console.log('🔐 Checking authentication...');
        
        const token = localStorage.getItem('token');
        const userStr = localStorage.getItem('user');
        
        if (!token || !userStr) {
            console.log('❌ No authentication found');
            
            // Create demo user
            const demoUser = {
                registrationNo: 'B23F0487SE076',
                fullName: 'Iqra Bibi',
                department: 'Software Engineering',
                year: '3rd Year',
                role: 'student',
                studentId: 'BSE23F',
                cgpa: 3.12,
                sgpa: 2.82,
                group: 'Blue'
            };
            
            localStorage.setItem('user', JSON.stringify(demoUser));
            localStorage.setItem('token', 'demo-token-' + Date.now());
            
            this.user = demoUser;
            this.token = 'demo-token';
            
            console.log('✅ Created demo user');
            return true;
        }
        
        try {
            this.user = JSON.parse(userStr);
            this.token = token;
            console.log('✅ User authenticated:', this.user.registrationNo);
            return true;
        } catch (error) {
            console.error('❌ Error parsing user data:', error);
            return false;
        }
    }

    setupEventListeners() {
        console.log('⚡ Setting up event listeners...');
        
        // Create application button
        const createBtn = document.getElementById('createAppBtn');
        if (createBtn) {
            createBtn.addEventListener('click', () => {
                this.showCreateModal();
            });
        }

        // Apply filters button
        const applyFilterBtn = document.getElementById('applyFilter');
        if (applyFilterBtn) {
            applyFilterBtn.addEventListener('click', () => {
                this.currentPage = 1;
                this.loadApplications();
            });
        }

        // Close modal buttons
        const closeModalBtn = document.getElementById('closeModal');
        if (closeModalBtn) {
            closeModalBtn.addEventListener('click', () => {
                this.hideCreateModal();
            });
        }

        const cancelBtn = document.getElementById('cancelBtn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                this.hideCreateModal();
            });
        }

        // Form submission
        const form = document.getElementById('applicationForm');
        if (form) {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                this.submitApplication();
            });
        }

        // Character counter
        const messageTextarea = document.getElementById('appMessage');
        if (messageTextarea) {
            messageTextarea.addEventListener('input', (e) => {
                this.updateCharCounter(e.target.value);
            });
        }

        // File upload
        const fileInput = document.getElementById('appAttachment');
        if (fileInput) {
            fileInput.addEventListener('change', (e) => {
                const fileName = document.getElementById('fileName');
                if (fileName && e.target.files.length > 0) {
                    fileName.textContent = e.target.files[0].name;
                }
            });
        }

        console.log('✅ Event listeners setup complete');
    }

    async loadApplications() {
        console.log('📥 Loading applications...');
        
        // Show loading
        this.showLoading();
        
        if (this.demoMode) {
            // Load demo data
            setTimeout(() => {
                this.loadDemoApplications();
            }, 500);
        } else {
            // Try to load from backend
            try {
                await this.loadFromBackend();
            } catch (error) {
                console.log('❌ Backend failed:', error.message);
                this.demoMode = true;
                this.loadDemoApplications();
            }
        }
    }

    showLoading() {
        const container = document.getElementById('applicationsList');
        if (container) {
            container.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align: center; padding: 60px 20px;">
                        <div style="display: inline-block; text-align: center;">
                            <div style="width: 50px; height: 50px; border: 3px solid #f3f3f3; border-top: 3px solid #3498db; border-radius: 50%; animation: spin 1s linear infinite; margin: 0 auto 15px;"></div>
                            <p style="color: #7f8c8d; font-size: 16px;">Loading applications...</p>
                            ${this.demoMode ? '<p style="color: #f39c12; font-size: 14px; margin-top: 10px;">⚠️ Using demo mode</p>' : ''}
                        </div>
                    </td>
                </tr>
            `;
            
            // Add spinner animation
            const style = document.createElement('style');
            style.textContent = `
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            `;
            document.head.appendChild(style);
        }
    }

    loadDemoApplications() {
        console.log('🎭 Loading demo applications...');
        
        // Get applications from localStorage (if any new ones added)
        const storedApps = JSON.parse(localStorage.getItem('student_applications')) || [];
        
        // Combine demo apps with stored apps (new ones)
        let allApplications = [...this.demoApplications];
        
        if (storedApps.length > 0) {
            // Add stored apps at the beginning (most recent first)
            allApplications = [...storedApps, ...allApplications];
        }
        
        // Filter based on selected filters
        let filteredApps = [...allApplications];
        
        const statusFilter = document.getElementById('statusFilter')?.value;
        const typeFilter = document.getElementById('typeFilter')?.value;
        
        if (statusFilter) {
            filteredApps = filteredApps.filter(app => app.status === statusFilter);
        }
        
        if (typeFilter) {
            filteredApps = filteredApps.filter(app => app.type === typeFilter);
        }

        // Sort by date (newest first)
        filteredApps.sort((a, b) => new Date(b.applicationDate) - new Date(a.applicationDate));

        // Pagination
        const start = (this.currentPage - 1) * this.limit;
        const end = start + parseInt(this.limit);
        const paginatedApps = filteredApps.slice(start, end);

        this.renderApplications(paginatedApps);
        
        this.renderPagination({
            page: this.currentPage,
            limit: parseInt(this.limit),
            total: filteredApps.length,
            pages: Math.ceil(filteredApps.length / this.limit)
        });
    }

    renderApplications(applications) {
        const container = document.getElementById('applicationsList');
        if (!container) {
            console.error('❌ Applications container not found');
            return;
        }

        if (!applications || applications.length === 0) {
            container.innerHTML = `
                <tr>
                    <td colspan="6">
                        <div style="text-align: center; padding: 60px 20px;">
                            <i class="fas fa-inbox" style="font-size: 48px; color: #bdc3c7;"></i>
                            <h3 style="color: #7f8c8d; margin: 20px 0 10px;">No Applications Found</h3>
                            <p style="color: #95a5a6;">No applications match your current filters.</p>
                            <button onclick="appSystem.showCreateModal()" style="margin-top: 20px; padding: 10px 20px; background: #3498db; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold;">
                                <i class="fas fa-plus"></i> Create Your First Application
                            </button>
                        </div>
                    </td>
                </tr>
            `;
            return;
        }

        container.innerHTML = applications.map(app => {
            const appDate = new Date(app.applicationDate);
            const formattedDate = appDate.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });

            // Status badge color
            const statusColors = {
                pending: '#f39c12',
                approved: '#27ae60',
                rejected: '#e74c3c',
                forwarded: '#3498db',
                implemented: '#9b59b6'
            };

            return `
                <tr>
                    <td><strong style="color: #2c3e50; font-size: 16px;">${app.applicationNo}</strong></td>
                    <td>${app.type}</td>
                    <td>${app.subject}</td>
                    <td>${formattedDate}</td>
                    <td>
                        <span style="display: inline-block; padding: 6px 15px; border-radius: 20px; font-size: 12px; font-weight: bold; background: ${statusColors[app.status] || '#95a5a6'}; color: white;">
                            ${app.status.charAt(0).toUpperCase() + app.status.slice(1)}
                        </span>
                    </td>
                    <td>
                        <button class="view-application-btn" 
                                data-app-id="${app._id}"
                                style="padding: 6px 15px; background: #3498db; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 13px; font-weight: bold;">
                            <i class="fas fa-eye"></i> View
                        </button>
                    </td>
                </tr>
            `;
        }).join('');

        // Add event listeners to view buttons
        this.setupViewButtons();
    }

    setupViewButtons() {
        // Get all view buttons
        const viewButtons = document.querySelectorAll('.view-application-btn');
        
        viewButtons.forEach(button => {
            // Remove existing listeners first
            const newButton = button.cloneNode(true);
            button.parentNode.replaceChild(newButton, button);
            
            // Add new listener
            newButton.addEventListener('click', (e) => {
                const appId = e.currentTarget.getAttribute('data-app-id');
                console.log('👆 View button clicked for app:', appId);
                this.viewApplication(appId);
            });
        });
        
        console.log(`✅ Added click handlers to ${viewButtons.length} view buttons`);
    }

    // FIXED: This function should be accessible
    viewApplication(appId) {
        console.log('🔍 Opening application details for:', appId);
        
        // Combine demo and stored apps for viewing
        const storedApps = JSON.parse(localStorage.getItem('student_applications')) || [];
        const allApps = [...storedApps, ...this.demoApplications];
        
        // Find the application
        const app = allApps.find(a => a._id === appId);
        
        if (!app) {
            console.error('❌ Application not found:', appId);
            this.showNotification('Application not found', 'error', 3000);
            return;
        }
        
        // Render the details modal
        this.renderApplicationDetails(app);
    }

    renderApplicationDetails(app) {
        console.log('📄 Rendering application details for:', app.applicationNo);
        
        const modal = document.getElementById('appDetailsModal');
        if (!modal) {
            console.error('❌ Details modal not found');
            return;
        }

        // Get student info
        const userStr = localStorage.getItem('user');
        const student = userStr ? JSON.parse(userStr) : {
            fullName: 'Iqra Bibi',
            registrationNo: 'B23F0487SE076',
            department: 'Software Engineering',
            year: '3rd Year',
            group: 'Blue',
            cgpa: 3.12,
            sgpa: 2.82
        };

        // Format date
        const appDate = new Date(app.applicationDate);
        const formattedDate = appDate.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });

        // Status color
        const statusColors = {
            pending: '#f39c12',
            approved: '#27ae60',
            rejected: '#e74c3c',
            forwarded: '#3498db',
            implemented: '#9b59b6'
        };

        // Build activities HTML
        let activitiesHTML = '';
        if (app.activities && app.activities.length > 0) {
            activitiesHTML = app.activities.map(activity => {
                const activityDate = new Date(activity.date);
                const formattedActivityDate = activityDate.toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric'
                });

                return `
                    <div style="margin-bottom: 20px; padding-left: 20px; border-left: 3px solid #3498db; position: relative;">
                        <div style="position: absolute; left: -7px; top: 5px; width: 12px; height: 12px; border-radius: 50%; background: #3498db;"></div>
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 8px;">
                            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                                <strong>Activity#${activity.activityNo}</strong>
                                <span style="color: #666; font-size: 13px;">${formattedActivityDate}</span>
                            </div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 14px;">
                                <div>
                                    <div style="color: #666;">Forwarded By:</div>
                                    <div style="font-weight: bold;">${activity.forwardedBy.name}</div>
                                    <div style="color: #999; font-size: 12px;">${activity.forwardedBy.role}</div>
                                </div>
                                <div>
                                    <div style="color: #666;">Respond By:</div>
                                    <div style="font-weight: bold;">${activity.respondBy.name}</div>
                                    <div style="color: #999; font-size: 12px;">${activity.respondBy.role}</div>
                                </div>
                                <div>
                                    <div style="color: #666;">Response:</div>
                                    <span style="display: inline-block; padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: bold; background: ${activity.response === 'Approved' ? '#27ae60' : activity.response === 'Rejected' ? '#e74c3c' : '#3498db'}; color: white;">
                                        ${activity.response}
                                    </span>
                                </div>
                                <div>
                                    <div style="color: #666;">Forwarded To:</div>
                                    <div style="font-weight: bold;">${activity.forwardedTo.name}</div>
                                    <div style="color: #999; font-size: 12px;">${activity.forwardedTo.role}</div>
                                </div>
                            </div>
                            ${activity.remarks ? `
                                <div style="margin-top: 10px; padding-top: 10px; border-top: 1px dashed #ddd;">
                                    <div style="color: #666; font-size: 13px;">Remarks for student:</div>
                                    <div style="color: #333; font-weight: 500;">${activity.remarks}</div>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                `;
            }).join('');
        } else {
            activitiesHTML = `
                <div style="text-align: center; padding: 30px; color: #666; background: #f8f9fa; border-radius: 8px;">
                    <i class="fas fa-history" style="font-size: 40px; margin-bottom: 15px; opacity: 0.5;"></i>
                    <p>No activity recorded yet</p>
                </div>
            `;
        }

        // Build modal content
        const modalContent = `
            <div style="background: white; border-radius: 10px; max-height: 85vh; overflow-y: auto;">
                <!-- Header -->
                <div style="background: #2c3e50; color: white; padding: 20px; border-radius: 10px 10px 0 0;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <button onclick="appSystem.closeDetailsModal()" style="background: none; border: none; color: white; font-size: 16px; cursor: pointer; display: flex; align-items: center; gap: 5px;">
                            <i class="fas fa-arrow-left"></i> Back
                        </button>
                        <h2 style="margin: 0; font-size: 20px;">Application Activity</h2>
                        <button onclick="appSystem.closeDetailsModal()" style="background: none; border: none; color: white; font-size: 24px; cursor: pointer;">×</button>
                    </div>
                </div>

                <!-- Content -->
                <div style="padding: 20px;">
                    <!-- Student Info -->
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                        <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 15px;">
                            <div>
                                <div style="font-size: 13px; color: #666;">Reg No.</div>
                                <div style="font-weight: bold; color: #2c3e50;">${student.registrationNo}</div>
                            </div>
                            <div>
                                <div style="font-size: 13px; color: #666;">Group</div>
                                <div style="font-weight: bold; color: #2c3e50;">${student.group || 'Blue'}</div>
                            </div>
                            <div>
                                <div style="font-size: 13px; color: #666;">Last Session Details</div>
                                <div style="font-weight: bold; color: #2c3e50;">SPRING-2025 | SGPA: ${student.sgpa || '2.82'} | CGPA: ${student.cgpa || '3.12'}</div>
                            </div>
                        </div>
                        
                        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; border-top: 1px solid #ddd; padding-top: 15px;">
                            <div>
                                <div style="font-size: 13px; color: #666;">Application No.</div>
                                <div style="font-weight: bold; color: #2c3e50;">${app.applicationNo}</div>
                            </div>
                            <div>
                                <div style="font-size: 13px; color: #666;">Subject</div>
                                <div style="font-weight: bold; color: #2c3e50;">${app.subject}</div>
                            </div>
                            <div>
                                <div style="font-size: 13px; color: #666;">Status</div>
                                <div>
                                    <span style="display: inline-block; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: bold; background: ${statusColors[app.status]}; color: white;">
                                        ${app.status.charAt(0).toUpperCase() + app.status.slice(1)}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Action Status -->
                    <div style="background: #e8f4fd; padding: 20px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #3498db;">
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
                            <div style="width: 12px; height: 12px; border-radius: 50%; background: #3498db;"></div>
                            <h3 style="margin: 0; color: #2c3e50;">Action Status</h3>
                        </div>
                        <div style="margin-left: 22px;">
                            <div style="background: white; padding: 15px; border-radius: 6px; border: 1px solid #ddd;">
                                <p style="margin: 0; line-height: 1.6; color: #333;">${app.message}</p>
                            </div>
                        </div>
                    </div>

                    <!-- Attachment -->
                    <div style="background: #f8f9fa; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                        <div style="font-size: 13px; color: #666;">Attachment</div>
                        <div style="color: #999; font-style: italic;">No attachment available</div>
                    </div>

                    <!-- Student Details Box -->
                    <div style="background: #f0f7ff; padding: 20px; border-radius: 8px; margin-bottom: 20px; border: 1px solid #cce5ff;">
                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                            <div>
                                <div style="font-size: 13px; color: #666;">Name</div>
                                <div style="font-weight: bold; color: #2c3e50;">${student.fullName}</div>
                            </div>
                            <div>
                                <div style="font-size: 13px; color: #666;">Program</div>
                                <div style="font-weight: bold; color: #2c3e50;">Bachelor of Science in Software Engineering</div>
                            </div>
                            <div>
                                <div style="font-size: 13px; color: #666;">Application Type</div>
                                <div style="font-weight: bold; color: #2c3e50;">${app.type} ${app.type === 'Adjustment' ? '(Not Extension)' : ''}</div>
                            </div>
                            <div>
                                <div style="font-size: 13px; color: #666;">Application Date</div>
                                <div style="font-weight: bold; color: #2c3e50;">${formattedDate}</div>
                            </div>
                        </div>
                    </div>

                    <!-- Application Status -->
                    <div style="margin-bottom: 20px;">
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 15px;">
                            <i class="fas fa-tasks" style="color: #3498db;"></i>
                            <h3 style="margin: 0; color: #2c3e50;">Application Status</h3>
                        </div>
                        <div style="background: white; padding: 15px; border-radius: 8px; border: 1px solid #ddd;">
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div style="width: 12px; height: 12px; border-radius: 50%; background: #28a745;"></div>
                                <span style="font-weight: bold; color: #28a745;">● ${app.status.charAt(0).toUpperCase() + app.status.slice(1)}</span>
                            </div>
                        </div>
                    </div>

                    <!-- All Activity Section -->
                    <div>
                        <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 20px;">
                            <i class="fas fa-history" style="color: #3498db;"></i>
                            <h3 style="margin: 0; color: #2c3e50;">All activity</h3>
                        </div>
                        
                        ${activitiesHTML}
                    </div>
                </div>
            </div>
        `;

        // Set modal content and show
        modal.innerHTML = modalContent;
        modal.style.display = 'block';
        document.body.style.overflow = 'hidden';

        // Add click outside to close
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                this.closeDetailsModal();
            }
        });
    }

    closeDetailsModal() {
        const modal = document.getElementById('appDetailsModal');
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }
    }

    async submitApplication() {
        console.log('📤 Submitting application...');
        
        const type = document.getElementById('appType').value;
        const subject = document.getElementById('appSubject').value;
        const message = document.getElementById('appMessage').value;
        
        if (!type || !subject || !message) {
            this.showNotification('Please fill all required fields!', 'error', 3000);
            return;
        }
        
        // Generate new application number
        const nextAppNumber = this.generateNextApplicationNumber();
        
        const submitBtn = document.querySelector('.btn-submit');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
        submitBtn.disabled = true;
        
        // Simulate submission delay
        setTimeout(() => {
            // Create new application object with PENDING status
            const newApplication = {
                _id: 'new_' + Date.now(), // Unique ID
                applicationNo: nextAppNumber, // e.g., APP006
                type: type,
                subject: subject,
                message: message,
                applicationDate: new Date().toISOString(),
                status: 'pending', // ALWAYS start as PENDING
                attachments: [],
                activities: [
                    {
                        activityNo: 1,
                        forwardedBy: { name: this.user.registrationNo, role: 'Student' },
                        respondBy: { name: 'System', role: 'System' },
                        response: 'Submitted',
                        forwardedTo: { name: 'Pending Review', role: 'Reviewer' },
                        date: new Date().toISOString(),
                        remarks: 'Application submitted successfully and is pending review.'
                    }
                ]
            };
            
            // Save to localStorage
            this.saveApplicationToStorage(newApplication);
            
            // Show success notification
            this.showNotification(
                `✅ Application submitted successfully!\nApplication No: ${newApplication.applicationNo}\nStatus: Pending`,
                'success',
                5000
            );
            
            // Reset form
            document.getElementById('applicationForm').reset();
            document.getElementById('fileName').textContent = 'No file chosen';
            document.getElementById('charRemaining').textContent = '1200';
            
            // Reset button
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
            
            // Hide modal
            this.hideCreateModal();
            
            // Reload applications to show the new one
            this.loadApplications();
            
        }, 1500);
    }

    generateNextApplicationNumber() {
        // Get all existing apps
        const storedApps = JSON.parse(localStorage.getItem('student_applications')) || [];
        const allApps = [...storedApps, ...this.demoApplications];
        
        // Find highest app number
        let highestNum = 0;
        allApps.forEach(app => {
            if (app.applicationNo.startsWith('APP')) {
                const num = parseInt(app.applicationNo.replace('APP', ''));
                if (!isNaN(num) && num > highestNum) {
                    highestNum = num;
                }
            }
        });
        
        // Generate next number
        const nextNum = highestNum + 1;
        return `APP${nextNum.toString().padStart(3, '0')}`;
    }

    saveApplicationToStorage(application) {
        // Get existing stored applications
        let storedApps = JSON.parse(localStorage.getItem('student_applications')) || [];
        
        // Add new application at the beginning (most recent first)
        storedApps.unshift(application);
        
        // Save back to localStorage
        localStorage.setItem('student_applications', JSON.stringify(storedApps));
        
        console.log('💾 Saved new application:', application.applicationNo);
    }

    showNotification(message, type = 'success', duration = 3000) {
        const toast = document.createElement('div');
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db'};
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            z-index: 9999;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            animation: slideIn 0.3s ease;
            max-width: 400px;
            word-wrap: break-word;
            white-space: pre-line;
        `;
        toast.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'}"></i>
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(toast);
        
        // Add animation styles
        if (!document.querySelector('#toast-animations')) {
            const style = document.createElement('style');
            style.id = 'toast-animations';
            style.textContent = `
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
            `;
            document.head.appendChild(style);
        }
        
        setTimeout(() => {
            toast.style.animation = 'slideIn 0.3s ease reverse';
            setTimeout(() => {
                if (toast.parentNode) {
                    toast.parentNode.removeChild(toast);
                }
            }, 300);
        }, duration);
    }

    showCreateModal() {
        const modal = document.getElementById('createAppModal');
        if (modal) {
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
        }
    }

    hideCreateModal() {
        const modal = document.getElementById('createAppModal');
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }
    }

    updateCharCounter(text) {
        const remaining = 1200 - text.length;
        const counter = document.getElementById('charRemaining');
        if (counter) {
            counter.textContent = remaining;
            counter.style.color = remaining < 100 ? '#e74c3c' : '#7f8c8d';
        }
    }

    renderPagination(pagination) {
        const container = document.getElementById('pagination');
        if (!container) return;

        const totalPages = pagination?.pages || 1;
        this.totalPages = totalPages;

        let html = '<div style="display: flex; justify-content: center; align-items: center; gap: 10px; padding: 20px;">';
        
        if (this.currentPage > 1) {
            html += `
                <button class="page-btn" onclick="appSystem.changePage(${this.currentPage - 1})">
                    ← Previous
                </button>
            `;
        }

        for (let i = 1; i <= totalPages; i++) {
            if (i === this.currentPage) {
                html += `<button class="page-btn" style="background:#3498db;color:white;" disabled>${i}</button>`;
            } else {
                html += `<button class="page-btn" onclick="appSystem.changePage(${i})">${i}</button>`;
            }
        }

        if (this.currentPage < totalPages) {
            html += `
                <button class="page-btn" onclick="appSystem.changePage(${this.currentPage + 1})">
                    Next →
                </button>
            `;
        }

        html += `<span class="page-info">Page ${this.currentPage} of ${totalPages} | Total: ${pagination?.total || 0}</span>`;
        html += '</div>';
        
        container.innerHTML = html;
    }

    changePage(page) {
        this.currentPage = page;
        this.loadApplications();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

// Initialize the application system
let appSystem;

document.addEventListener('DOMContentLoaded', () => {
    console.log('📄 Applications page loaded');
    appSystem = new ApplicationSystem();
    window.appSystem = appSystem; // Make it globally accessible
});