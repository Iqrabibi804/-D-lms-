
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize tab switching
            initTabs();
            
            // Load all assessments table data
            loadAllAssessments();
            
            // Back button functionality
            const backButton = document.querySelector('.back-button');
            backButton.addEventListener('click', function(event) {
                event.preventDefault();
                window.location.href = backButton.getAttribute('href');
            });
            
            // Close modal when clicking outside
            const modalOverlay = document.getElementById('detailsModal');
            modalOverlay.addEventListener('click', function(event) {
                if (event.target === modalOverlay) {
                    closeModal();
                }
            });
        });
        
        function initTabs() {
            const tabButtons = document.querySelectorAll('.tab-btn');
            const tables = document.querySelectorAll('.table-container');
            
            tabButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const tabId = this.getAttribute('data-tab');
                    
                    // Update active tab button
                    tabButtons.forEach(btn => btn.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Show corresponding table
                    tables.forEach(table => {
                        table.classList.remove('active');
                        if (table.id === `${tabId}-table`) {
                            table.classList.add('active');
                        }
                    });
                });
            });
        }
        
        function loadAllAssessments() {
            // This would typically come from an API or database
            // For now, we'll populate with the 8 assessments
            const allTableBody = document.querySelector('#all-table tbody');
            
            const allAssessments = [
                { no: 1, name: 'Assignment 1', start: '9/1/2025', end: '9/5/2025', marks: '10.00', weight: '2.50%', type: 'Assignment', attachment: true },
                { no: 2, name: 'Quiz 1', start: '9/3/2025', end: '9/23/2025', marks: '10.00', weight: '2.50%', type: 'Quiz', attachment: true },
                { no: 3, name: 'Assignment 2', start: '9/30/2025', end: '10/6/2025', marks: '10.00', weight: '2.50%', type: 'Assignment', attachment: true },
                { no: 4, name: 'Quiz 2', start: '10/8/2025', end: '10/8/2025', marks: '10.00', weight: '2.50%', type: 'Quiz', attachment: true },
                { no: 5, name: 'Mid-Semester Exam', start: '10/23/2025', end: '10/23/2025', marks: '25.00', weight: '25.00%', type: 'Exam', attachment: true },
                { no: 6, name: 'Assignment 3', start: '10/29/2025', end: '11/4/2025', marks: '10.00', weight: '2.50%', type: 'Assignment', attachment: true },
                { no: 7, name: 'Quiz 3', start: '11/11/2025', end: '11/11/2025', marks: '10.00', weight: '2.50%', type: 'Quiz', attachment: false },
                { no: 8, name: 'Assignment 4', start: '11/18/2025', end: '11/26/2025', marks: '10.00', weight: '2.50%', type: 'Assignment', attachment: true }
            ];
            
            allAssessments.forEach(assessment => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td class="marks-cell">${assessment.no}</td>
                    <td>
                        <div class="assessment-name">
                            ${assessment.name}
                            <span class="status-badge status-completed">
                                <i class="fas fa-check-circle"></i> COMPLETED
                            </span>
                        </div>
                    </td>
                    <td class="date-cell">${assessment.start}</td>
                    <td class="date-cell">${assessment.end}</td>
                    <td class="marks-cell">${assessment.marks}</td>
                    <td class="weightage-cell">${assessment.weight}</td>
                    <td class="type-cell">
                        <span class="type-badge">${assessment.type}</span>
                    </td>
                    <td class="attachment-cell">
                        <span class="attachment-icon ${assessment.attachment ? 'has-attachment' : ''}">
                            <i class="fas ${assessment.attachment ? 'fa-check-circle' : 'fa-times-circle'}"></i>
                        </span>
                    </td>
                    <td class="actions-cell">
                        <div class="action-buttons">
                            <button class="action-btn" onclick="viewDetails('${assessment.name}', '${assessment.type.toLowerCase()}')">
                                <i class="fas fa-eye"></i> View Details
                            </button>
                            ${getActionButton(assessment)}
                        </div>
                    </td>
                `;
                allTableBody.appendChild(row);
            });
        }
        
        function getActionButton(assessment) {
            if (assessment.type === 'Assignment') {
                return `<button class="action-btn" onclick="downloadAssessment('${assessment.name}')">
                    <i class="fas fa-download"></i> Download
                </button>`;
            } else if (assessment.type === 'Quiz') {
                return `<button class="action-btn" onclick="startQuiz('${assessment.name}')">
                    <i class="fas fa-play-circle"></i> Start Quiz
                </button>`;
            } else if (assessment.type === 'Exam') {
                return `<button class="action-btn" onclick="viewSyllabus('${assessment.name}')">
                    <i class="fas fa-book"></i> Syllabus
                </button>`;
            }
            return '';
        }
        
        // Modal Functions
        function viewDetails(assessmentName, type) {
            const modal = document.getElementById('detailsModal');
            const modalTitle = document.getElementById('modalTitle');
            const modalBody = document.getElementById('modalBody');
            
            modalTitle.textContent = `${assessmentName} - Details`;
            
            // Generate modal content based on assessment type
            let modalContent = '';
            
            if (type === 'assignment') {
                modalContent = `
                    <div class="modal-section">
                        <h4><i class="fas fa-info-circle"></i> Assignment Information</h4>
                        <div class="modal-details">
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Assignment Name</div>
                                <div class="modal-detail-value">${assessmentName}</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Type</div>
                                <div class="modal-detail-value">Individual Assignment</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Status</div>
                                <div class="modal-detail-value"><span class="status-badge status-completed">COMPLETED</span></div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Total Marks</div>
                                <div class="modal-detail-value">10.00</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Weightage</div>
                                <div class="modal-detail-value">2.50%</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-section">
                        <h4><i class="fas fa-calendar-alt"></i> Timeline</h4>
                        <div class="modal-details">
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Start Date</div>
                                <div class="modal-detail-value">${getAssessmentDate(assessmentName, 'start')}</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">End Date</div>
                                <div class="modal-detail-value">${getAssessmentDate(assessmentName, 'end')}</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Duration</div>
                                <div class="modal-detail-value">5 Days</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-section">
                        <h4><i class="fas fa-file-alt"></i> Description</h4>
                        <p>This assignment covers the fundamentals of mobile application development including UI design, basic functionality implementation, and debugging techniques for COMP-313 course.</p>
                    </div>
                    
                    <div class="modal-section">
                        <h4><i class="fas fa-download"></i> Actions</h4>
                        <div class="action-buttons" style="justify-content: flex-start;">
                            <button class="action-btn" onclick="downloadAssessment('${assessmentName}')">
                                <i class="fas fa-download"></i> Download Assignment
                            </button>
                            <button class="action-btn" onclick="submitAssignment('${assessmentName}')">
                                <i class="fas fa-upload"></i> Submit Solution
                            </button>
                        </div>
                    </div>
                `;
            } else if (type === 'quiz') {
                modalContent = `
                    <div class="modal-section">
                        <h4><i class="fas fa-info-circle"></i> Quiz Information</h4>
                        <div class="modal-details">
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Quiz Name</div>
                                <div class="modal-detail-value">${assessmentName}</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Type</div>
                                <div class="modal-detail-value">Online Quiz</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Status</div>
                                <div class="modal-detail-value"><span class="status-badge status-completed">COMPLETED</span></div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Total Marks</div>
                                <div class="modal-detail-value">10.00</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Weightage</div>
                                <div class="modal-detail-value">2.50%</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-section">
                        <h4><i class="fas fa-calendar-alt"></i> Timeline</h4>
                        <div class="modal-details">
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Start Date</div>
                                <div class="modal-detail-value">${getAssessmentDate(assessmentName, 'start')}</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">End Date</div>
                                <div class="modal-detail-value">${getAssessmentDate(assessmentName, 'end')}</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Duration</div>
                                <div class="modal-detail-value">30 Minutes</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-section">
                        <h4><i class="fas fa-question-circle"></i> Quiz Details</h4>
                        <p>This quiz covers topics from Weeks 1-4 of the COMP-313 course including mobile UI components, activity lifecycle, and basic event handling.</p>
                        <ul style="margin-top: 10px; padding-left: 20px;">
                            <li>Total Questions: 20</li>
                            <li>Question Types: Multiple Choice, True/False</li>
                            <li>Time Limit: 30 minutes</li>
                            <li>Attempts Allowed: 2</li>
                        </ul>
                    </div>
                    
                    <div class="modal-section">
                        <h4><i class="fas fa-play-circle"></i> Actions</h4>
                        <div class="action-buttons" style="justify-content: flex-start;">
                            <button class="action-btn" onclick="startQuiz('${assessmentName}')">
                                <i class="fas fa-play-circle"></i> Start Quiz
                            </button>
                            <button class="action-btn" onclick="viewQuizResults('${assessmentName}')">
                                <i class="fas fa-chart-bar"></i> View Results
                            </button>
                        </div>
                    </div>
                `;
            } else if (type === 'exam') {
                modalContent = `
                    <div class="modal-section">
                        <h4><i class="fas fa-info-circle"></i> Exam Information</h4>
                        <div class="modal-details">
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Exam Name</div>
                                <div class="modal-detail-value">${assessmentName}</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Type</div>
                                <div class="modal-detail-value">Mid-Semester Examination</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Status</div>
                                <div class="modal-detail-value"><span class="status-badge status-completed">COMPLETED</span></div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Total Marks</div>
                                <div class="modal-detail-value">25.00</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Weightage</div>
                                <div class="modal-detail-value">25.00%</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-section">
                        <h4><i class="fas fa-calendar-alt"></i> Timeline</h4>
                        <div class="modal-details">
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Exam Date</div>
                                <div class="modal-detail-value">${getAssessmentDate(assessmentName, 'start')}</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Duration</div>
                                <div class="modal-detail-value">3 Hours</div>
                            </div>
                            <div class="modal-detail-item">
                                <div class="modal-detail-label">Venue</div>
                                <div class="modal-detail-value">Main Campus - Room 304</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-section">
                        <h4><i class="fas fa-book"></i> Syllabus</h4>
                        <p>The mid-semester exam covers all topics from Weeks 1-8 of the COMP-313 Mobile Application Development course.</p>
                        <ul style="margin-top: 10px; padding-left: 20px;">
                            <li>Introduction to Mobile Development</li>
                            <li>Android Studio and Development Environment</li>
                            <li>User Interface Design</li>
                            <li>Activities and Intents</li>
                            <li>Data Storage (SharedPreferences, SQLite)</li>
                            <li>Networking and Web Services</li>
                        </ul>
                    </div>
                    
                    <div class="modal-section">
                        <h4><i class="fas fa-download"></i> Resources</h4>
                        <div class="action-buttons" style="justify-content: flex-start;">
                            <button class="action-btn" onclick="downloadSyllabus('${assessmentName}')">
                                <i class="fas fa-download"></i> Download Syllabus
                            </button>
                            <button class="action-btn" onclick="viewPastPapers('${assessmentName}')">
                                <i class="fas fa-file-pdf"></i> Past Papers
                            </button>
                        </div>
                    </div>
                `;
            }
            
            modalBody.innerHTML = modalContent;
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }
        
        function closeModal() {
            const modal = document.getElementById('detailsModal');
            modal.classList.remove('active');
            document.body.style.overflow = 'auto';
        }
        
        function getAssessmentDate(assessmentName, type) {
            // Mock data for dates
            const dates = {
                'Assignment 1': { start: '9/1/2025', end: '9/5/2025' },
                'Quiz 1': { start: '9/3/2025', end: '9/23/2025' },
                'Assignment 2': { start: '9/30/2025', end: '10/6/2025' },
                'Quiz 2': { start: '10/8/2025', end: '10/8/2025' },
                'Mid-Semester Exam': { start: '10/23/2025', end: '10/23/2025' },
                'Assignment 3': { start: '10/29/2025', end: '11/4/2025' },
                'Quiz 3': { start: '11/11/2025', end: '11/11/2025' },
                'Assignment 4': { start: '11/18/2025', end: '11/26/2025' }
            };
            
            return dates[assessmentName] ? dates[assessmentName][type] : 'N/A';
        }
        
        // Action Functions
        function downloadAssessment(assessmentName) {
            alert(`Downloading ${assessmentName}...`);
            closeModal();
        }
        
        function startQuiz(quizName) {
            alert(`Starting ${quizName}...\nYou will be redirected to the quiz interface.`);
            closeModal();
        }
        
        function viewSyllabus(examName) {
            alert(`Viewing syllabus for ${examName}...`);
            closeModal();
        }
        
        function submitAssignment(assignmentName) {
            alert(`Opening submission page for ${assignmentName}...`);
            closeModal();
        }
        
        function viewQuizResults(quizName) {
            alert(`Viewing results for ${quizName}...`);
            closeModal();
        }
        
        function downloadSyllabus(examName) {
            alert(`Downloading syllabus for ${examName}...`);
            closeModal();
        }
        
        function viewPastPapers(examName) {
            alert(`Viewing past papers for ${examName}...`);
            closeModal();
        }
   