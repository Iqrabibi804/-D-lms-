// API Configuration
const API_BASE_URL = 'http://localhost:5000/api';
let currentUser = null;

// ==================== AUTH FUNCTIONS ====================
function checkAuth() {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    
    if (!token || !userData) {
        // If on protected page, redirect to login
        const currentPage = window.location.pathname.split('/').pop();
        if (currentPage !== '1.html' && currentPage !== '') {
            window.location.href = '1.html';
        }
        return false;
    }
    
    try {
        currentUser = JSON.parse(userData);
        updateUIWithUser(currentUser);
        return true;
    } catch (error) {
        console.error('Error parsing user data:', error);
        return false;
    }
}

async function login(email, password) {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user || data.data));
            showNotification('Login successful!', 'success');
            
            // Redirect to dashboard after 1 second
            setTimeout(() => {
                window.location.href = 'dashboard.html';
            }, 1000);
        } else {
            showNotification(data.message || 'Login failed', 'error');
        }
    } catch (error) {
        console.error('Login error:', error);
        showNotification('Server connection failed', 'error');
    }
}

async function register(userData) {
    try {
        const response = await fetch(`${API_BASE_URL}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Registration successful!', 'success');
            return data;
        } else {
            showNotification(data.message || 'Registration failed', 'error');
            return null;
        }
    } catch (error) {
        console.error('Registration error:', error);
        showNotification('Server connection failed', 'error');
        return null;
    }
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    currentUser = null;
    showNotification('Logged out successfully', 'success');
    window.location.href = '1.html';
}

function updateUIWithUser(user) {
    // Update user name in dashboard
    const userNameElements = document.querySelectorAll('#user-name, .user-name');
    userNameElements.forEach(element => {
        element.textContent = user.fullName || user.name || user.email;
    });
    
    // Update profile image
    const profileImage = document.getElementById('profile-image');
    if (profileImage && user.profileImage) {
        profileImage.src = user.profileImage;
    }
    
    // Update student ID if exists
    const studentIdElement = document.getElementById('student-id');
    if (studentIdElement && user.studentId) {
        studentIdElement.textContent = user.studentId;
    }
}

// ==================== API REQUEST HELPER ====================
async function apiRequest(endpoint, options = {}) {
    const token = localStorage.getItem('token');
    
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': token ? `Bearer ${token}` : ''
        }
    };
    
    const config = { ...defaultOptions, ...options };
    
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
        
        // Handle 401 Unauthorized
        if (response.status === 401) {
            logout();
            throw new Error('Session expired. Please login again.');
        }
        
        const data = await response.json();
        
        if (!data.success && data.message) {
            showNotification(data.message, 'error');
        }
        
        return data;
    } catch (error) {
        console.error(`API Error (${endpoint}):`, error);
        showNotification(error.message || 'Server connection failed', 'error');
        throw error;
    }
}

// ==================== DASHBOARD FUNCTIONS ====================
async function loadDashboardData() {
    if (!checkAuth()) return;
    
    try {
        // Load multiple data in parallel
        const [coursesData, noticesData, attendanceData] = await Promise.allSettled([
            apiRequest('/courses'),
            apiRequest('/notices'),
            apiRequest('/attendance')
        ]);
        
        // Update dashboard stats
        updateDashboardStats(coursesData, noticesData, attendanceData);
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

function updateDashboardStats(coursesData, noticesData, attendanceData) {
    // Update courses count
    if (coursesData.status === 'fulfilled' && coursesData.value.data) {
        const coursesCount = document.getElementById('courses-count');
        if (coursesCount) {
            coursesCount.textContent = coursesData.value.data.length;
        }
    }
    
    // Update notices count
    if (noticesData.status === 'fulfilled' && noticesData.value.data) {
        const noticesCount = document.getElementById('notices-count');
        if (noticesCount) {
            noticesCount.textContent = noticesData.value.data.length;
        }
    }
    
    // Update attendance percentage
    if (attendanceData.status === 'fulfilled' && attendanceData.value.data) {
        const attendancePercent = document.getElementById('attendance-percent');
        if (attendancePercent && attendanceData.value.data.length > 0) {
            // Calculate average attendance from all courses
            const totalPercentage = attendanceData.value.data.reduce((sum, item) => {
                return sum + (item.percentage || 0);
            }, 0);
            const averagePercentage = totalPercentage / attendanceData.value.data.length;
            attendancePercent.textContent = `${averagePercentage.toFixed(1)}%`;
        }
    }
}

// Dashboard card click handlers
function setupDashboardCards() {
    document.querySelectorAll('.cards').forEach(card => {
        card.addEventListener('click', async () => {
            if (!checkAuth()) return;
            
            const cardText = card.querySelector('p')?.textContent?.trim();
            
            switch(cardText) {
                case 'MY PROFILE':
                    await loadProfile();
                    break;
                    
                case 'MY COURSES':
                    await loadCourses();
                    break;
                    
                case 'FEE VOUCHERS':
                    await loadFees();
                    break;
                    
                case 'ASSIGNMENTS':
                    await loadAssignments();
                    break;
                    
                case 'MY ATTENDANCE':
                    await loadAttendance();
                    break;
                    
                case 'NOTICE BOARD':
                    await loadNotices();
                    break;
                    
                case 'PROJECT':
                    await loadProjects();
                    break;
                    
                case 'EXAM & RESULTS':
                    await loadExams();
                    break;
                    
                case 'TRANSCRIPT & DEGREE':
                    await loadTranscript();
                    break;
                    
                case 'PROMOTIONS':
                    await loadPromotions();
                    break;
                    
                case 'LIBRARY':
                    await loadLibrary();
                    break;
                    
                case 'AWARDS':
                    await loadAwards();
                    break;
                    
                default:
                    console.log('Card clicked:', cardText);
            }
        });
    });
}

// ==================== PROFILE FUNCTIONS ====================
async function loadProfile() {
    try {
        const response = await apiRequest('/profile');
        const user = response.data || currentUser;
        
        const container = document.getElementById('container');
        container.innerHTML = `
            <div class="profile-container">
                <div class="profile-header">
                    <img src="${user.profileImage || 'profile.png'}" alt="Profile" class="profile-img">
                    <h2>${user.fullName || user.name || 'User'}</h2>
                    <p>${user.studentId || 'N/A'} | ${user.department || 'N/A'} | ${user.year || 'N/A'}</p>
                </div>
                
                <div class="profile-details">
                    <div class="detail-card">
                        <h3>📧 Email</h3>
                        <p>${user.email || 'N/A'}</p>
                    </div>
                    
                    <div class="detail-card">
                        <h3>🎓 CGPA</h3>
                        <p>${user.cgpa || '8.5'}</p>
                    </div>
                    
                    <div class="detail-card">
                        <h3>📞 Phone</h3>
                        <p>${user.phone || '+91 9876543210'}</p>
                    </div>
                    
                    <div class="detail-card">
                        <h3>📍 Address</h3>
                        <p>${user.address || '123 University Street, City'}</p>
                    </div>
                </div>
                
                <button onclick="editProfile()" class="btn-primary">Edit Profile</button>
            </div>
        `;
    } catch (error) {
        console.error('Error loading profile:', error);
        showNotification('Error loading profile', 'error');
    }
}

async function editProfile() {
    // Implement profile editing logic
    showNotification('Profile editing feature coming soon', 'info');
}

// ==================== COURSES FUNCTIONS ====================
async function loadCourses() {
    try {
        const response = await apiRequest('/courses');
        const courses = response.data || [];
        
        const container = document.getElementById('container');
        container.innerHTML = `
            <div class="section-header">
                <h2>📚 My Courses</h2>
                <button onclick="loadAvailableCourses()" class="btn-secondary">Browse Courses</button>
            </div>
            
            <div class="courses-grid" id="coursesList">
                ${courses.length > 0 ? courses.map(course => `
                    <div class="course-card">
                        <div class="course-header">
                            <h3>${course.code || 'N/A'}</h3>
                            <span class="badge">${course.credits || 0} Credits</span>
                        </div>
                        <h4>${course.title || 'Untitled Course'}</h4>
                        <p><strong>Description:</strong> ${course.description || 'No description'}</p>
                        <div class="course-actions">
                            <button onclick="viewCourseDetails('${course.id || course._id}')" class="btn-small">View</button>
                            <button onclick="openCourseMaterials('${course.id || course._id}')" class="btn-small">Materials</button>
                        </div>
                    </div>
                `).join('') : 
                `<div class="empty-state">
                    <p>No courses enrolled yet.</p>
                    <button onclick="loadAvailableCourses()" class="btn-primary">Browse Available Courses</button>
                </div>`
                }
            </div>
        `;
    } catch (error) {
        console.error('Error loading courses:', error);
        showNotification('Error loading courses', 'error');
    }
}

async function loadAvailableCourses() {
    showNotification('Available courses feature coming soon', 'info');
}

function viewCourseDetails(courseId) {
    showNotification(`Viewing course ${courseId}`, 'info');
}

function openCourseMaterials(courseId) {
    showNotification(`Opening materials for course ${courseId}`, 'info');
}

// ==================== FEES FUNCTIONS ====================
async function loadFees() {
    try {
        const response = await apiRequest('/fees');
        const feesData = response.data || {};
        
        const container = document.getElementById('container');
        container.innerHTML = `
            <div class="section-header">
                <h2>💰 Fee Management</h2>
                <button onclick="downloadFeeReceipt()" class="btn-secondary">Download Receipt</button>
            </div>
            
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Paid</h3>
                    <h1>₹${feesData.paid || 0}</h1>
                </div>
                <div class="stat-card warning">
                    <h3>Pending</h3>
                    <h1>₹${feesData.due || 0}</h1>
                </div>
                <div class="stat-card info">
                    <h3>Total Amount</h3>
                    <h1>₹${(feesData.paid || 0) + (feesData.due || 0)}</h1>
                </div>
            </div>
            
            ${feesData.transactions ? `
            <div class="fees-table">
                <h3>Transaction History</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Mode</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${feesData.transactions.map(transaction => `
                            <tr>
                                <td>${transaction.date || 'N/A'}</td>
                                <td>₹${transaction.amount || 0}</td>
                                <td>${transaction.mode || 'N/A'}</td>
                                <td>
                                    <span class="status-badge ${transaction.status || 'completed'}">
                                        ${(transaction.status || 'completed').toUpperCase()}
                                    </span>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>` : ''}
        `;
    } catch (error) {
        console.error('Error loading fees:', error);
        showNotification('Error loading fee details', 'error');
    }
}

function downloadFeeReceipt() {
    showNotification('Downloading receipt...', 'info');
}

// ==================== ATTENDANCE FUNCTIONS ====================
async function loadAttendance() {
    try {
        const response = await apiRequest('/attendance');
        const attendanceData = response.data || [];
        
        // Calculate statistics
        let totalClasses = 0;
        let attendedClasses = 0;
        
        attendanceData.forEach(item => {
            totalClasses += item.totalClasses || 0;
            attendedClasses += item.attended || 0;
        });
        
        const attendancePercentage = totalClasses > 0 ? ((attendedClasses / totalClasses) * 100).toFixed(1) : 0;
        
        const container = document.getElementById('container');
        container.innerHTML = `
            <div class="section-header">
                <h2>📅 Attendance</h2>
                <div class="attendance-stats">
                    <div class="stat-circle">
                        <h1>${attendancePercentage}%</h1>
                        <p>Overall Attendance</p>
                    </div>
                    <div class="stat-details">
                        <p><strong>Present:</strong> ${attendedClasses}</p>
                        <p><strong>Absent:</strong> ${totalClasses - attendedClasses}</p>
                        <p><strong>Total Classes:</strong> ${totalClasses}</p>
                    </div>
                </div>
            </div>
            
            ${attendanceData.length > 0 ? `
            <div class="attendance-table">
                <table>
                    <thead>
                        <tr>
                            <th>Course</th>
                            <th>Total Classes</th>
                            <th>Attended</th>
                            <th>Percentage</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${attendanceData.map(record => `
                            <tr>
                                <td>${record.course || 'N/A'}</td>
                                <td>${record.totalClasses || 0}</td>
                                <td>${record.attended || 0}</td>
                                <td>${record.percentage || 0}%</td>
                                <td>
                                    <span class="status-badge ${(record.percentage || 0) >= 75 ? 'present' : 'absent'}">
                                        ${(record.percentage || 0) >= 75 ? 'GOOD' : 'LOW'}
                                    </span>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>` : 
            `<div class="empty-state">
                <p>No attendance records found.</p>
            </div>`
            }
        `;
    } catch (error) {
        console.error('Error loading attendance:', error);
        showNotification('Error loading attendance', 'error');
    }
}

// ==================== NOTICES FUNCTIONS ====================
async function loadNotices() {
    try {
        const response = await apiRequest('/notices');
        const notices = response.data || [];
        
        const container = document.getElementById('container');
        container.innerHTML = `
            <div class="section-header">
                <h2>📢 Notice Board</h2>
                <div class="filter-options">
                    <select id="noticeFilter" onchange="filterNotices()">
                        <option value="all">All Notices</option>
                        <option value="important">Important</option>
                        <option value="academic">Academic</option>
                        <option value="exam">Exam</option>
                    </select>
                </div>
            </div>
            
            <div class="notices-container">
                ${notices.length > 0 ? notices.map(notice => `
                    <div class="notice-card ${notice.category === 'important' ? 'important' : ''}">
                        <div class="notice-header">
                            <h3>${notice.title || 'Untitled Notice'}</h3>
                            <span class="notice-category">${notice.category || 'general'}</span>
                            ${notice.category === 'important' ? '<span class="notice-important">❗ Important</span>' : ''}
                        </div>
                        <div class="notice-content">
                            <p>${notice.content || 'No content available'}</p>
                        </div>
                        <div class="notice-footer">
                            <span>📅 ${notice.date || new Date().toLocaleDateString()}</span>
                            <button onclick="viewNoticeDetails('${notice.id || notice._id}')" class="btn-small">Read More</button>
                        </div>
                    </div>
                `).join('') : 
                `<div class="empty-state">
                    <p>No notices available.</p>
                </div>`
                }
            </div>
        `;
    } catch (error) {
        console.error('Error loading notices:', error);
        showNotification('Error loading notices', 'error');
    }
}

function filterNotices() {
    const filterValue = document.getElementById('noticeFilter').value;
    showNotification(`Filtering notices by: ${filterValue}`, 'info');
}

function viewNoticeDetails(noticeId) {
    showNotification(`Viewing notice ${noticeId}`, 'info');
}

// ==================== ASSIGNMENTS FUNCTIONS ====================
async function loadAssignments() {
    try {
        // Note: You need to create /assignments API endpoint
        showNotification('Assignments feature coming soon', 'info');
        
        // Mock data for now
        const assignments = [
            {
                id: 1,
                title: "Programming Assignment 1",
                course: "CS101 - Intro to Programming",
                dueDate: "2025-12-15",
                status: "pending",
                marks: 20
            }
        ];
        
        const container = document.getElementById('container');
        container.innerHTML = `
            <div class="section-header">
                <h2>📝 Assignments</h2>
                <button onclick="createNewAssignment()" class="btn-primary">New Assignment</button>
            </div>
            
            <div class="assignments-grid">
                ${assignments.map(assignment => `
                    <div class="assignment-card ${assignment.status}">
                        <div class="assignment-header">
                            <h3>${assignment.title}</h3>
                            <span class="assignment-status ${assignment.status}">
                                ${assignment.status.toUpperCase()}
                            </span>
                        </div>
                        <p class="assignment-course">${assignment.course}</p>
                        <p class="assignment-due">Due: ${assignment.dueDate}</p>
                        <p class="assignment-marks">Marks: ${assignment.marks}</p>
                        
                        <div class="assignment-actions">
                            <button onclick="viewAssignment(${assignment.id})" class="btn-small">
                                ${assignment.status === 'pending' ? 'Submit' : 'View'}
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    } catch (error) {
        console.error('Error loading assignments:', error);
        showNotification('Error loading assignments', 'error');
    }
}

// ==================== OTHER PAGES FUNCTIONS ====================
async function loadExams() {
    // Exam and Results page
    showNotification('Exams & Results feature coming soon', 'info');
}

async function loadLibrary() {
    // Library page
    showNotification('Library feature coming soon', 'info');
}

async function loadAwards() {
    // Awards page
    showNotification('Awards feature coming soon', 'info');
}

async function loadProjects() {
    showNotification('Projects feature coming soon', 'info');
}

async function loadTranscript() {
    showNotification('Transcript feature coming soon', 'info');
}

async function loadPromotions() {
    showNotification('Promotions feature coming soon', 'info');
}

// ==================== UTILITY FUNCTIONS ====================
function showNotification(message, type = 'info') {
    // Remove existing notifications
    document.querySelectorAll('.notification').forEach(n => n.remove());
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <span>${type === 'success' ? '✅' : type === 'error' ? '❌' : 'ℹ️'} ${message}</span>
        <button onclick="this.parentElement.remove()">×</button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', function() {
    // Check authentication on all pages
    const isAuthenticated = checkAuth();
    
    // Get current page
    const currentPage = window.location.pathname.split('/').pop();
    
    // Setup for dashboard page
    if (currentPage === 'dashboard.html') {
        if (isAuthenticated) {
            setupDashboardCards();
            loadDashboardData();
        }
    }
    
    // Setup for login page
    if (currentPage === '1.html' || currentPage === '') {
        setupLoginForm();
    }
});

function setupLoginForm() {
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email')?.value;
            const password = document.getElementById('password')?.value;
            
            if (!email || !password) {
                showNotification('Please enter both email and password', 'error');
                return;
            }
            
            await login(email, password);
        });
    }
    
    // Check if already logged in
    if (localStorage.getItem('token')) {
        window.location.href = 'dashboard.html';
    }
}