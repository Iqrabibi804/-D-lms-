
    // Sample Data
    let sessions = [
      { id: 1, name: "FALL-2025", status: "Active", semester: 3, students: 150, canPromote: true },
      { id: 2, name: "SPRING-2025", status: "Active", semester: 4, students: 120, canPromote: true },
      { id: 3, name: "FALL-2024", status: "Active", semester: 3, students: 180, canPromote: true },
      { id: 4, name: "SPRING-2024", status: "Inactive", semester: 2, students: 95, canPromote: false },
      { id: 5, name: "FALL-2023", status: "Inactive", semester: 1, students: 80, canPromote: false }
    ];

    let currentPage = 1;
    const entriesPerPage = 5;

    // DOM Elements
    const sessionsTableBody = document.getElementById('sessionsTableBody');
    const promotionSessionSelect = document.getElementById('promotionSession');
    const currentSemesterSelect = document.getElementById('currentSemester');
    const promoteToInput = document.getElementById('promoteTo');
    const studentsCountInput = document.getElementById('studentsCount');
    const promoteBtn = document.getElementById('promoteBtn');
    const newSessionBtn = document.getElementById('newSessionBtn');
    const confirmationModal = document.getElementById('confirmationModal');
    const newSessionModal = document.getElementById('newSessionModal');
    const confirmPromotionBtn = document.getElementById('confirmPromotion');
    const cancelPromotionBtn = document.getElementById('cancelPromotion');
    const createSessionBtn = document.getElementById('createSessionBtn');
    const cancelSessionBtn = document.getElementById('cancelSessionBtn');
    const backBtn = document.getElementById('backBtn');

    // Initialize
    function init() {
      renderTable();
      updateStats();
      populateSessionDropdown();
      setupEventListeners();
      updatePagination();
    }

    // Render sessions table
    function renderTable() {
      sessionsTableBody.innerHTML = '';
      
      const startIndex = (currentPage - 1) * entriesPerPage;
      const endIndex = startIndex + entriesPerPage;
      const currentSessions = sessions.slice(startIndex, endIndex);
      
      currentSessions.forEach((session, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${startIndex + index + 1}</td>
          <td>${session.name}</td>
          <td class="${session.status === 'Active' ? 'status-active' : 'status-inactive'}">
            ${session.status}
          </td>
          <td>${session.semester}</td>
          <td>${session.students}</td>
          <td>
            <div class="action-buttons">
              ${session.canPromote ? `
                <button class="promote-btn" onclick="promoteSession(${session.id})">
                  ↑ Promote
                </button>
              ` : ''}
              <button class="deactivate-btn" onclick="toggleSessionStatus(${session.id})">
                ${session.status === 'Active' ? '✗ Deactivate' : '✓ Activate'}
              </button>
            </div>
          </td>
        `;
        sessionsTableBody.appendChild(row);
      });
      
      // Update footer
      document.getElementById('startEntry').textContent = startIndex + 1;
      document.getElementById('endEntry').textContent = Math.min(endIndex, sessions.length);
      document.getElementById('totalEntries').textContent = sessions.length;
    }

    // Update statistics
    function updateStats() {
      const totalStudents = sessions.reduce((sum, session) => sum + session.students, 0);
      const activeSessions = sessions.filter(s => s.status === 'Active').length;
      const pendingPromotions = sessions.filter(s => s.canPromote && s.status === 'Active').length;
      
      document.getElementById('totalStudents').textContent = totalStudents;
      document.getElementById('activeSessions').textContent = activeSessions;
      document.getElementById('pendingPromotions').textContent = pendingPromotions;
    }

    // Populate session dropdown
    function populateSessionDropdown() {
      promotionSessionSelect.innerHTML = '<option value="">-- Choose Session --</option>';
      const activeSessions = sessions.filter(s => s.status === 'Active' && s.canPromote);
      
      activeSessions.forEach(session => {
        const option = document.createElement('option');
        option.value = session.id;
        option.textContent = `${session.name} (Semester ${session.semester})`;
        promotionSessionSelect.appendChild(option);
      });
      
      // Populate semester options
      currentSemesterSelect.innerHTML = '<option value="">-- Select Semester --</option>';
      for (let i = 1; i <= 8; i++) {
        const option = document.createElement('option');
        option.value = i;
        option.textContent = `Semester ${i}`;
        currentSemesterSelect.appendChild(option);
      }
    }

    // Setup event listeners
    function setupEventListeners() {
      // Promotion button
      promoteBtn.addEventListener('click', () => {
        const sessionId = parseInt(promotionSessionSelect.value);
        const currentSemester = parseInt(currentSemesterSelect.value);
        const studentsCount = parseInt(studentsCountInput.value);
        
        if (!sessionId || !currentSemester || !studentsCount) {
          alert('Please fill all fields correctly');
          return;
        }
        
        const session = sessions.find(s => s.id === sessionId);
        if (!session) {
          alert('Session not found');
          return;
        }
        
        if (currentSemester !== session.semester) {
          alert(`Current semester for ${session.name} is ${session.semester}, not ${currentSemester}`);
          return;
        }
        
        const nextSemester = currentSemester + 1;
        if (nextSemester > 8) {
          alert('Maximum semester reached (8). Cannot promote further.');
          return;
        }
        
        document.getElementById('modalMessage').textContent = 
          `Promote ${studentsCount} students from ${session.name} Semester ${currentSemester} to Semester ${nextSemester}?`;
        
        confirmationModal.style.display = 'flex';
        
        // Store promotion data
        confirmationModal.dataset.sessionId = sessionId;
        confirmationModal.dataset.currentSemester = currentSemester;
        confirmationModal.dataset.studentsCount = studentsCount;
      });
      
      // New session button
      newSessionBtn.addEventListener('click', () => {
        newSessionModal.style.display = 'flex';
      });
      
      // Back button
      backBtn.addEventListener('click', () => {
        if (confirm('Return to dashboard?')) {
          window.location.href = 'dashboard.html';
        }
      });
      
      // Semester change listener
      currentSemesterSelect.addEventListener('change', function() {
        const currentSemester = parseInt(this.value);
        if (currentSemester && currentSemester < 8) {
          promoteToInput.value = `Semester ${currentSemester + 1}`;
        } else {
          promoteToInput.value = 'Maximum Reached';
        }
      });
      
      // Session change listener
      promotionSessionSelect.addEventListener('change', function() {
        const sessionId = parseInt(this.value);
        const session = sessions.find(s => s.id === sessionId);
        if (session) {
          currentSemesterSelect.value = session.semester;
          promoteToInput.value = session.semester < 8 ? `Semester ${session.semester + 1}` : 'Maximum Reached';
          studentsCountInput.value = session.students;
        }
      });
    }

    // Session promotion function
    window.promoteSession = function(sessionId) {
      const session = sessions.find(s => s.id === sessionId);
      if (!session) return;
      
      if (!session.canPromote) {
        alert('This session cannot be promoted');
        return;
      }
      
      if (session.semester >= 8) {
        alert('Maximum semester reached. Cannot promote further.');
        return;
      }
      
      // Auto-fill the promotion form
      promotionSessionSelect.value = sessionId;
      currentSemesterSelect.value = session.semester;
      promoteToInput.value = `Semester ${session.semester + 1}`;
      studentsCountInput.value = session.students;
      
      // Scroll to promotion panel
      document.querySelector('.side-panel').scrollIntoView({ behavior: 'smooth' });
    };

    // Toggle session status
    window.toggleSessionStatus = function(sessionId) {
      const session = sessions.find(s => s.id === sessionId);
      if (!session) return;
      
      const newStatus = session.status === 'Active' ? 'Inactive' : 'Active';
      const confirmMessage = session.status === 'Active' 
        ? `Deactivate ${session.name}? This will prevent further promotions.`
        : `Activate ${session.name}?`;
      
      if (confirm(confirmMessage)) {
        session.status = newStatus;
        session.canPromote = newStatus === 'Active';
        renderTable();
        updateStats();
        populateSessionDropdown();
        alert(`Session ${session.name} is now ${newStatus}`);
      }
    };

    // Update pagination
    function updatePagination() {
      const paginationDiv = document.getElementById('pagination');
      paginationDiv.innerHTML = '';
      
      const totalPages = Math.ceil(sessions.length / entriesPerPage);
      
      // Previous button
      if (currentPage > 1) {
        const prevBtn = document.createElement('button');
        prevBtn.className = 'page-btn';
        prevBtn.innerHTML = '&laquo;';
        prevBtn.addEventListener('click', () => {
          currentPage--;
          renderTable();
          updatePagination();
        });
        paginationDiv.appendChild(prevBtn);
      }
      
      // Page buttons
      for (let i = 1; i <= totalPages; i++) {
        const pageBtn = document.createElement('button');
        pageBtn.className = `page-btn ${i === currentPage ? 'active' : ''}`;
        pageBtn.textContent = i;
        pageBtn.addEventListener('click', () => {
          currentPage = i;
          renderTable();
          updatePagination();
        });
        paginationDiv.appendChild(pageBtn);
      }
      
      // Next button
      if (currentPage < totalPages) {
        const nextBtn = document.createElement('button');
        nextBtn.className = 'page-btn';
        nextBtn.innerHTML = '&raquo;';
        nextBtn.addEventListener('click', () => {
          currentPage++;
          renderTable();
          updatePagination();
        });
        paginationDiv.appendChild(nextBtn);
      }
    }

    // Modal event listeners
    confirmPromotionBtn.addEventListener('click', function() {
      const sessionId = parseInt(confirmationModal.dataset.sessionId);
      const currentSemester = parseInt(confirmationModal.dataset.currentSemester);
      const studentsCount = parseInt(confirmationModal.dataset.studentsCount);
      
      const session = sessions.find(s => s.id === sessionId);
      if (session) {
        // Update session semester
        session.semester = currentSemester + 1;
        session.students = studentsCount;
        
        // Check if reached max semester
        if (session.semester >= 8) {
          session.canPromote = false;
          alert(`Maximum semester reached for ${session.name}. Further promotions disabled.`);
        }
        
        // Update UI
        renderTable();
        updateStats();
        populateSessionDropdown();
        
        // Show success message
        alert(`Successfully promoted ${studentsCount} students to Semester ${session.semester} in ${session.name}`);
      }
      
      confirmationModal.style.display = 'none';
    });
    
    cancelPromotionBtn.addEventListener('click', function() {
      confirmationModal.style.display = 'none';
    });
    
    createSessionBtn.addEventListener('click', function() {
      const sessionName = document.getElementById('sessionName').value.trim();
      const initialSemester = parseInt(document.getElementById('initialSemester').value);
      
      if (!sessionName) {
        alert('Please enter a session name');
        return;
      }
      
      // Check if session already exists
      if (sessions.some(s => s.name === sessionName)) {
        alert('Session with this name already exists');
        return;
      }
      
      // Create new session
      const newSession = {
        id: sessions.length + 1,
        name: sessionName,
        status: "Active",
        semester: initialSemester,
        students: 100, // Default value
        canPromote: true
      };
      
      sessions.unshift(newSession);
      
      // Update UI
      renderTable();
      updateStats();
      populateSessionDropdown();
      updatePagination();
      
      // Reset form and close modal
      document.getElementById('sessionName').value = '';
      newSessionModal.style.display = 'none';
      
      alert(`New session "${sessionName}" created successfully!`);
    });
    
    cancelSessionBtn.addEventListener('click', function() {
      newSessionModal.style.display = 'none';
      document.getElementById('sessionName').value = '';
    });
    
    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
      if (event.target === confirmationModal) {
        confirmationModal.style.display = 'none';
      }
      if (event.target === newSessionModal) {
        newSessionModal.style.display = 'none';
      }
    });

    // Initialize the application
    init();
