// script.js

// Configuration
const currentUserId = 'B23F0487SE076';
let selectedFile = null;
let documentToDeleteId = null;
let currentViewingDocument = null;

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('Initializing application...');
    
    // Initialize sample data if needed
    if (!localStorage.getItem('lms_documents')) {
        initializeSampleData();
    }
    
    // Set up event listeners
    setupEventListeners();
    
    // Load initial data
    loadUserDocuments();
    loadUserCredentials();
    
    // Show documents tab by default
    switchTab('documents');
    
    console.log('Application initialized successfully');
});

// Set up all event listeners
function setupEventListeners() {
    // Back button
    document.getElementById('backButton').addEventListener('click', goToDashboard);
    
    // Tab switching
    document.getElementById('documentsTabBtn').addEventListener('click', () => switchTab('documents'));
    document.getElementById('uploadTabBtn').addEventListener('click', () => switchTab('upload'));
    document.getElementById('credentialsTabBtn').addEventListener('click', () => switchTab('credentials'));
    
    // Upload first button
    document.getElementById('uploadFirstBtn').addEventListener('click', () => switchTab('upload'));
    
    // File upload
    document.getElementById('uploadButton').addEventListener('click', uploadDocument);
    document.getElementById('resetButton').addEventListener('click', resetUploadForm);
    
    // File selection
    document.getElementById('file').addEventListener('change', handleFileSelect);
    document.getElementById('fileUploadArea').addEventListener('click', () => {
        document.getElementById('file').click();
    });
    
    // Modal buttons
    document.getElementById('confirmDeleteBtn').addEventListener('click', confirmDelete);
    document.getElementById('cancelDeleteBtn').addEventListener('click', () => closeModal('deleteModal'));
    document.getElementById('downloadFromViewerBtn').addEventListener('click', downloadCurrentDocument);
    document.getElementById('closeViewerBtn').addEventListener('click', () => closeModal('fileViewerModal'));
    
    // Drag and drop
    const fileUploadArea = document.getElementById('fileUploadArea');
    fileUploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        this.style.borderColor = '#3498db';
        this.style.background = '#e8f4fc';
    });
    
    fileUploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        const fileInput = document.getElementById('file');
        if (e.dataTransfer.files.length > 0) {
            fileInput.files = e.dataTransfer.files;
            handleFileSelect();
        }
        this.style.borderColor = '';
        this.style.background = '';
    });
}

// Back to dashboard
function goToDashboard() {
    window.location.href = 'dashboard.html';
}

// Tab switching function
function switchTab(tabName) {
    console.log('Switching to tab:', tabName);
    
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.style.display = 'none';
        tab.classList.remove('active');
    });
    
    // Remove active class from all tab buttons
    document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected tab
    const selectedTab = document.getElementById(tabName + 'Tab');
    if (selectedTab) {
        selectedTab.style.display = 'block';
        selectedTab.classList.add('active');
    }
    
    // Add active class to clicked button
    const clickedBtn = document.getElementById(tabName + 'TabBtn');
    if (clickedBtn) {
        clickedBtn.classList.add('active');
    }
    
    // Reload data if needed
    if (tabName === 'documents') {
        loadUserDocuments();
    } else if (tabName === 'credentials') {
        loadUserCredentials();
    }
}

// Load user documents
function loadUserDocuments() {
    const documentsList = document.getElementById('documentsList');
    const emptyDocuments = document.getElementById('emptyDocuments');
    
    if (!documentsList) return;
    
    // Get documents from local storage
    const documents = JSON.parse(localStorage.getItem('lms_documents')) || [];
    const userDocs = documents.filter(doc => doc.uploadedBy === currentUserId);
    
    documentsList.innerHTML = '';
    
    if (userDocs.length === 0) {
        if (emptyDocuments) {
            emptyDocuments.style.display = 'block';
        }
        documentsList.innerHTML = `
            <div class="loading">
                <div class="loading-spinner"></div>
                <p>No documents found. Upload your first document!</p>
                <button class="upload-btn" id="uploadFirstBtn2" style="width: 200px; margin: 20px auto;">
                    <i class="fas fa-upload"></i> Upload Document
                </button>
            </div>
        `;
        // Add event listener to the new button
        setTimeout(() => {
            const uploadFirstBtn2 = document.getElementById('uploadFirstBtn2');
            if (uploadFirstBtn2) {
                uploadFirstBtn2.addEventListener('click', () => switchTab('upload'));
            }
        }, 100);
        return;
    }
    
    if (emptyDocuments) {
        emptyDocuments.style.display = 'none';
    }
    
    userDocs.forEach(doc => {
        const documentCard = createDocumentCard(doc);
        documentsList.appendChild(documentCard);
    });
}

// Create document card
function createDocumentCard(doc) {
    const categoryLabels = {
        'assignment': 'Assignment',
        'project': 'Project',
        'notes': 'Study Notes',
        'lab': 'Lab Report',
        'certificate': 'Certificate',
        'other': 'Other'
    };
    
    const fileIcons = {
        'pdf': 'file-pdf',
        'docx': 'file-word',
        'doc': 'file-word',
        'zip': 'file-archive',
        'rar': 'file-archive',
        'jpg': 'file-image',
        'jpeg': 'file-image',
        'png': 'file-image',
        'txt': 'file-alt',
        'pptx': 'file-powerpoint',
        'ppt': 'file-powerpoint',
        'xlsx': 'file-excel',
        'xls': 'file-excel'
    };
    
    const fileIcon = fileIcons[doc.fileType] || 'file';
    const fileSizeMB = (doc.fileSize / (1024*1024)).toFixed(1) + ' MB';
    const uploadDate = new Date(doc.uploadedAt).toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    
    const card = document.createElement('div');
    card.className = 'document-card';
    card.innerHTML = `
        <div class="card-header">
            <div style="flex: 1; margin-right: 15px;">
                <h3 class="doc-title">${escapeHtml(doc.title)}</h3>
                <p class="doc-description">${escapeHtml(doc.description || 'No description provided')}</p>
            </div>
            <span class="doc-category">${escapeHtml(categoryLabels[doc.category])}</span>
        </div>
        
        <div class="doc-meta">
            <div class="doc-date">
                <i class="far fa-calendar"></i> ${escapeHtml(uploadDate)}
            </div>
            <div class="doc-size">
                <i class="fas fa-weight-hanging"></i> ${escapeHtml(fileSizeMB)}
            </div>
        </div>
        
        <div class="file-preview">
            <div class="file-icon">
                <i class="fas fa-${fileIcon}"></i>
            </div>
            <div class="file-info">
                <h4>${escapeHtml(doc.originalName)}</h4>
                <p>
                    <span><i class="fas fa-file"></i> ${escapeHtml(doc.fileType.toUpperCase())}</span>
                    <span><i class="fas fa-weight-hanging"></i> ${escapeHtml(fileSizeMB)}</span>
                </p>
            </div>
        </div>
        
        <div class="action-buttons">
            <button class="action-btn view-btn" data-doc-id="${doc.id}">
                <i class="fas fa-eye"></i> View
            </button>
            <button class="action-btn edit-btn" data-doc-id="${doc.id}">
                <i class="fas fa-edit"></i> Edit
            </button>
            <button class="action-btn download-btn" data-doc-id="${doc.id}">
                <i class="fas fa-download"></i> Download
            </button>
            <button class="action-btn delete-btn" data-doc-id="${doc.id}" data-doc-title="${escapeHtml(doc.title)}">
                <i class="fas fa-trash"></i> Delete
            </button>
        </div>
    `;
    
    // Add event listeners to buttons
    const viewBtn = card.querySelector('.view-btn');
    const editBtn = card.querySelector('.edit-btn');
    const downloadBtn = card.querySelector('.download-btn');
    const deleteBtn = card.querySelector('.delete-btn');
    
    viewBtn.addEventListener('click', () => viewDocument(doc.id));
    editBtn.addEventListener('click', () => editDocument(doc.id));
    downloadBtn.addEventListener('click', () => downloadDocument(doc.id));
    deleteBtn.addEventListener('click', () => showDeleteModal(doc.id, doc.title));
    
    return card;
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Handle file selection
function handleFileSelect() {
    const fileInput = document.getElementById('file');
    const fileNameDisplay = document.getElementById('fileNameDisplay');
    
    if (fileInput.files.length > 0) {
        selectedFile = fileInput.files[0];
        
        // Validate file size
        if (selectedFile.size > 50 * 1024 * 1024) {
            alert('File size exceeds 50MB limit');
            fileInput.value = '';
            fileNameDisplay.textContent = 'No file selected';
            selectedFile = null;
            return;
        }
        
        // Validate file type
        const allowedTypes = ['pdf', 'doc', 'docx', 'zip', 'rar', 'jpg', 'jpeg', 'png', 'txt', 'pptx', 'ppt', 'xlsx', 'xls'];
        const fileExtension = selectedFile.name.split('.').pop().toLowerCase();
        
        if (!allowedTypes.includes(fileExtension)) {
            alert('File type not supported. Please upload a document file.');
            fileInput.value = '';
            fileNameDisplay.textContent = 'No file selected';
            selectedFile = null;
            return;
        }
        
        fileNameDisplay.textContent = `${selectedFile.name} (${(selectedFile.size / (1024*1024)).toFixed(2)} MB)`;
    }
}

// Upload document
async function uploadDocument() {
    const title = document.getElementById('title').value.trim();
    const category = document.getElementById('category').value;
    const description = document.getElementById('description').value.trim();
    
    // Validate inputs
    if (!title) {
        alert('Please enter a document title');
        return;
    }
    
    if (!category) {
        alert('Please select a category');
        return;
    }
    
    if (!selectedFile) {
        alert('Please select a file to upload');
        return;
    }
    
    try {
        // Create new document object
        const newDocument = {
            id: 'doc_' + Date.now().toString(),
            title: title,
            description: description,
            category: category,
            originalName: selectedFile.name,
            fileName: selectedFile.name,
            fileType: selectedFile.name.split('.').pop().toLowerCase(),
            fileSize: selectedFile.size,
            uploadedBy: currentUserId,
            uploadedAt: new Date().toISOString(),
            filePath: 'uploads/' + selectedFile.name
        };
        
        // Get existing documents
        const existingDocs = JSON.parse(localStorage.getItem('lms_documents')) || [];
        
        // Add new document
        existingDocs.push(newDocument);
        
        // Save back to local storage
        localStorage.setItem('lms_documents', JSON.stringify(existingDocs));
        
        // Show success message
        document.getElementById('uploadSuccess').style.display = 'block';
        document.getElementById('uploadError').style.display = 'none';
        
        // Reset form
        resetUploadForm();
        
        // Switch to documents tab after 1 second
        setTimeout(() => {
            switchTab('documents');
            loadUserDocuments();
            document.getElementById('uploadSuccess').style.display = 'none';
        }, 2000);
        
    } catch (error) {
        console.error('Upload error:', error);
        document.getElementById('uploadError').style.display = 'block';
        document.getElementById('uploadSuccess').style.display = 'none';
        
        setTimeout(() => {
            document.getElementById('uploadError').style.display = 'none';
        }, 3000);
    }
}

// Reset upload form
function resetUploadForm() {
    document.getElementById('title').value = '';
    document.getElementById('category').value = '';
    document.getElementById('description').value = '';
    document.getElementById('file').value = '';
    document.getElementById('fileNameDisplay').textContent = 'No file selected';
    selectedFile = null;
    
    // Hide messages
    document.getElementById('uploadSuccess').style.display = 'none';
    document.getElementById('uploadError').style.display = 'none';
}

// View document
async function viewDocument(docId) {
    const documents = JSON.parse(localStorage.getItem('lms_documents')) || [];
    const doc = documents.find(d => d.id === docId);
    
    if (!doc) {
        alert('Document not found!');
        return;
    }
    
    currentViewingDocument = doc;
    
    // Open file viewer modal
    const fileViewerFrame = document.getElementById('fileViewerFrame');
    
    if (doc.fileType === 'pdf') {
        // For PDF files, use Google Docs viewer
        fileViewerFrame.src = `https://docs.google.com/viewer?url=${encodeURIComponent(doc.filePath)}&embedded=true`;
    } else {
        // For other files, show a message with download option
        fileViewerFrame.srcdoc = `
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        padding: 40px;
                        text-align: center;
                        background: #f8f9fa;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        margin: 0;
                    }
                    .container {
                        max-width: 500px;
                        margin: 0 auto;
                        padding: 30px;
                        background: white;
                        border-radius: 10px;
                        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                    }
                    .file-icon {
                        font-size: 48px;
                        color: #3498db;
                        margin-bottom: 20px;
                    }
                    h2 {
                        color: #2c3e50;
                        margin-bottom: 10px;
                    }
                    .download-btn {
                        background: #3498db;
                        color: white;
                        border: none;
                        padding: 12px 30px;
                        border-radius: 5px;
                        font-size: 16px;
                        cursor: pointer;
                        margin-top: 20px;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="file-icon">📄</div>
                    <h2>${escapeHtml(doc.title)}</h2>
                    <p>File Type: ${doc.fileType.toUpperCase()}</p>
                    <p>Size: ${(doc.fileSize/(1024*1024)).toFixed(2)} MB</p>
                    <p>This file type cannot be previewed directly. Please download it to view.</p>
                    <button class="download-btn" id="iframeDownloadBtn">
                        Download File
                    </button>
                </div>
                <script>
                    document.getElementById('iframeDownloadBtn').addEventListener('click', function() {
                        window.parent.postMessage('download', '*');
                    });
                <\/script>
            </body>
            </html>
        `;
    }
    
    openModal('fileViewerModal');
}

// Edit document
function editDocument(docId) {
    const documents = JSON.parse(localStorage.getItem('lms_documents')) || [];
    const doc = documents.find(d => d.id === docId);
    
    if (!doc) {
        alert('Document not found!');
        return;
    }
    
    const newTitle = prompt('Enter new title:', doc.title);
    if (newTitle === null) return; // User cancelled
    
    const newDescription = prompt('Enter new description:', doc.description || '');
    
    const docIndex = documents.findIndex(d => d.id === docId);
    if (docIndex !== -1) {
        documents[docIndex].title = newTitle;
        documents[docIndex].description = newDescription;
        
        localStorage.setItem('lms_documents', JSON.stringify(documents));
        loadUserDocuments();
        alert('Document updated successfully!');
    }
}

// Download document
function downloadDocument(docId) {
    const documents = JSON.parse(localStorage.getItem('lms_documents')) || [];
    const doc = documents.find(d => d.id === docId);
    
    if (!doc) {
        alert('Document not found!');
        return;
    }
    
    try {
        // Create a download link
        const link = document.createElement('a');
        
        // Create dummy file content for demo
        let fileContent = `Document: ${doc.title}\n\n`;
        fileContent += `Description: ${doc.description || 'No description'}\n`;
        fileContent += `Category: ${doc.category}\n`;
        fileContent += `File Type: ${doc.fileType}\n`;
        fileContent += `File Size: ${doc.fileSize} bytes\n`;
        fileContent += `Uploaded: ${doc.uploadedAt}\n\n`;
        fileContent += `This is a demo file for testing purposes.\n`;
        fileContent += `In a real application, this would be the actual file content.\n`;
        
        const blob = new Blob([fileContent], { type: 'text/plain' });
        link.href = URL.createObjectURL(blob);
        link.download = doc.originalName;
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        // Release the object URL
        setTimeout(() => URL.revokeObjectURL(link.href), 100);
        
        // Show success feedback
        const button = event?.target;
        if (button && button.classList.contains('download-btn')) {
            const originalHTML = button.innerHTML;
            button.innerHTML = '<i class="fas fa-check"></i> Downloaded!';
            button.style.background = 'linear-gradient(135deg, #27ae60, #219653)';
            
            setTimeout(() => {
                button.innerHTML = originalHTML;
                button.style.background = '';
            }, 2000);
        }
        
        alert(`Download started: ${doc.title}`);
        
    } catch (error) {
        console.error('Download error:', error);
        alert('Error downloading document. Please try again.');
    }
}

// Download current viewing document
function downloadCurrentDocument() {
    if (currentViewingDocument) {
        downloadDocument(currentViewingDocument.id);
        closeModal('fileViewerModal');
    }
}

// Show delete confirmation modal
function showDeleteModal(docId, docTitle) {
    documentToDeleteId = docId;
    document.getElementById('documentToDelete').textContent = docTitle;
    openModal('deleteModal');
}

// Confirm delete
function confirmDelete() {
    if (!documentToDeleteId) return;
    
    const documents = JSON.parse(localStorage.getItem('lms_documents')) || [];
    const updatedDocuments = documents.filter(d => d.id !== documentToDeleteId);
    
    localStorage.setItem('lms_documents', JSON.stringify(updatedDocuments));
    loadUserDocuments();
    closeModal('deleteModal');
    
    // Show success message
    alert('Document deleted successfully!');
    documentToDeleteId = null;
}

// Modal functions
function openModal(modalId) {
    document.getElementById(modalId).classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

// Load user credentials
function loadUserCredentials() {
    const credentialsList = document.getElementById('credentialsList');
    
    if (!credentialsList) return;
    
    // Credentials data
    const credentialsData = [
        {
            title: "University Account",
            icon: "university",
            items: [
                { label: "University Email", value: "B23F0487SE076@paf-iast.edu.pk" },
                { label: "Password", value: "PAF@2023Student" }
            ]
        },
        {
            title: "Learning Management System",
            icon: "book",
            items: [
                { label: "LMS Username", value: "B23F0487SE076" },
                { label: "LMS Password", value: "Learn@PAF2023" },
                { label: "LMS Portal", value: "https://lms.paf-iast.edu.pk" }
            ]
        },
        {
            title: "Personal Email",
            icon: "envelope",
            items: [
                { label: "Email Address", value: "sbdlahans1700@gmail.com" },
                { label: "Password", value: "23048752076" }
            ]
        },
        {
            title: "Library System",
            icon: "book-reader",
            items: [
                { label: "Library ID", value: "LIB-PAF-0487" },
                { label: "Password", value: "Research@2023" },
                { label: "Library Portal", value: "https://library.paf-iast.edu.pk" }
            ]
        }
    ];
    
    // Clear loading message
    credentialsList.innerHTML = '';
    
    // Load credentials
    credentialsData.forEach(cred => {
        const credentialCard = document.createElement('div');
        credentialCard.className = 'credential-card';
        
        const credentialItems = cred.items.map(item => {
            const isPortal = item.label.includes('Portal');
            return `
                <div class="credential-item">
                    <div class="credential-label">
                        <i class="fas fa-${getCredentialIcon(item.label)}"></i> 
                        ${escapeHtml(item.label)}
                    </div>
                    <div class="credential-value">
                        ${isPortal ? `<a href="${escapeHtml(item.value)}" target="_blank">${escapeHtml(item.value)}</a>` : escapeHtml(item.value)}
                        <button class="copy-btn" data-value="${escapeHtml(item.value)}">
                            <i class="fas fa-copy"></i> Copy
                        </button>
                    </div>
                </div>
            `;
        }).join('');
        
        credentialCard.innerHTML = `
            <div class="credential-header">
                <div class="credential-icon">
                    <i class="fas fa-${cred.icon}"></i>
                </div>
                <div class="credential-title">${escapeHtml(cred.title)}</div>
            </div>
            ${credentialItems}
        `;
        
        // Add event listeners to copy buttons
        credentialCard.querySelectorAll('.copy-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const text = this.getAttribute('data-value');
                copyCredentialToClipboard(text);
            });
        });
        
        credentialsList.appendChild(credentialCard);
    });
}

// Get appropriate icon for credential label
function getCredentialIcon(label) {
    label = label.toLowerCase();
    if (label.includes('email')) return 'envelope';
    if (label.includes('password')) return 'lock';
    if (label.includes('username')) return 'user';
    if (label.includes('portal')) return 'link';
    if (label.includes('id')) return 'id-card';
    return 'key';
}

// Copy credential to clipboard
function copyCredentialToClipboard(text) {
    // Remove HTML tags if present (for links)
    const cleanText = text.replace(/<[^>]*>/g, '');
    navigator.clipboard.writeText(cleanText)
        .then(() => {
            // Visual feedback
            const button = event?.target;
            if (button) {
                const originalHTML = button.innerHTML;
                button.innerHTML = '<i class="fas fa-check"></i> Copied!';
                button.style.background = '#27ae60';
                button.style.color = 'white';
                
                setTimeout(() => {
                    button.innerHTML = originalHTML;
                    button.style.background = '';
                    button.style.color = '';
                }, 2000);
            }
        })
        .catch(err => {
            console.error('Failed to copy:', err);
            alert('Failed to copy to clipboard');
        });
}

// Initialize sample data
function initializeSampleData() {
    const sampleDocuments = [
        {
            id: 'doc_1',
            title: 'bnmb,n,m',
            description: 'xhjm gjmb',
            category: 'notes',
            originalName: 'Exam Admit Card (1).pdf',
            fileName: 'Exam_Admit_Card_1.pdf',
            fileType: 'pdf',
            fileSize: 1048576, // 1 MB
            uploadedBy: currentUserId,
            uploadedAt: '2025-12-10T10:00:00Z',
            filePath: 'uploads/Exam_Admit_Card_1.pdf'
        },
        {
            id: 'doc_2',
            title: 'Software Engineering Assignment 1',
            description: 'First assignment covering software requirements specification',
            category: 'assignment',
            originalName: 'SE_Assignment_1.pdf',
            fileName: 'SE_Assignment_1.pdf',
            fileType: 'pdf',
            fileSize: 2516582,
            uploadedBy: currentUserId,
            uploadedAt: '2023-10-15T14:30:00Z',
            filePath: 'uploads/SE_Assignment_1.pdf'
        },
        {
            id: 'doc_3',
            title: 'Database Systems Project',
            description: 'Complete database design for library management system',
            category: 'project',
            originalName: 'DB_Project_Final.zip',
            fileName: 'DB_Project_Final.zip',
            fileType: 'zip',
            fileSize: 16462643,
            uploadedBy: currentUserId,
            uploadedAt: '2023-11-05T10:15:00Z',
            filePath: 'uploads/DB_Project_Final.zip'
        },
        {
            id: 'doc_4',
            title: 'Data Structures Notes',
            description: 'Comprehensive notes on trees and graphs algorithms',
            category: 'notes',
            originalName: 'Data_Structures_Notes.docx',
            fileName: 'Data_Structures_Notes.docx',
            fileType: 'docx',
            fileSize: 3250586,
            uploadedBy: currentUserId,
            uploadedAt: '2023-09-20T16:45:00Z',
            filePath: 'uploads/Data_Structures_Notes.docx'
        }
    ];
    
    localStorage.setItem('lms_documents', JSON.stringify(sampleDocuments));
    console.log('Sample data initialized');
}

// Listen for download messages from iframe
window.addEventListener('message', function(e) {
    if (e.data === 'download' && currentViewingDocument) {
        downloadDocument(currentViewingDocument.id);
    }
});