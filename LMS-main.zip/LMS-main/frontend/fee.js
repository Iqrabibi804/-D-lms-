 const feeRecords = [
        {
            id: 1,
            semester: "FALL-2024",
            voucherNo: "B23F1818/13",
            dueDate: "2024-10-08",
            uploadDate: "2024-10-05",
            amount: 126390,
            fine: 0,
            status: "verified",
            remarks: "Verified by Admin on 2024-10-06",
            fileUrl: "#",
            verifiedDate: "2024-10-06",
            paymentMethod: "bank"
        },
        {
            id: 2,
            semester: "SPRING-2025",
            voucherNo: "B23F1818/14",
            dueDate: "2025-01-24",
            uploadDate: null,
            amount: 126390,
            fine: 5000, // Late fine
            status: "pending",
            remarks: "Due in 2 days - Late fine applicable",
            fileUrl: null,
            paymentMethod: null
        }
    ];

    // Notifications data
    const notifications = [
        {
            id: 1,
            type: "new_voucher",
            message: "New fee voucher for SPRING-2025 has been uploaded by admin",
            date: "2025-01-15",
            read: false
        },
        {
            id: 2,
            type: "fine_added",
            message: "Late fine of Rs. 5,000 added to your SPRING-2025 fee",
            date: "2025-01-20",
            read: false
        },
        {
            id: 3,
            type: "verification",
            message: "Your FALL-2024 voucher has been verified by admin",
            date: "2024-10-06",
            read: true
        }
    ];

    // Statistics data
    let stats = {
        totalSemesters: 2,
        totalFee: 252780,
        paidAmount: 126390,
        pendingAmount: 126390,
        paidSemesters: 1,
        pendingSemesters: 1,
        totalFines: 5000
    };

    // Selected voucher for payment
    let selectedVoucher = null;
    let selectedPaymentMethod = 'online';

    // Initialize page when DOM is loaded
    document.addEventListener('DOMContentLoaded', function() {
        updateStatistics();
        renderFeeTable();
        setupUploadModal();
        loadNotifications();
        checkNotifications();
        setupEventListeners();
    });

    // Setup event listeners
    function setupEventListeners() {
        // Upload Voucher button
        document.getElementById('uploadVoucherBtn').addEventListener('click', openUploadModal);
        
        // Submit Voucher button in modal
        document.getElementById('submitVoucherBtn').addEventListener('click', submitVoucher);
        
        // Process Payment button
        document.getElementById('processPaymentBtn').addEventListener('click', processPayment);
        
        // Close notification button
        document.getElementById('closeNotificationBtn').addEventListener('click', hideNotification);
        
        // Payment option selection
        document.querySelectorAll('.payment-option').forEach(option => {
            option.addEventListener('click', function() {
                selectPaymentMethod(this.dataset.method);
            });
        });
    }

    // Update statistics
    function updateStatistics() {
        document.getElementById('totalSemesters').textContent = stats.totalSemesters;
        document.getElementById('totalFee').textContent = `Rs. ${stats.totalFee.toLocaleString()}`;
        document.getElementById('paidAmount').textContent = `Rs. ${stats.paidAmount.toLocaleString()}`;
        document.getElementById('pendingAmount').textContent = `Rs. ${stats.pendingAmount.toLocaleString()}`;
        document.getElementById('paidSemesters').textContent = stats.paidSemesters;
        document.getElementById('pendingSemesters').textContent = stats.pendingSemesters;
        document.getElementById('totalFines').textContent = `Rs. ${stats.totalFines.toLocaleString()}`;
    }

    // Render fee table with action buttons
    function renderFeeTable() {
        const tbody = document.getElementById('feeTableBody');
        tbody.innerHTML = '';

        feeRecords.forEach((record, index) => {
            const row = document.createElement('tr');
            
            let statusClass = 'badge-pending';
            let statusText = 'Pending';
            
            if (record.status === 'verified') {
                statusClass = 'badge-verified';
                statusText = 'Verified';
            } else if (record.status === 'paid') {
                statusClass = 'badge-paid';
                statusText = 'Paid';
            } else if (record.status === 'rejected') {
                statusClass = 'badge-rejected';
                statusText = 'Rejected';
            }

            const dueDate = new Date(record.dueDate);
            const today = new Date();
            const daysRemaining = Math.ceil((dueDate - today) / (1000 * 60 * 60 * 24));
            
            let dueDateText = formatDate(record.dueDate);
            if (daysRemaining < 0) {
                dueDateText += ` <span class="fine-badge">Overdue ${Math.abs(daysRemaining)} days</span>`;
            } else if (daysRemaining <= 2) {
                dueDateText += ` <span class="fine-badge" style="background-color: rgba(255, 152, 0, 0.1); color: #ff9800;">Due in ${daysRemaining} days</span>`;
            }

            const totalAmount = record.amount + (record.fine || 0);
            
            row.innerHTML = `
                <td>${index + 1}</td>
                <td>
                    <strong>${record.semester}</strong>
                    ${record.fine > 0 ? `<br><small class="fine-badge">Fine: Rs. ${record.fine.toLocaleString()}</small>` : ''}
                    ${record.status === 'verified' ? 
                        `<br><small class="text-success">Verified on ${formatDate(record.verifiedDate)}</small>` : ''}
                </td>
                <td>
                    <code class="text-primary">${record.voucherNo}</code>
                </td>
                <td>${dueDateText}</td>
                <td>
                    <strong>Rs. ${totalAmount.toLocaleString()}</strong>
                    ${record.fine > 0 ? `<br><small class="text-danger">Including fine</small>` : ''}
                </td>
                <td>
                    <span class="status-badge ${statusClass}">${statusText}</span>
                </td>
                <td>
                    <small>${record.remarks}</small>
                </td>
                <td>
                    <div class="action-buttons">
                        ${record.fileUrl ? `
                            <button class="btn-details" onclick="viewVoucher(${record.id})">
                                <i class="fas fa-eye"></i>
                                View
                            </button>
                            <button class="btn-download" onclick="downloadVoucher(${record.id})">
                                <i class="fas fa-download"></i>
                                Download
                            </button>
                        ` : `
                            <button class="btn-details" onclick="viewVoucherDetails(${record.id})">
                                <i class="fas fa-info-circle"></i>
                                Details
                            </button>
                        `}
                        ${record.status === 'pending' ? `
                            <button class="btn-pay" onclick="payNow(${record.id})">
                                <i class="fas fa-credit-card"></i>
                                Pay Now
                            </button>
                        ` : ''}
                    </div>
                </td>
            `;

            tbody.appendChild(row);
        });
    }

    // View voucher details (for verified vouchers)
    function viewVoucher(id) {
        const record = feeRecords.find(r => r.id === id);
        if (!record) return;
        
        const totalAmount = record.amount + record.fine;
        alert(`📄 Voucher Details\n\n` +
              `Semester: ${record.semester}\n` +
              `Voucher No: ${record.voucherNo}\n` +
              `Amount: Rs. ${record.amount.toLocaleString()}\n` +
              `Fine: Rs. ${record.fine.toLocaleString()}\n` +
              `Total: Rs. ${totalAmount.toLocaleString()}\n` +
              `Status: ${record.status.charAt(0).toUpperCase() + record.status.slice(1)}\n` +
              `Payment Method: ${record.paymentMethod || 'N/A'}\n` +
              `Verified Date: ${record.verifiedDate ? formatDate(record.verifiedDate) : 'N/A'}\n` +
              `Remarks: ${record.remarks}`);
    }

    // View voucher details (for pending vouchers)
    function viewVoucherDetails(id) {
        const record = feeRecords.find(r => r.id === id);
        if (!record) return;
        
        const dueDate = new Date(record.dueDate);
        const today = new Date();
        const daysRemaining = Math.ceil((dueDate - today) / (1000 * 60 * 60 * 24));
        const totalAmount = record.amount + record.fine;
        
        let message = `📄 Voucher Details\n\n` +
                     `Semester: ${record.semester}\n` +
                     `Voucher No: ${record.voucherNo}\n` +
                     `Amount: Rs. ${record.amount.toLocaleString()}\n` +
                     `Fine: Rs. ${record.fine.toLocaleString()}\n` +
                     `Total Payable: Rs. ${totalAmount.toLocaleString()}\n` +
                     `Due Date: ${formatDate(record.dueDate)}\n`;
        
        if (daysRemaining < 0) {
            message += `Status: ⚠️ Overdue by ${Math.abs(daysRemaining)} days\n`;
        } else {
            message += `Status: ⏳ Due in ${daysRemaining} days\n`;
        }
        
        message += `Remarks: ${record.remarks}\n\n`;
        message += `Click "Pay Now" to make payment online.`;
        
        alert(message);
    }

    // Download voucher
    function downloadVoucher(id) {
        const record = feeRecords.find(r => r.id === id);
        if (!record) return;
        
        // Simulate download
        const totalAmount = record.amount + record.fine;
        
        alert(`⬇️ Downloading Voucher\n\n` +
              `Voucher: ${record.voucherNo}\n` +
              `Semester: ${record.semester}\n` +
              `Amount: Rs. ${totalAmount.toLocaleString()}\n\n` +
              `Your voucher PDF is being downloaded...`);
        
        showNotification(`Voucher ${record.voucherNo} downloaded successfully!`, 'success');
    }

    // Pay now - Open payment modal
    function payNow(id) {
        const record = feeRecords.find(r => r.id === id);
        if (!record) return;
        
        selectedVoucher = record;
        
        // Update modal content
        document.getElementById('paymentSemester').textContent = record.semester;
        document.getElementById('paymentVoucherNo').textContent = record.voucherNo;
        document.getElementById('paymentDueDate').textContent = formatDate(record.dueDate);
        document.getElementById('paymentFine').textContent = `Rs. ${record.fine.toLocaleString()}`;
        
        const totalAmount = record.amount + record.fine;
        document.getElementById('paymentTotalAmount').textContent = `Rs. ${totalAmount.toLocaleString()}`;
        
        // Show modal
        const modalElement = document.getElementById('paymentModal');
        const modal = new bootstrap.Modal(modalElement);
        modal.show();
        
        // Reset to online payment
        selectPaymentMethod('online');
    }

    // Load notifications
    function loadNotifications() {
        const notificationsList = document.getElementById('notificationsList');
        const unreadCount = notifications.filter(n => !n.read).length;
        
        if (unreadCount > 0) {
            document.getElementById('notificationsCard').style.display = 'block';
            
            notifications.forEach(notification => {
                const notificationDiv = document.createElement('div');
                notificationDiv.className = `summary-item ${notification.read ? '' : 'fw-bold'}`;
                notificationDiv.innerHTML = `
                    <div>
                        <small>${notification.message}</small>
                        <br>
                        <small class="text-muted">${formatDate(notification.date)}</small>
                    </div>
                `;
                notificationsList.appendChild(notificationDiv);
            });
        }
    }

    // Check for new notifications
    function checkNotifications() {
        const unreadCount = notifications.filter(n => !n.read).length;
        if (unreadCount > 0) {
            showNotification(`You have ${unreadCount} new notification${unreadCount > 1 ? 's' : ''}`, 'info');
        }
    }

    // Setup upload modal
    function setupUploadModal() {
        const fileInput = document.getElementById('voucherImage');
        const previewSection = document.getElementById('previewSection');
        const uploadArea = document.getElementById('uploadArea');
        
        // File upload handler
        fileInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                // Check file type
                if (!file.type.match('image.*') && file.type !== 'application/pdf') {
                    alert('Please select an image or PDF file (JPG, PNG, PDF)');
                    fileInput.value = '';
                    return;
                }
                
                // Check file size (max 5MB)
                if (file.size > 5 * 1024 * 1024) {
                    alert('File size should be less than 5MB');
                    fileInput.value = '';
                    return;
                }
                
                // Show preview
                previewSection.style.display = 'block';
                uploadArea.style.display = 'none';
                
                // Update file info
                document.getElementById('fileName').textContent = file.name;
                document.getElementById('fileSize').textContent = formatFileSize(file.size);
                document.getElementById('fileType').textContent = file.type.split('/')[1].toUpperCase();
                
                // Show image preview if it's an image
                if (file.type.match('image.*')) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        document.getElementById('voucherPreview').src = e.target.result;
                    };
                    reader.readAsDataURL(file);
                } else {
                    // For PDF, show PDF icon
                    document.getElementById('voucherPreview').src = '';
                    document.getElementById('voucherPreview').style.display = 'none';
                }
            }
        });
    }

    // Open upload modal
    function openUploadModal() {
        const modalElement = document.getElementById('uploadVoucherModal');
        const modal = new bootstrap.Modal(modalElement);
        modal.show();
    }

    // Submit voucher for verification
    function submitVoucher() {
        const fileInput = document.getElementById('voucherImage');
        const semester = document.getElementById('semester').value;
        const voucherNo = document.getElementById('voucherNo').value.trim();
        const amount = document.getElementById('amount').value;
        const paymentDate = document.getElementById('paymentDate').value;
        const remarks = document.getElementById('remarks').value.trim();
        
        // Validation
        if (!fileInput.files[0]) {
            alert('Please select a voucher file');
            return;
        }
        
        if (!semester) {
            alert('Please select semester');
            return;
        }
        
        if (!voucherNo) {
            alert('Please enter voucher number');
            return;
        }
        
        if (!amount || amount <= 0) {
            alert('Please enter valid amount');
            return;
        }
        
        if (!paymentDate) {
            alert('Please select payment date');
            return;
        }
        
        // Get next ID
        const nextId = feeRecords.length > 0 ? Math.max(...feeRecords.map(r => r.id)) + 1 : 1;
        
        // Add new voucher record (for bank deposit)
        const newRecord = {
            id: nextId,
            semester: semester,
            voucherNo: voucherNo,
            dueDate: addDaysToDate(paymentDate, 7), // Due date 7 days after payment
            uploadDate: new Date().toISOString().split('T')[0],
            amount: parseInt(amount),
            fine: 0,
            status: 'pending',
            remarks: remarks || 'Awaiting admin verification',
            fileUrl: '#',
            paymentMethod: 'bank'
        };
        
        feeRecords.push(newRecord);
        
        // Update statistics
        stats.totalSemesters += 1;
        stats.totalFee += parseInt(amount);
        stats.pendingAmount += parseInt(amount);
        stats.pendingSemesters += 1;
        
        // Update UI
        updateStatistics();
        renderFeeTable();
        
        // Close modal
        const modalElement = document.getElementById('uploadVoucherModal');
        const modal = bootstrap.Modal.getInstance(modalElement);
        modal.hide();
        
        // Reset form
        resetUploadForm();
        
        // Show success notification
        showNotification('Voucher uploaded successfully! Admin will verify within 24-48 hours.', 'success');
    }

    // Reset upload form
    function resetUploadForm() {
        document.getElementById('voucherImage').value = '';
        document.getElementById('previewSection').style.display = 'none';
        document.getElementById('uploadArea').style.display = 'block';
        document.getElementById('semester').value = '';
        document.getElementById('voucherNo').value = '';
        document.getElementById('amount').value = '';
        document.getElementById('paymentDate').value = '';
        document.getElementById('remarks').value = '';
    }

    // Select payment method
    function selectPaymentMethod(method) {
        selectedPaymentMethod = method;
        
        // Remove active class from all
        document.querySelectorAll('.payment-option').forEach(option => {
            option.classList.remove('active');
        });
        
        // Add active class to selected
        document.querySelectorAll('.payment-option').forEach(option => {
            if (option.dataset.method === method) {
                option.classList.add('active');
            }
        });
        
        // Show/hide sections
        document.getElementById('onlinePaymentSection').style.display = method === 'online' ? 'block' : 'none';
        document.getElementById('bankPaymentSection').style.display = method === 'bank' ? 'block' : 'none';
        document.getElementById('mobilePaymentSection').style.display = (method === 'jazzcash' || method === 'easypaisa') ? 'block' : 'none';
        
        // Update mobile account number
        if (method === 'jazzcash') {
            document.getElementById('mobileAccountNumber').value = '0312-3456789';
        } else if (method === 'easypaisa') {
            document.getElementById('mobileAccountNumber').value = '0345-6789012';
        }
    }

    // Process payment
    function processPayment() {
        if (!selectedVoucher) return;
        
        const totalAmount = selectedVoucher.amount + selectedVoucher.fine;
        
        if (selectedPaymentMethod === 'online') {
            // Online payment
            alert(`🔄 Redirecting to secure payment gateway...\n\n` +
                  `Voucher: ${selectedVoucher.voucherNo}\n` +
                  `Amount: Rs. ${totalAmount.toLocaleString()}\n\n` +
                  `You will be taken to a secure payment page.`);
            
            // Simulate payment processing
            setTimeout(() => {
                // Update voucher status
                const record = feeRecords.find(r => r.id === selectedVoucher.id);
                if (record) {
                    record.status = 'paid';
                    record.paymentMethod = 'online';
                    record.verifiedDate = new Date().toISOString().split('T')[0];
                    record.remarks = `Paid via online payment on ${formatDate(record.verifiedDate)}`;
                    
                    // Update statistics
                    stats.paidAmount += totalAmount;
                    stats.pendingAmount -= totalAmount;
                    stats.paidSemesters += 1;
                    stats.pendingSemesters -= 1;
                    
                    updateStatistics();
                    renderFeeTable();
                }
                
                showNotification(`Payment of Rs. ${totalAmount.toLocaleString()} completed successfully!`, 'success');
                
                // Close modal
                const modalElement = document.getElementById('paymentModal');
                const modal = bootstrap.Modal.getInstance(modalElement);
                modal.hide();
            }, 2000);
        } else {
            // Bank/Mobile payment
            let paymentMethodName = '';
            let instructions = '';
            
            switch(selectedPaymentMethod) {
                case 'bank':
                    paymentMethodName = 'Bank Deposit';
                    instructions = 'Deposit at any HBL branch and upload deposit slip';
                    break;
                case 'jazzcash':
                    paymentMethodName = 'JazzCash';
                    instructions = 'Send money to 0312-3456789 and upload screenshot';
                    break;
                case 'easypaisa':
                    paymentMethodName = 'EasyPaisa';
                    instructions = 'Send money to 0345-6789012 and upload screenshot';
                    break;
            }
            
            alert(`📋 Payment Instructions\n\n` +
                  `Method: ${paymentMethodName}\n` +
                  `Voucher: ${selectedVoucher.voucherNo}\n` +
                  `Amount: Rs. ${totalAmount.toLocaleString()}\n\n` +
                  `Instructions: ${instructions}\n\n` +
                  `After payment, please upload the proof in the "Upload Voucher" section.`);
            
            // Close modal
            const modalElement = document.getElementById('paymentModal');
            const modal = bootstrap.Modal.getInstance(modalElement);
            modal.hide();
        }
    }

    // Show notification
    function showNotification(message, type = 'success') {
        const alert = document.getElementById('successAlert');
        
        // Set type
        if (type === 'success') {
            alert.className = 'notification-alert alert alert-success alert-dismissible fade show';
            document.getElementById('notificationTitle').textContent = 'Success!';
        } else if (type === 'info') {
            alert.className = 'notification-alert alert alert-info alert-dismissible fade show';
            document.getElementById('notificationTitle').textContent = 'Info!';
        } else if (type === 'warning') {
            alert.className = 'notification-alert alert alert-warning alert-dismissible fade show';
            document.getElementById('notificationTitle').textContent = 'Warning!';
        }
        
        document.getElementById('notificationMessage').textContent = message;
        alert.style.display = 'block';
        
        // Auto hide after 5 seconds
        setTimeout(hideNotification, 5000);
    }

    // Hide notification
    function hideNotification() {
        document.getElementById('successAlert').style.display = 'none';
    }

    // Format date
    function formatDate(dateString) {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    // Add days to date
    function addDaysToDate(dateString, days) {
        const date = new Date(dateString);
        date.setDate(date.getDate() + days);
        return date.toISOString().split('T')[0];
    }

    // Format file size
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Make functions globally available
    window.viewVoucher = viewVoucher;
    window.viewVoucherDetails = viewVoucherDetails;
    window.downloadVoucher = downloadVoucher;
    window.payNow = payNow;