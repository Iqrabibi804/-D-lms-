// login.js
const API_BASE_URL = 'http://localhost:5000/api';
let correctCredentials = { registration: "2023CSE001", password: "student123", captcha: "" };

function generateCaptcha() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let captcha = '';
    for (let i = 0; i < 5; i++) captcha += chars.charAt(Math.floor(Math.random() * chars.length));
    document.getElementById('captchaDisplay').textContent = captcha;
    correctCredentials.captcha = captcha;
}
function regToEmail(regNo) {
    return `${regNo.toLowerCase()}@university.edu`;
}
async function isBackendConnected() {
    try {
        const res = await fetch(`${API_BASE_URL}/health`);
        return res.ok;
    } catch {
        return false;
    }
}
function showError(msg) {
    const errorDiv = document.getElementById('errorMessage');
    errorDiv.textContent = msg;
    errorDiv.style.display = 'block';
}
// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    generateCaptcha();
    document.getElementById('refreshCaptcha').addEventListener('click', generateCaptcha);
    
    // Backend status
    isBackendConnected().then(connected => {
        const header = document.querySelector('.header h1');
        header.innerHTML = connected
            ? '🎓 Student Portal <small style="font-size:12px;color:green;">(Backend Connected)</small>'
            : '🎓 Student Portal <small style="font-size:12px;color:orange;">(Mock Mode)</small>';
    });
    
    // Login form handler
    document.getElementById('loginForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        const regNo = document.getElementById('reg-no').value.trim();
        const password = document.getElementById('password').value.trim();
        const captcha = document.getElementById('captchaInput').value.trim().toUpperCase();
        const errorDiv = document.getElementById('errorMessage');
        const btn = this.querySelector('button[type="submit"]');

        errorDiv.style.display = 'none';
        btn.disabled = true;
        btn.textContent = 'Logging in...';

        const backendAvailable = await isBackendConnected();

        if (backendAvailable) {
            try {
                const res = await fetch(`${API_BASE_URL}/auth/login`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email: regToEmail(regNo), password })
                });
                const data = await res.json();
                if (data.success) {
                    localStorage.setItem('token', data.token);
                    data.user.studentId = regNo;
                    localStorage.setItem('user', JSON.stringify(data.user));
                    alert('✅ Login successful! Redirecting...');
                    setTimeout(() => {
                        window.location.href = 'dashboard.html';
                    }, 1000);
                } else showError(data.message || 'Invalid credentials.');
            } catch {
                showError('Backend error. Please try again.');
            }
        } else {
            // Mock fallback - NO CAPTCHA CHECK
            if (regNo === correctCredentials.registration && password === correctCredentials.password) {
                const mockUser = {
                    studentId: regNo,
                    fullName: "Hina",
                    email: "hina@university.edu",
                    department: "Computer Science",
                    year: "3rd Year",
                    role: "student"
                };
                localStorage.setItem('user', JSON.stringify(mockUser));
                localStorage.setItem('token', 'mock-jwt-token');
                alert('✅ Login successful (Mock Mode)! Redirecting...');
                setTimeout(() => {
                    window.location.href = 'dashboard.html';
                }, 1000);
            } else {
                showError('Invalid registration or password.');
            }
        }

        btn.disabled = false;
        btn.textContent = 'Login to Portal';
        generateCaptcha();
    });
    
    // Quick test button
    const quickBtn = document.createElement('button');
    quickBtn.type = 'button';
    quickBtn.textContent = '🚀 Quick Test (Fill Credentials)';
    quickBtn.style.cssText = 'width:100%; padding:12px; background:#28a745; color:white; border:none; border-radius:8px; margin-top:15px; cursor:pointer;';
    quickBtn.onclick = function() {
        document.getElementById('reg-no').value = '2023CSE001';
        document.getElementById('password').value = 'student123';
        document.getElementById('captchaInput').value = correctCredentials.captcha;
    };
    document.getElementById('loginForm').appendChild(quickBtn);
});