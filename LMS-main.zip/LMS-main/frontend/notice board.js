
        // Notice cards data
        const noticeCards = [
            {
                id: 1,
                title: "Final Term Examinations Schedule Spring 2024",
                description: "The final term examination schedule for Spring 2024 semester has been announced. All students are required to check their examination dates and venues.",
                category: "exam",
                date: "2024-05-15",
                department: "Examination Department",
                content: `<p>The final term examination schedule for Spring 2024 semester has been officially announced. All students must adhere to the following guidelines:</p>
                         <h5>Important Instructions:</h5>
                         <ul>
                             <li>Examinations will commence from <strong>June 1, 2024</strong> and conclude on <strong>June 20, 2024</strong></li>
                             <li>All students must carry their university ID cards and admission cards</li>
                             <li>Electronic devices are strictly prohibited in examination halls</li>
                             <li>Reporting time is 30 minutes before the exam starts</li>
                         </ul>
                         <h5>Venue Details:</h5>
                         <ul>
                             <li>Morning Session: Main Examination Hall, Block A</li>
                             <li>Evening Session: Auditorium Complex, Block C</li>
                         </ul>
                         <p>For any queries, contact the Examination Department during office hours.</p>`,
                attachments: [
                    { name: "Exam_Schedule_Spring2024.pdf", size: "2.4 MB", type: "pdf" },
                    { name: "Exam_Rules_Regulations.pdf", size: "1.1 MB", type: "pdf" }
                ],
                read: false
            },
            {
                id: 2,
                title: "Important: Fee Payment Last Date Extended",
                description: "Due to technical issues in the online payment system, the last date for fee payment has been extended till 25th May 2024.",
                category: "important",
                date: "2024-05-10",
                department: "Accounts Office",
                content: `<p>This is to inform all students that due to technical issues in the online payment system, the university administration has decided to extend the fee payment deadline.</p>
                         <h5>New Payment Schedule:</h5>
                         <ul>
                             <li><strong>Extended Deadline:</strong> May 25, 2024</li>
                             <li><strong>Late Fee Charges:</strong> Will be applicable from May 26, 2024</li>
                             <li><strong>Payment Methods:</strong> Online banking, bank deposit, and mobile wallets</li>
                         </ul>
                         <h5>Important Notes:</h5>
                         <ol>
                             <li>Students who fail to pay fees by the extended deadline will not be allowed to appear in final examinations</li>
                             <li>Late fee of 5% will be charged per week after the deadline</li>
                             <li>Contact accounts office for any payment-related queries</li>
                         </ol>
                         <p><strong>Note:</strong> The online payment portal is now functioning properly. Please make your payments at the earliest.</p>`,
                attachments: [
                    { name: "Fee_Structure_2024.pdf", size: "3.2 MB", type: "pdf" },
                    { name: "Bank_Details.docx", size: "450 KB", type: "doc" }
                ],
                read: true
            },
            {
                id: 3,
                title: "University Annual Sports Day 2024",
                description: "The annual sports day will be held on 30th May 2024. Registrations are open for various sports competitions.",
                category: "event",
                date: "2024-05-05",
                department: "Sports Department",
                content: `<p>We are pleased to announce the University Annual Sports Day 2024, which promises to be an exciting event filled with sportsmanship and camaraderie.</p>
                         <h5>Event Details:</h5>
                         <ul>
                             <li><strong>Date:</strong> May 30, 2024</li>
                             <li><strong>Time:</strong> 8:00 AM to 5:00 PM</li>
                             <li><strong>Venue:</strong> University Sports Complex</li>
                         </ul>
                         <h5>Sports Competitions:</h5>
                         <ol>
                             <li>Athletics (100m, 200m, 400m, 800m races)</li>
                             <li>Cricket Tournament</li>
                             <li>Football Match</li>
                             <li>Basketball Tournament</li>
                             <li>Table Tennis</li>
                             <li>Badminton</li>
                             <li>Tug of War</li>
                         </ol>
                         <h5>Registration:</h5>
                         <ul>
                             <li>Last date for registration: May 20, 2024</li>
                             <li>Registration fee: Rs. 500 per participant</li>
                             <li>Register at Sports Department office or online portal</li>
                         </ul>
                         <p>Let's celebrate sportsmanship and healthy competition!</p>`,
                attachments: [
                    { name: "Sports_Day_Schedule.pdf", size: "1.8 MB", type: "pdf" },
                    { name: "Registration_Form.docx", size: "550 KB", type: "doc" }
                ],
                read: false
            },
            {
                id: 4,
                title: "New Library Timings from June 2024",
                description: "The university library timings have been revised. New timings will be effective from 1st June 2024.",
                category: "academic",
                date: "2024-05-03",
                department: "Library Department",
                content: `<p>To better serve the academic community, the University Library timings have been revised. The new schedule will provide extended hours for research and study.</p>
                         <h5>New Library Timings (Effective from June 1, 2024):</h5>
                         <table class="table table-bordered">
                             <thead>
                                 <tr>
                                     <th>Day</th>
                                     <th>Opening Time</th>
                                     <th>Closing Time</th>
                                 </tr>
                             </thead>
                             <tbody>
                                 <tr>
                                     <td>Monday - Friday</td>
                                     <td>8:00 AM</td>
                                     <td>10:00 PM</td>
                                 </tr>
                                 <tr>
                                     <td>Saturday</td>
                                     <td>9:00 AM</td>
                                     <td>6:00 PM</td>
                                 </tr>
                                 <tr>
                                     <td>Sunday</td>
                                     <td>10:00 AM</td>
                                     <td>4:00 PM</td>
                                 </tr>
                             </tbody>
                         </table>
                         <h5>Special Arrangements:</h5>
                         <ul>
                             <li>24/7 Reading Room access for final year students</li>
                             <li>Extended hours during examination period (up to midnight)</li>
                             <li>Online book reservation system now available</li>
                         </ul>
                         <p>For any queries regarding library services, please contact the library help desk.</p>`,
                attachments: [
                    { name: "Library_Rules.pdf", size: "890 KB", type: "pdf" }
                ],
                read: true
            },
            {
                id: 5,
                title: "Scholarship Applications Open for Merit Students",
                description: "Merit-based scholarship applications for the academic year 2024-25 are now open. Last date to apply is 15th June 2024.",
                category: "scholarship",
                date: "2024-04-28",
                department: "Scholarship Office",
                content: `<p>The university is pleased to announce the opening of merit-based scholarship applications for the academic year 2024-25. These scholarships aim to support and encourage academic excellence.</p>
                         <h5>Available Scholarships:</h5>
                         <ul>
                             <li><strong>Merit Scholarship:</strong> For students with CGPA 3.8 and above (100% tuition fee waiver)</li>
                             <li><strong>Need-based Scholarship:</strong> For financially challenged students (50-75% fee concession)</li>
                             <li><strong>Sports Scholarship:</strong> For national level athletes</li>
                             <li><strong>Special Talent Scholarship:</strong> For exceptional achievements in arts, culture, etc.</li>
                         </ul>
                         <h5>Eligibility Criteria:</h5>
                         <ol>
                             <li>Minimum CGPA of 3.5 for merit scholarship</li>
                             <li>No disciplinary actions against the student</li>
                             <li>Regular attendance record (minimum 85%)</li>
                             <li>Active participation in university activities</li>
                         </ol>
                         <h5>Application Process:</h5>
                         <ul>
                             <li>Submit online application through student portal</li>
                             <li>Attach required documents (marksheets, income certificate, etc.)</li>
                             <li>Application deadline: June 15, 2024</li>
                             <li>Interview dates: July 1-5, 2024</li>
                         </ul>
                         <p>For more information, visit the Scholarship Office or check the detailed guidelines.</p>`,
                attachments: [
                    { name: "Scholarship_Guidelines.pdf", size: "2.1 MB", type: "pdf" },
                    { name: "Application_Form.docx", size: "680 KB", type: "doc" },
                    { name: "Required_Documents.pdf", size: "950 KB", type: "pdf" }
                ],
                read: false
            },
            {
                id: 6,
                title: "Holiday Announcement: Eid-ul-Fitr",
                description: "The university will remain closed from 10th to 14th April 2024 on account of Eid-ul-Fitr holidays.",
                category: "event",
                date: "2024-04-01",
                department: "Administration Office",
                content: `<p>This is to inform all students, faculty, and staff that the university will remain closed for Eid-ul-Fitr celebrations.</p>
                         <h5>Holiday Schedule:</h5>
                         <ul>
                             <li><strong>Start Date:</strong> April 10, 2024</li>
                             <li><strong>End Date:</strong> April 14, 2024</li>
                             <li><strong>Reopening:</strong> April 15, 2024 (Monday)</li>
                         </ul>
                         <h5>Important Information:</h5>
                         <ol>
                             <li>All academic activities will resume from April 15, 2024</li>
                             <li>Library will also remain closed during this period</li>
                             <li>Emergency contact numbers will remain operational</li>
                             <li>Security services will continue as usual</li>
                         </ol>
                         <p>The university administration wishes all students, faculty, and staff a blessed Eid-ul-Fitr. May this occasion bring joy, peace, and prosperity to everyone.</p>
                         <p><strong>Note:</strong> The cafeteria and other food services will remain closed during holidays.</p>`,
                attachments: [],
                read: true
            }
        ];

        let currentFilter = 'all';

        // Initialize page
        document.addEventListener('DOMContentLoaded', function() {
            renderNoticeCards();
            setupEventListeners();
        });

        // Render notice cards
        function renderNoticeCards() {
            const container = document.getElementById('noticeCardsContainer');
            const emptyState = document.getElementById('emptyState');
            
            // Filter notices based on current filter
            let filteredNotices = noticeCards;
            
            if (currentFilter === 'important') {
                filteredNotices = noticeCards.filter(notice => notice.category === 'important');
            } else if (currentFilter === 'academic') {
                filteredNotices = noticeCards.filter(notice => notice.category === 'academic');
            } else if (currentFilter === 'exam') {
                filteredNotices = noticeCards.filter(notice => notice.category === 'exam');
            } else if (currentFilter === 'fee') {
                filteredNotices = noticeCards.filter(notice => notice.category === 'fee');
            } else if (currentFilter === 'event') {
                filteredNotices = noticeCards.filter(notice => notice.category === 'event');
            } else if (currentFilter === 'scholarship') {
                filteredNotices = noticeCards.filter(notice => notice.category === 'scholarship');
            } else if (currentFilter === 'unread') {
                filteredNotices = noticeCards.filter(notice => !notice.read);
            }
            
            container.innerHTML = '';
            
            if (filteredNotices.length === 0) {
                container.style.display = 'none';
                emptyState.style.display = 'block';
                return;
            }
            
            container.style.display = 'grid';
            emptyState.style.display = 'none';
            
            filteredNotices.forEach(notice => {
                const card = createNoticeCard(notice);
                container.appendChild(card);
            });
        }

        // Create notice card HTML
        function createNoticeCard(notice) {
            const card = document.createElement('div');
            card.className = 'notice-card';
            
            let categoryClass = '';
            let categoryText = '';
            
            switch(notice.category) {
                case 'important':
                    categoryClass = 'category-important';
                    categoryText = 'Important';
                    break;
                case 'academic':
                    categoryClass = 'category-academic';
                    categoryText = 'Academic';
                    break;
                case 'exam':
                    categoryClass = 'category-exam';
                    categoryText = 'Examination';
                    break;
                case 'fee':
                    categoryClass = 'category-fee';
                    categoryText = 'Fee Related';
                    break;
                case 'event':
                    categoryClass = 'category-event';
                    categoryText = 'Event';
                    break;
                case 'scholarship':
                    categoryClass = 'category-scholarship';
                    categoryText = 'Scholarship';
                    break;
            }
            
            const formattedDate = formatDate(notice.date);
            const hasAttachments = notice.attachments && notice.attachments.length > 0;
            
            card.innerHTML = `
                ${!notice.read ? '<div class="unread-indicator"></div>' : ''}
                <div class="card-header">
                    <span class="notice-category ${categoryClass}">${categoryText}</span>
                    <div class="notice-date">
                        <i class="far fa-calendar-alt"></i>
                        ${formattedDate}
                    </div>
                </div>
                <div class="card-body">
                    <h4 class="notice-title">${notice.title}</h4>
                    <p class="notice-description">${notice.description}</p>
                </div>
                <div class="card-footer">
                    <div class="notice-department">
                        <i class="fas fa-building"></i>
                        ${notice.department}
                    </div>
                    <div class="notice-actions">
                        <button class="btn-read-more" onclick="viewNoticeDetails(${notice.id})">
                            <i class="fas fa-eye"></i>
                            Read More
                        </button>
                        ${hasAttachments ? `
                            <a href="#" class="btn-attachment" onclick="viewNoticeDetails(${notice.id}); return false;">
                                <i class="fas fa-paperclip"></i>
                                Attachments (${notice.attachments.length})
                            </a>
                        ` : ''}
                    </div>
                </div>
            `;
            
            return card;
        }

        // Filter notices
        function filterNotices(filter) {
            currentFilter = filter;
            
            // Update active filter button
            document.querySelectorAll('.filter-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            event.target.classList.add('active');
            
            renderNoticeCards();
        }

        // View notice details
        function viewNoticeDetails(id) {
            const notice = noticeCards.find(n => n.id === id);
            if (!notice) return;
            
            // Mark as read
            notice.read = true;
            
            let categoryClass = '';
            let categoryText = '';
            
            switch(notice.category) {
                case 'important':
                    categoryClass = 'category-important';
                    categoryText = 'Important';
                    break;
                case 'academic':
                    categoryClass = 'category-academic';
                    categoryText = 'Academic';
                    break;
                case 'exam':
                    categoryClass = 'category-exam';
                    categoryText = 'Examination';
                    break;
                case 'fee':
                    categoryClass = 'category-fee';
                    categoryText = 'Fee Related';
                    break;
                case 'event':
                    categoryClass = 'category-event';
                    categoryText = 'Event';
                    break;
                case 'scholarship':
                    categoryClass = 'category-scholarship';
                    categoryText = 'Scholarship';
                    break;
            }
            
            // Update modal content
            document.getElementById('modalCategory').className = `notice-category ${categoryClass}`;
            document.getElementById('modalCategory').textContent = categoryText;
            document.getElementById('modalDate').textContent = formatDate(notice.date);
            document.getElementById('modalDepartment').textContent = notice.department;
            document.getElementById('modalTitle').textContent = notice.title;
            document.getElementById('modalContent').innerHTML = notice.content;
            
            // Handle attachments
            const attachmentsSection = document.getElementById('modalAttachments');
            const attachmentList = document.getElementById('attachmentList');
            
            if (notice.attachments && notice.attachments.length > 0) {
                attachmentsSection.style.display = 'block';
                attachmentList.innerHTML = '';
                
                notice.attachments.forEach(attachment => {
                    let iconClass = '';
                    let icon = '';
                    
                    switch(attachment.type) {
                        case 'pdf':
                            iconClass = 'icon-pdf';
                            icon = 'fas fa-file-pdf';
                            break;
                        case 'doc':
                            iconClass = 'icon-doc';
                            icon = 'fas fa-file-word';
                            break;
                        case 'image':
                            iconClass = 'icon-image';
                            icon = 'fas fa-file-image';
                            break;
                        case 'excel':
                            iconClass = 'icon-excel';
                            icon = 'fas fa-file-excel';
                            break;
                    }
                    
                    const attachmentItem = document.createElement('div');
                    attachmentItem.className = 'attachment-item';
                    attachmentItem.innerHTML = `
                        <div class="attachment-info">
                            <div class="attachment-icon ${iconClass}">
                                <i class="${icon}"></i>
                            </div>
                            <div>
                                <div class="attachment-name">${attachment.name}</div>
                                <div class="attachment-size">${attachment.size}</div>
                            </div>
                        </div>
                        <button class="btn-download-attachment" onclick="downloadAttachment('${attachment.name}')">
                            <i class="fas fa-download"></i>
                            Download
                        </button>
                    `;
                    
                    attachmentList.appendChild(attachmentItem);
                });
            } else {
                attachmentsSection.style.display = 'none';
            }
            
            // Show modal
            const modal = new bootstrap.Modal(document.getElementById('noticeDetailsModal'));
            modal.show();
            
            // Re-render cards to update read status
            renderNoticeCards();
        }

        // Download attachment
        function downloadAttachment(filename) {
            alert(`Downloading: ${filename}\n(In a real application, this would download the actual file)`);
            
            // Simulate download
            const link = document.createElement('a');
            link.href = '#';
            link.download = filename;
            link.click();
        }

        // Setup event listeners
        function setupEventListeners() {
            // No additional listeners needed for now
        }

        // Format date
        function formatDate(dateString) {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });
        }

        // Export functions for HTML
        window.filterNotices = filterNotices;
        window.viewNoticeDetails = viewNoticeDetails;
        window.downloadAttachment = downloadAttachment;
