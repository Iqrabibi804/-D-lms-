// user-profile.js - Sab jagah same user information ke liye

const UserProfile = {
    // User ka basic data
    currentUser: {
        studentId: "BSE234",
        fullName: "Hina",
        email: "hina@university.edu",
        department: "Computer Science",
        year: "3rd Year",
        role: "student",
        registrationNo: "2023CSE001",
        
        // Profile image URL
        profileImage: "https://ui-avatars.com/api/?name=Hina&background=0D8BC9&color=fff&size=130&bold=true",
        
        // Personal details
        dateOfBirth: "20-06-2005",
        gender: "Female",
        bloodGroup: "AB+",
        religion: "Islam",
        nationality: "Pakistan",
        cnic: "37101-2635387-3",
        
        // Contact info
        phone: "+92 123 456 789",
        address: "Karachi, Pakistan",
        permanentAddress: "Karachi, Pakistan",
        
        // Family info
        fatherName: "Ali",
        fatherOccupation: "Business",
        fatherCnic: "37133-5636336-?",
        motherName: "Fatima"
    },

    // Sab pages update karne ka function
    updateAllPages() {
        this.updateDashboard();
        this.updateProfilePage();
        this.updateLibraryPage();
    },

    // Dashboard update kare
    updateDashboard() {
        if (document.querySelector('.user-avatar')) {
            document.querySelector('.user-avatar').textContent = this.currentUser.fullName.charAt(0);
            document.querySelector('.user-info h3').textContent = this.currentUser.fullName;
            document.querySelector('.user-info p').textContent = `${this.currentUser.studentId} - Student`;
            document.querySelector('.dashboard-header h1').textContent = `Welcome to Your Dashboard, ${this.currentUser.fullName}!`;
        }
    },

    // Profile page update kare
    updateProfilePage() {
        if (document.querySelector('.profile-header img')) {
            // Update profile image
            document.querySelector('.profile-header img').src = this.currentUser.profileImage;
            
            // Update name
            document.querySelector('.profile-info h1').textContent = this.currentUser.fullName;
            
            // Update email
            const emailElement = document.querySelector('.contact-info a[href^="mailto"]');
            if (emailElement) {
                emailElement.textContent = this.currentUser.email;
                emailElement.href = `mailto:${this.currentUser.email}`;
            }
            
            // Update phone
            const phoneElement = document.querySelector('.contact-info span');
            if (phoneElement && phoneElement.textContent.includes('+92')) {
                phoneElement.textContent = this.currentUser.phone;
            }
            
            // Update registration number
            const regElements = document.querySelectorAll('.info-value');
            regElements.forEach(el => {
                if (el.textContent === 'B23F34767436SEeu') {
                    el.textContent = this.currentUser.registrationNo;
                }
            });
        }
    },

    // Library page update kare
    updateLibraryPage() {
        if (document.getElementById('studentId')) {
            document.getElementById('studentId').textContent = this.currentUser.studentId;
            document.getElementById('studentName').textContent = this.currentUser.fullName;
            document.getElementById('studentDept').textContent = this.currentUser.department;
        }
    },

    // Image update kare
    updateProfileImage(newImageUrl) {
        this.currentUser.profileImage = newImageUrl;
        this.updateAllPages();
        
        // Save to localStorage
        localStorage.setItem('lms_user_image', newImageUrl);
    },

    // Data save kare (localStorage mein)
    saveToStorage() {
        localStorage.setItem('lms_user_data', JSON.stringify(this.currentUser));
    },

    // Data load kare
    loadFromStorage() {
        const saved = localStorage.getItem('lms_user_data');
        if (saved) {
            this.currentUser = JSON.parse(saved);
        }
    }
};

// Automatically run on page load
document.addEventListener('DOMContentLoaded', function() {
    UserProfile.loadFromStorage();
    UserProfile.updateAllPages();
});

// Global access ke liye
window.UserProfile = UserProfile;