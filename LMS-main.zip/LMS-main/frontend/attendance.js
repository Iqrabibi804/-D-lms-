        // Sample attendance data
        const attendanceData = {
            // Mobile Application Development
            'COMP-331': {
                courseTitle: "Mobile Application Development",
                courseCode: "COMP-331",
                semester: "FALL-2025",
                instructor: {
                    name: "Mr. Shakeel Ahmed",
                    position: "Assistant Professor",
                    email: "shakeel.ahmed@university.edu",
                    avatar: "S"
                },
                attendance: {
                    totalClasses: 18,
                    attended: 14,
                    percentage: 78
                },
                sessions: [
                    { set: 1, date: "05-12-2025", time: "10:00 AM", type: "Scheduled", status: "Present" },
                    { set: 2, date: "04-12-2025", time: "09:55 AM", type: "Scheduled", status: "Present" },
                    { set: 3, date: "03-12-2025", time: "01:44 PM", type: "Scheduled", status: "Absent" },
                    { set: 4, date: "27-11-2025", time: "01:52 PM", type: "Scheduled", status: "Present" },
                    { set: 5, date: "26-11-2025", time: "12:42 PM", type: "Scheduled", status: "Present" },
                    { set: 6, date: "19-11-2025", time: "12:56 PM", type: "Scheduled", status: "Absent" },
                    { set: 7, date: "18-11-2025", time: "08:15 AM", type: "Scheduled", status: "Present" },
                    { set: 8, date: "12-11-2025", time: "12:43 PM", type: "Scheduled", status: "Present" },
                    { set: 9, date: "11-11-2025", time: "08:19 AM", type: "Scheduled", status: "Present" },
                    { set: 10, date: "05-11-2025", time: "12:46 PM", type: "Scheduled", status: "Present" },
                    { set: 11, date: "04-11-2025", time: "08:20 AM", type: "Scheduled", status: "Present" },
                    { set: 12, date: "29-10-2025", time: "01:45 PM", type: "Scheduled", status: "Absent" },
                    { set: 13, date: "28-10-2025", time: "09:12 AM", type: "Scheduled", status: "Present" },
                    { set: 14, date: "15-10-2025", time: "01:49 PM", type: "Scheduled", status: "Present" },
                    { set: 15, date: "14-10-2025", time: "09:22 AM", type: "Scheduled", status: "Present" },
                    { set: 16, date: "08-10-2025", time: "02:14 PM", type: "Scheduled", status: "Present" },
                    { set: 17, date: "07-10-2025", time: "10:54 AM", type: "Scheduled", status: "Absent" },
                    { set: 18, date: "02-10-2025", time: "09:27 AM", type: "Scheduled", status: "Present" }
                ]
            },

            // Computer Networks
            'COMP-322': {
                courseTitle: "Computer Networks",
                courseCode: "COMP-322",
                semester: "FALL-2025",
                instructor: {
                    name: "Dr. Sajjad Ahmed",
                    position: "Associate Professor",
                    email: "sajjad.ahmed@university.edu",
                    avatar: "S"
                },
                attendance: {
                    totalClasses: 15,
                    attended: 13,
                    percentage: 87
                },
                sessions: [
                    { set: 1, date: "03-12-2025", time: "11:00 AM", type: "Scheduled", status: "Present" },
                    { set: 2, date: "26-11-2025", time: "11:00 AM", type: "Scheduled", status: "Present" },
                    { set: 3, date: "19-11-2025", time: "11:00 AM", type: "Scheduled", status: "Absent" },
                    { set: 4, date: "12-11-2025", time: "11:00 AM", type: "Scheduled", status: "Present" },
                    { set: 5, date: "05-11-2025", time: "11:00 AM", type: "Scheduled", status: "Present" },
                    { set: 6, date: "29-10-2025", time: "11:00 AM", type: "Scheduled", status: "Present" },
                    { set: 7, date: "22-10-2025", time: "11:00 AM", type: "Scheduled", status: "Present" },
                    { set: 8, date: "15-10-2025", time: "11:00 AM", type: "Scheduled", status: "Present" },
                    { set: 9, date: "08-10-2025", time: "11:00 AM", type: "Scheduled", status: "Present" },
                    { set: 10, date: "01-10-2025", time: "11:00 AM", type: "Scheduled", status: "Present" },
                    { set: 11, date: "24-09-2025", time: "11:00 AM", type: "Scheduled", status: "Absent" },
                    { set: 12, date: "17-09-2025", time: "11:00 AM", type: "Scheduled", status: "Present" },
                    { set: 13, date: "10-09-2025", time: "11:00 AM", type: "Scheduled", status: "Present" },
                    { set: 14, date: "03-09-2025", time: "11:00 AM", type: "Scheduled", status: "Present" },
                    { set: 15, date: "27-08-2025", time: "11:00 AM", type: "Scheduled", status: "Present" }
                ]
            },

            // Computer Networks Lab
            'COMP-322L': {
                courseTitle: "Computer Networks Lab",
                courseCode: "COMP-322L",
                semester: "FALL-2025",
                instructor: {
                    name: "Dr. Sajjad Ahmed",
                    position: "Associate Professor",
                    email: "sajjad.ahmed@university.edu",
                    avatar: "S"
                },
                attendance: {
                    totalClasses: 8,
                    attended: 7,
                    percentage: 88
                },
                sessions: [
                    { set: 1, date: "04-12-2025", time: "02:00 PM", type: "Lab", status: "Present" },
                    { set: 2, date: "27-11-2025", time: "02:00 PM", type: "Lab", status: "Present" },
                    { set: 3, date: "20-11-2025", time: "02:00 PM", type: "Lab", status: "Present" },
                    { set: 4, date: "13-11-2025", time: "02:00 PM", type: "Lab", status: "Present" },
                    { set: 5, date: "06-11-2025", time: "02:00 PM", type: "Lab", status: "Absent" },
                    { set: 6, date: "30-10-2025", time: "02:00 PM", type: "Lab", status: "Present" },
                    { set: 7, date: "23-10-2025", time: "02:00 PM", type: "Lab", status: "Present" },
                    { set: 8, date: "16-10-2025", time: "02:00 PM", type: "Lab", status: "Present" }
                ]
            },

            // Database Systems
            'COMP-231': {
                courseTitle: "Database Systems",
                courseCode: "COMP-231",
                semester: "SPRING-2025",
                instructor: {
                    name: "Dr. Mubashir Mansoor",
                    position: "Professor",
                    email: "mubashir.mansoor@university.edu",
                    avatar: "M"
                },
                attendance: {
                    totalClasses: 20,
                    attended: 18,
                    percentage: 90
                },
                sessions: [
                    { set: 1, date: "15-04-2025", time: "09:00 AM", type: "Scheduled", status: "Present" },
                    { set: 2, date: "08-04-2025", time: "09:00 AM", type: "Scheduled", status: "Present" },
                    { set: 3, date: "01-04-2025", time: "09:00 AM", type: "Scheduled", status: "Present" },
                    { set: 4, date: "25-03-2025", time: "09:00 AM", type: "Scheduled", status: "Present" },
                    { set: 5, date: "18-03-2025", time: "09:00 AM", type: "Scheduled", status: "Absent" },
                    { set: 6, date: "11-03-2025", time: "09:00 AM", type: "Scheduled", status: "Present" },
                    { set: 7, date: "04-03-2025", time: "09:00 AM", type: "Scheduled", status: "Present" },
                    { set: 8, date: "25-02-2025", time: "09:00 AM", type: "Scheduled", status: "Present" },
                    { set: 9, date: "18-02-2025", time: "09:00 AM", type: "Scheduled", status: "Present" },
                    { set: 10, date: "11-02-2025", time: "09:00 AM", type: "Scheduled", status: "Present" },
                    { set: 11, date: "04-02-2025", time: "09:00 AM", type: "Scheduled", status: "Absent" },
                    { set: 12, date: "28-01-2025", time: "09:00 AM", type: "Scheduled", status: "Present" },
                    { set: 13, date: "21-01-2025", time: "09:00 AM", type: "Scheduled", status: "Present" },
                    { set: 14, date: "14-01-2025", time: "09:00 AM", type: "Scheduled", status: "Present" },
                    { set: 15, date: "07-01-2025", time: "09:00 AM", type: "Scheduled", status: "Present" }
                ]
            }
        };

        // Get course code from URL
        function getCourseFromURL() {
            const params = new URLSearchParams(window.location.search);
            return params.get('course') || 'COMP-331'; // Default to COMP-331
        }

        // Go back to My Courses
        function goBackToCourses() {
            // Save current course code in localStorage for reference
            const courseCode = getCourseFromURL();
            localStorage.setItem('lastViewedCourse', courseCode);
            
            // Try different file names
            const possibleFiles = ['my_courses.html', 'mycourse.html', 'courses.html', 'index.html'];
            
            for (let file of possibleFiles) {
                try {
                    // Try to navigate to the file
                    window.location.href = file;
                    return;
                } catch (e) {
                    continue;
                }
            }
            
            // If none work, show error
            alert('Could not find My Courses page. Please check the file name.');
        }

        // Load attendance data
        function loadAttendance() {
            const courseCode = getCourseFromURL();
            const courseData = attendanceData[courseCode];
            
            if (!courseData) {
                alert('Course data not found!');
                return;
            }

            // Update page title
            document.title = `Attendance - ${courseData.courseCode}`;

            // Update header
            document.getElementById('courseTitle').textContent = courseData.courseTitle;
            document.getElementById('courseCode').textContent = courseData.courseCode;
            document.getElementById('semesterBadge').textContent = courseData.semester;
            
            // Update instructor info
            document.getElementById('instructorName').textContent = courseData.instructor.name;
            document.getElementById('instructorAvatar').textContent = courseData.instructor.avatar;
            document.getElementById('instructorDetails').textContent = 
                `${courseData.instructor.position} | ${courseData.instructor.email}`;
            
            // Update stats
            const attendance = courseData.attendance;
            document.getElementById('attendancePercentage').textContent = `${attendance.percentage}%`;
            document.getElementById('classesAttended').textContent = attendance.attended;
            document.getElementById('classesAbsent').textContent = attendance.totalClasses - attendance.attended;
            document.getElementById('totalClasses').textContent = attendance.totalClasses;
            document.getElementById('progressPercentage').textContent = `${attendance.percentage}%`;
            
            // Update progress bar
            const progressFill = document.getElementById('progressFill');
            progressFill.style.width = `${attendance.percentage}%`;
            
            // Set progress bar color
            if (attendance.percentage >= 75) {
                progressFill.style.background = 'linear-gradient(90deg, #28a745, #20c997)';
            } else if (attendance.percentage >= 65) {
                progressFill.style.background = 'linear-gradient(90deg, #ffc107, #fd7e14)';
            } else {
                progressFill.style.background = 'linear-gradient(90deg, #dc3545, #c82333)';
            }
            
            // Show alert if below 75%
            const alertBox = document.getElementById('alertBox');
            if (attendance.percentage < 75) {
                alertBox.style.display = 'flex';
            } else {
                alertBox.style.display = 'none';
            }
            
            // Update session dates
            if (courseData.sessions.length > 0) {
                const firstDate = courseData.sessions[courseData.sessions.length - 1].date;
                const lastDate = courseData.sessions[0].date;
                document.getElementById('sessionDates').textContent = `${firstDate} - ${lastDate}`;
            }
            
            // Populate table
            const tableBody = document.getElementById('attendanceTableBody');
            tableBody.innerHTML = '';
            
            courseData.sessions.forEach(session => {
                const statusClass = session.status === 'Present' ? 'present' : 'absent';
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${session.set}</td>
                    <td>${session.date}</td>
                    <td>${session.time}</td>
                    <td>${session.type}</td>
                    <td><span class="status-badge ${statusClass}">${session.status}</span></td>
                `;
                tableBody.appendChild(row);
            });
        }

        // Initialize page
        document.addEventListener('DOMContentLoaded', loadAttendance);